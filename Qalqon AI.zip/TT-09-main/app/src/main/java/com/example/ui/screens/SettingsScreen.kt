package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.data.AiSensitivity
import com.example.data.PermissionStatusSnapshot
import com.example.data.QalqonSettingsState
import com.example.security.BiometricAvailabilityStatus
import com.example.security.PermissionHelper
import com.example.ui.ApiKeyTestUiState
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

@Composable
fun SettingsScreen(
    settings: QalqonSettingsState,
    permissions: PermissionStatusSnapshot,
    biometricAvailability: BiometricAvailabilityStatus,
    whitelistCount: Int,
    totalLogsCount: Int,
    isRunningAppAudit: Boolean,
    apiKeyTestState: ApiKeyTestUiState,
    onRefreshPermissions: () -> Unit,
    onToggleMasterShield: (Boolean) -> Unit,
    onToggleApkAutoScan: (Boolean) -> Unit,
    onTogglePeriodicAppAudit: (Boolean) -> Unit,
    onRunAppAuditNow: () -> Unit,
    onToggleSocialGuard: (Boolean) -> Unit,
    onToggleGeminiAnalysis: (Boolean) -> Unit,
    onToggleBiometricLock: (Boolean) -> Unit,
    onLockNow: () -> Unit,
    onSelectSensitivity: (AiSensitivity) -> Unit,
    onSaveGeminiApiKey: (String) -> Unit,
    onTestGeminiApiKey: (String) -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onOpenWhitelist: () -> Unit,
    onOpenSecurityLogs: () -> Unit,
    onReopenOnboarding: () -> Unit,
    onClearLogs: () -> Unit
) {
    val context = LocalContext.current
    var askedRationaleBefore by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            onRefreshPermissions()
            if (!granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val activity = context as? Activity
                val canAskAgain = activity != null && runCatching {
                    ActivityCompat.shouldShowRequestPermissionRationale(
                        activity,
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                }.getOrDefault(false)
                if (!askedRationaleBefore && !canAskAgain) {
                    PermissionHelper.openNotificationSettingsSafely(context)
                }
            }
        }
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "Ruxsatlarni sozlash ustasi",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            }

            item {
                PermissionWizardItem(
                    title = "Barcha fayllarga ruxsat (All Files Access)",
                    subtitle = "Telegram va Yuklanmalar papkalarini kuzatish",
                    icon = Icons.Filled.FolderOpen,
                    granted = permissions.hasAllFilesAccess,
                    testTag = "settings_perm_storage",
                    onAction = {
                        runCatching {
                            context.startActivity(PermissionHelper.createAllFilesAccessIntent(context))
                        }
                    }
                )
            }

            item {
                PermissionWizardItem(
                    title = "Accessibility Xizmati",
                    subtitle = "Instagram, YouTube va Facebook kontent himoyasi",
                    icon = Icons.Filled.AccessibilityNew,
                    granted = permissions.hasAccessibilityService,
                    testTag = "settings_perm_accessibility",
                    onAction = {
                        runCatching {
                            context.startActivity(PermissionHelper.createAccessibilitySettingsIntent())
                        }
                    }
                )
            }

            item {
                PermissionWizardItem(
                    title = "Ilovalar ustidan ko'rsatish (Overlay)",
                    subtitle = "XAVF! Qizil ogohlantirish ekranini chiqarish",
                    icon = Icons.Filled.Layers,
                    granted = permissions.hasOverlayPermission,
                    testTag = "settings_perm_overlay",
                    onAction = {
                        runCatching {
                            context.startActivity(PermissionHelper.createOverlayPermissionIntent(context))
                        }
                    }
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                item {
                    PermissionWizardItem(
                        title = "Bildirishnomalar",
                        subtitle = "24/7 fon xizmati va tezkor ogohlantirishlar",
                        icon = Icons.Filled.NotificationsActive,
                        granted = permissions.hasNotificationsPermission,
                        testTag = "settings_perm_notifications",
                        onAction = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                if (permissions.hasNotificationsPermission) {
                                    PermissionHelper.openNotificationSettingsSafely(context)
                                } else {
                                    val activity = context as? Activity
                                    askedRationaleBefore = activity != null && runCatching {
                                        ActivityCompat.shouldShowRequestPermissionRationale(
                                            activity,
                                            Manifest.permission.POST_NOTIFICATIONS
                                        )
                                    }.getOrDefault(false)
                                    try {
                                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } catch (_: Exception) {
                                        PermissionHelper.openNotificationSettingsSafely(context)
                                    }
                                }
                            } else {
                                PermissionHelper.openNotificationSettingsSafely(context)
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Fon xizmati diagnostikasi",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            }

            item {
                BatteryDiagnosticCard(
                    isExcluded = permissions.isBatteryOptimizationIgnored,
                    isFileObserverReady = permissions.hasAllFilesAccess && settings.isApkAutoScanEnabled,
                    onRecheck = onRefreshPermissions,
                    onOpenBatterySettings = {
                        runCatching {
                            context.startActivity(
                                PermissionHelper.createBatteryOptimizationSettingsIntent(context)
                            )
                        }
                    }
                )
            }

            item {
                PeriodicAppAuditCard(
                    isEnabled = settings.isPeriodicAppAuditEnabled && settings.isMasterShieldEnabled,
                    lastAuditTimestamp = settings.lastAppAuditTimestamp,
                    lastAuditSummaryUz = settings.lastAppAuditSummaryUz,
                    isRunning = isRunningAppAudit,
                    onToggle = onTogglePeriodicAppAudit,
                    onRunNow = onRunAppAuditNow
                )
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "AI va Himoya modullari",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingsSwitchRow(
                            title = "24/7 Asosiy Qalqon",
                            subtitle = "Barcha himoya modullarini umumiy boshqarish",
                            checked = settings.isMasterShieldEnabled,
                            testTag = "settings_switch_master",
                            onCheckedChange = onToggleMasterShield
                        )
                        SettingsSwitchRow(
                            title = "Telegram & APK Avto-skaneri",
                            subtitle = "Yangi yuklangan .apk fayllarni darhol tekshirish",
                            checked = settings.isApkAutoScanEnabled,
                            testTag = "settings_switch_apk",
                            onCheckedChange = onToggleApkAutoScan
                        )
                        SettingsSwitchRow(
                            title = "Ijtimoiy Tarmoqlar Kontent Qalqoni",
                            subtitle = "Ekstremistik va zararli kontentga tugmalarni bloklash",
                            checked = settings.isSocialGuardEnabled,
                            testTag = "settings_switch_social",
                            onCheckedChange = onToggleSocialGuard
                        )
                        SettingsSwitchRow(
                            title = "Gemini AI Bulut Tahlili",
                            subtitle = "To'g'ridan-to'g'ri Gemini REST API va oflayn zaxira tahlili",
                            checked = settings.isGeminiAnalysisEnabled,
                            testTag = "settings_switch_gemini",
                            onCheckedChange = onToggleGeminiAnalysis
                        )
                        SettingsSwitchRow(
                            title = "Biometrik qulf (Yuz / Barmoq izi)",
                            subtitle = "Sozlamalar va Himoyalangan Akkauntlarga kirishda tasdiqlash (${biometricAvailability.badgeUz})",
                            checked = settings.isBiometricLockEnabled,
                            testTag = "settings_switch_biometric",
                            onCheckedChange = onToggleBiometricLock
                        )
                        if (settings.isBiometricLockEnabled) {
                            OutlinedButton(
                                onClick = onLockNow,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("settings_lock_now_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "Maxfiy bo'limlarni hozir qulflash",
                                    color = CyberCyan,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = "AI Sezgirligi",
                                tint = CyberCyan
                            )
                            Text(
                                text = "AI Sezgirlik darajasi",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AiSensitivity.entries.forEach { level ->
                                FilterChip(
                                    selected = settings.aiSensitivity == level,
                                    onClick = { onSelectSensitivity(level) },
                                    label = { Text(level.titleUz) },
                                    modifier = Modifier.testTag("sensitivity_chip_${level.name.lowercase()}"),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyanContainer,
                                        selectedLabelColor = CyberCyan,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                        }
                        Text(
                            text = settings.aiSensitivity.descriptionUz,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }
            }

            item {
                GeminiApiKeyCard(
                    currentKey = settings.geminiApiKey,
                    testState = apiKeyTestState,
                    onSaveKey = onSaveGeminiApiKey,
                    onTestKey = onTestGeminiApiKey
                )
            }

            item {
                val notifPrefs = settings.notificationPreferences
                val notifAccent = if (notifPrefs.generalAlertsEnabled && notifPrefs.enabledThreatCategoryCount > 0) {
                    CyberCyan
                } else {
                    WarningAmber
                }
                val notifContainer = if (notifPrefs.generalAlertsEnabled && notifPrefs.enabledThreatCategoryCount > 0) {
                    CyberCyanContainer
                } else {
                    WarningAmberContainer
                }
                Surface(
                    onClick = onOpenNotificationSettings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_open_notification_prefs_card"),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, notifAccent.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = "Bildirishnoma sozlamalari",
                                tint = notifAccent
                            )
                            Column {
                                Text(
                                    text = "Bildirishnoma sozlamalari",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = notifPrefs.summaryUz(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                        StatusBadgePill(
                            text = if (notifPrefs.generalAlertsEnabled) {
                                "${notifPrefs.enabledThreatCategoryCount}/4 faol"
                            } else {
                                "O'chiq"
                            },
                            accentColor = notifAccent,
                            containerColor = notifContainer
                        )
                    }
                }
            }

            item {
                Surface(
                    onClick = onOpenWhitelist,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_open_whitelist_card"),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VerifiedUser,
                                contentDescription = "Oq ro'yxat",
                                tint = ShieldEmerald
                            )
                            Column {
                                Text(
                                    text = "Oq ro'yxat (Ishonchli manbalar)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Saqlangan ishonchli APK, paket va kanallar: $whitelistCount ta",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                        StatusBadgePill(
                            text = "Boshqarish",
                            accentColor = ShieldEmerald,
                            containerColor = ShieldEmeraldContainer
                        )
                    }
                }
            }

            item {
                Surface(
                    onClick = onOpenSecurityLogs,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_open_security_logs_card"),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.History,
                                contentDescription = "Xavfsizlik jurnali",
                                tint = CyberCyan
                            )
                            Column {
                                Text(
                                    text = "Xavfsizlik jurnali (Security Logs)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Bloklangan fayllar va ijtimoiy tahdidlar: $totalLogsCount ta",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                        StatusBadgePill(
                            text = "Ko'rish",
                            accentColor = CyberCyan,
                            containerColor = CyberCyanContainer
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onReopenOnboarding,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("settings_reopen_onboarding"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RestartAlt,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Yo'riqnomani ochish", color = CyberCyan)
                    }

                    OutlinedButton(
                        onClick = onClearLogs,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("settings_clear_logs"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.55f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = null,
                            tint = ThreatCrimson,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Jurnalni tozalash", color = ThreatCrimson)
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun PermissionWizardItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    granted: Boolean,
    testTag: String,
    onAction: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (granted) ShieldEmerald.copy(alpha = 0.45f) else CyberOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (granted) ShieldEmerald else CyberCyan,
                    modifier = Modifier.size(22.dp)
                )
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    StatusBadgePill(
                        text = if (granted) "Ruxsat berilgan" else "Sozlash kerak",
                        accentColor = if (granted) ShieldEmerald else WarningAmber,
                        containerColor = if (granted) ShieldEmeraldContainer else WarningAmberContainer
                    )
                }
            }

            Button(
                onClick = onAction,
                modifier = Modifier
                    .height(48.dp)
                    .testTag(testTag),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (granted) ShieldEmeraldContainer else CyberCyan,
                    contentColor = if (granted) ShieldEmerald else CyberNavyBg
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (granted) "Holat" else "Yoqish",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = CyberTextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberNavyBg,
                checkedTrackColor = CyberCyan
            )
        )
    }
}

@Composable
private fun BatteryDiagnosticCard(
    isExcluded: Boolean,
    isFileObserverReady: Boolean,
    onRecheck: () -> Unit,
    onOpenBatterySettings: () -> Unit
) {
    val accent = if (isExcluded) ShieldEmerald else WarningAmber
    val container = if (isExcluded) ShieldEmeraldContainer else WarningAmberContainer

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.BatteryChargingFull,
                        contentDescription = "Batareya optimizatsiyasi diagnostikasi",
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "Batareya optimizatsiyasi",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                StatusBadgePill(
                    text = if (isExcluded) "Istisno qilingan" else "Cheklangan",
                    accentColor = accent,
                    containerColor = container
                )
            }

            Text(
                text = if (isExcluded) {
                    "Ilova Android batareya cheklovidan ozod qilingan. Fon FileObserver xizmati Telegram va Yuklanmalar papkasini uzluksiz kuzatishda davom etadi."
                } else {
                    "Android tizimi fon jarayonlarini uyqu rejimiga o'tkazishi mumkin. FileObserver 24/7 faol qolishi uchun Qalqon AI ni batareya cheklovidan chiqaring."
                },
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )

            Text(
                text = if (isFileObserverReady && isExcluded) {
                    "Diagnostika: FileObserver himoyasi barqaror (24/7 tayyor)"
                } else if (!isFileObserverReady) {
                    "Diagnostika: Barcha fayllarga ruxsat yoki APK avto-skaneri faol emas"
                } else {
                    "Diagnostika: Batareya istisnosini yoqish tavsiya etiladi"
                },
                style = MaterialTheme.typography.labelMedium,
                color = accent
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onRecheck,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_battery_recheck_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Tekshirish", color = CyberCyan)
                }

                Button(
                    onClick = onOpenBatterySettings,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_battery_open_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isExcluded) ShieldEmeraldContainer else CyberCyan,
                        contentColor = if (isExcluded) ShieldEmerald else CyberNavyBg
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (isExcluded) "Sozlamalar" else "Istisno qilish",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun PeriodicAppAuditCard(
    isEnabled: Boolean,
    lastAuditTimestamp: Long,
    lastAuditSummaryUz: String,
    isRunning: Boolean,
    onToggle: (Boolean) -> Unit,
    onRunNow: () -> Unit
) {
    val formattedLastRun = remember(lastAuditTimestamp) {
        if (lastAuditTimestamp <= 0L) {
            "Hali ishga tushmagan"
        } else {
            SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(lastAuditTimestamp))
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("settings_periodic_audit_card"),
        color = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (isEnabled) CyberCyan.copy(alpha = 0.45f) else CyberOutline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Schedule,
                        contentDescription = "WorkManager davriy tekshiruvi",
                        tint = if (isEnabled) CyberCyan else CyberTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "Ilovalar davriy auditi",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Har 6 soatda WorkManager orqali",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextSecondary
                        )
                    }
                }
                Switch(
                    checked = isEnabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("settings_switch_periodic_audit"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberNavyBg,
                        checkedTrackColor = CyberCyan
                    )
                )
            }

            Text(
                text = "Yangi o'rnatilgan ilovalarning APK ruxsatlari va nomini fonda yengil tekshiradi; zararli APK aniqlansa darhol bildirishnoma yuboradi.",
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadgePill(
                    text = if (isEnabled) "WorkManager Rejalashtirilgan" else "To'xtatilgan",
                    accentColor = if (isEnabled) ShieldEmerald else WarningAmber,
                    containerColor = if (isEnabled) ShieldEmeraldContainer else WarningAmberContainer
                )
                Text(
                    text = formattedLastRun,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan
                )
            }

            if (lastAuditSummaryUz.isNotBlank()) {
                Text(
                    text = lastAuditSummaryUz,
                    style = MaterialTheme.typography.labelMedium,
                    color = CyberTextPrimary
                )
            }

            OutlinedButton(
                onClick = onRunNow,
                enabled = !isRunning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_run_audit_now_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
            ) {
                if (isRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = CyberCyan,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Tekshirilmoqda...", color = CyberCyan)
                } else {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Yangi ilovalarni hozir tekshirish", color = CyberCyan)
                }
            }
        }
    }
}

@Composable
private fun GeminiApiKeyCard(
    currentKey: String,
    testState: ApiKeyTestUiState,
    onSaveKey: (String) -> Unit,
    onTestKey: (String) -> Unit
) {
    var apiKeyInput by remember(currentKey) { mutableStateOf(currentKey) }
    var isKeyVisible by remember { mutableStateOf(false) }

    LaunchedEffect(currentKey) {
        if (apiKeyInput != currentKey && apiKeyInput.isBlank()) {
            apiKeyInput = currentKey
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("settings_gemini_api_card"),
        color = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Key,
                    contentDescription = "Gemini AI API Kaliti",
                    tint = CyberCyan,
                    modifier = Modifier.size(22.dp)
                )
                Column {
                    Text(
                        text = "Gemini AI API Kaliti",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "To'g'ridan-to'g'ri Gemini REST API (internet bo'lmasa oflayn dvigatel ishlaydi)",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                }
            }

            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_gemini_api_key_input"),
                label = { Text("Gemini API Kaliti") },
                singleLine = true,
                visualTransformation = if (isKeyVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    IconButton(
                        onClick = { isKeyVisible = !isKeyVisible },
                        modifier = Modifier.testTag("settings_toggle_api_key_visibility")
                    ) {
                        Icon(
                            imageVector = if (isKeyVisible) {
                                Icons.Filled.VisibilityOff
                            } else {
                                Icons.Filled.Visibility
                            },
                            contentDescription = if (isKeyVisible) "Kalitni yashirish" else "Kalitni ko'rsatish",
                            tint = CyberCyan
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CyberOutline,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary,
                    focusedLabelColor = CyberCyan,
                    unfocusedLabelColor = CyberTextSecondary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { onSaveKey(apiKeyInput) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("settings_save_gemini_key_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
                ) {
                    Text("Saqlash", color = CyberCyan)
                }

                Button(
                    onClick = { onTestKey(apiKeyInput) },
                    enabled = testState !is ApiKeyTestUiState.Testing,
                    modifier = Modifier
                        .weight(1.4f)
                        .height(48.dp)
                        .testTag("settings_test_gemini_key_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = CyberNavyBg
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (testState is ApiKeyTestUiState.Testing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = CyberNavyBg,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("Tekshirilmoqda...")
                    } else {
                        Text(
                            text = "API Kalitni Tekshirish",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            when (testState) {
                is ApiKeyTestUiState.Success -> {
                    Surface(
                        color = ShieldEmeraldContainer,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Muvaffaqiyatli",
                                tint = ShieldEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = testState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = ShieldEmerald
                            )
                        }
                    }
                }
                is ApiKeyTestUiState.Error -> {
                    Surface(
                        color = ThreatCrimsonContainer,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = "Xatolik",
                                tint = ThreatCrimson,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = testState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = ThreatCrimson
                            )
                        }
                    }
                }
                else -> Unit
            }
        }
    }
}
