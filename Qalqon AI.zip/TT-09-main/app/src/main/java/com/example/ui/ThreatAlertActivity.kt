package com.example.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.security.PermissionHelper
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.QalqonAITheme
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import java.io.File

class ThreatAlertActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val alertType = intent.getStringExtra(EXTRA_ALERT_TYPE) ?: TYPE_APK
        val targetName = intent.getStringExtra(EXTRA_TARGET_NAME).orEmpty()
        val targetPath = intent.getStringExtra(EXTRA_TARGET_PATH).orEmpty()
        val reason = intent.getStringExtra(EXTRA_REASON).orEmpty()
        val indicators = intent.getStringExtra(EXTRA_INDICATORS).orEmpty()
        val recommendation = intent.getStringExtra(EXTRA_RECOMMENDATION).orEmpty()

        setContent {
            QalqonAITheme {
                ThreatAlertScreen(
                    isApkAlert = alertType == TYPE_APK,
                    targetName = targetName,
                    targetPath = targetPath,
                    reason = reason,
                    indicators = indicators,
                    recommendation = recommendation,
                    onDeleteOrBlock = {
                        if (alertType == TYPE_APK) {
                            val deleted = runCatching {
                                val f = File(targetPath)
                                f.exists() && f.isFile && f.delete()
                            }.getOrDefault(false)

                            if (deleted) {
                                Toast.makeText(
                                    this,
                                    "Zararli fayl qurilmadan o'chirildi!",
                                    Toast.LENGTH_LONG
                                ).show()
                                finish()
                            } else {
                                Toast.makeText(
                                    this,
                                    "Faylni Yuklanmalar/Telegram papkasidan o'chiring va o'rnatmang!",
                                    Toast.LENGTH_LONG
                                ).show()
                                if (targetPath.contains('.') && !targetPath.contains('/')) {
                                    startActivity(PermissionHelper.createAppDetailsIntent(this))
                                }
                                finish()
                            }
                        } else {
                            finish()
                        }
                    },
                    onDismissSafe = { finish() }
                )
            }
        }
    }

    companion object {
        private const val EXTRA_ALERT_TYPE = "extra_alert_type"
        private const val EXTRA_TARGET_NAME = "extra_target_name"
        private const val EXTRA_TARGET_PATH = "extra_target_path"
        private const val EXTRA_REASON = "extra_reason"
        private const val EXTRA_INDICATORS = "extra_indicators"
        private const val EXTRA_RECOMMENDATION = "extra_recommendation"

        private const val TYPE_APK = "APK"
        private const val TYPE_SOCIAL = "SOCIAL"

        fun createApkAlertIntent(
            context: Context,
            fileName: String,
            filePath: String,
            reason: String,
            indicators: String,
            recommendation: String
        ): Intent {
            return Intent(context, ThreatAlertActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(EXTRA_ALERT_TYPE, TYPE_APK)
                putExtra(EXTRA_TARGET_NAME, fileName)
                putExtra(EXTRA_TARGET_PATH, filePath)
                putExtra(EXTRA_REASON, reason)
                putExtra(EXTRA_INDICATORS, indicators)
                putExtra(EXTRA_RECOMMENDATION, recommendation)
            }
        }

        fun launchApkAlert(
            context: Context,
            fileName: String,
            filePath: String,
            reason: String,
            indicators: String,
            recommendation: String
        ) {
            context.startActivity(
                createApkAlertIntent(
                    context = context,
                    fileName = fileName,
                    filePath = filePath,
                    reason = reason,
                    indicators = indicators,
                    recommendation = recommendation
                )
            )
        }

        fun createSocialAlertIntent(
            context: Context,
            platformName: String,
            reason: String
        ): Intent {
            return Intent(context, ThreatAlertActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(EXTRA_ALERT_TYPE, TYPE_SOCIAL)
                putExtra(EXTRA_TARGET_NAME, platformName)
                putExtra(EXTRA_TARGET_PATH, platformName)
                putExtra(EXTRA_REASON, reason)
                putExtra(
                    EXTRA_INDICATORS,
                    "Like, Share, Save va Izoh yozish harakatlari vaqtincha bloklandi"
                )
                putExtra(
                    EXTRA_RECOMMENDATION,
                    "Xavfsizlik uchun ushbu sahifadan chiqing va shubhali kanallarni tark eting."
                )
            }
        }

        fun launchSocialAlert(
            context: Context,
            platformName: String,
            reason: String
        ) {
            context.startActivity(
                createSocialAlertIntent(
                    context = context,
                    platformName = platformName,
                    reason = reason
                )
            )
        }
    }
}

@Composable
private fun ThreatAlertScreen(
    isApkAlert: Boolean,
    targetName: String,
    targetPath: String,
    reason: String,
    indicators: String,
    recommendation: String,
    onDeleteOrBlock: () -> Unit,
    onDismissSafe: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "threat_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ThreatCrimsonContainer, CyberNavyBg, CyberNavyBg)
                )
            )
            .safeDrawingPadding()
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .size(104.dp)
                    .scale(pulseScale)
                    .background(ThreatCrimson.copy(alpha = 0.2f), CircleShape)
                    .border(2.dp, ThreatCrimson, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isApkAlert) Icons.Filled.GppBad else Icons.Filled.Warning,
                    contentDescription = "Kritik xavf belgisi",
                    tint = ThreatCrimson,
                    modifier = Modifier.size(54.dp)
                )
            }

            Surface(
                color = ThreatCrimson.copy(alpha = 0.16f),
                shape = RoundedCornerShape(999.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.6f))
            ) {
                Text(
                    text = "QALQON AI • KRITIK OGOHLANTIRISH",
                    style = MaterialTheme.typography.labelMedium,
                    color = ThreatCrimson,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Text(
                text = if (isApkAlert) {
                    "XAVF! Zararli fayl aniqlandi!"
                } else {
                    "Bu kontent xavfsiz emas va bloklandi"
                },
                style = MaterialTheme.typography.headlineMedium,
                color = CyberTextPrimary,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CyberSurface,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.45f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (isApkAlert) "Aniqlangan fayl:" else "Platforma:",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberTextSecondary
                    )
                    Text(
                        text = targetName.ifBlank { "Noma'lum obyekt" },
                        style = MaterialTheme.typography.titleMedium,
                        color = ThreatCrimson,
                        fontWeight = FontWeight.Bold
                    )

                    if (targetPath.isNotBlank() && targetPath != targetName) {
                        Text(
                            text = targetPath,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextSecondary
                        )
                    }

                    Text(
                        text = "Sabab:",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberTextSecondary
                    )
                    Text(
                        text = reason.ifBlank { "Xavfli xatti-harakat aniqlandi." },
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberTextPrimary
                    )

                    if (indicators.isNotBlank()) {
                        Text(
                            text = "Shubhali alomatlar / Ruxsatlar:",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberTextSecondary
                        )
                        Text(
                            text = indicators,
                            style = MaterialTheme.typography.labelMedium,
                            color = ThreatCrimson
                        )
                    }

                    if (recommendation.isNotBlank()) {
                        Surface(
                            color = CyberNavyBg.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Shield,
                                    contentDescription = "Tavsiya",
                                    tint = CyberCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = recommendation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextPrimary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onDeleteOrBlock,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("alert_primary_action_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ThreatCrimson,
                    contentColor = CyberTextPrimary
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = if (isApkAlert) Icons.Filled.DeleteForever else Icons.Filled.Shield,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = if (isApkAlert) "Faylni o'chirish va bloklash" else "Xavfsiz joyga qaytish",
                    style = MaterialTheme.typography.labelLarge
                )
            }

            OutlinedButton(
                onClick = onDismissSafe,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("alert_dismiss_button"),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "Yopish",
                    color = CyberCyan,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
