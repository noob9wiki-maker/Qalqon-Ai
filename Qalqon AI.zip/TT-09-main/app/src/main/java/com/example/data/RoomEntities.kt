package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "threat_logs",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["sourceType"]),
        Index(value = ["threatLevel"])
    ]
)
data class ThreatLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val sourceType: String,
    val title: String,
    val targetName: String,
    val packageNameOrPath: String,
    val threatLevel: String,
    val reasonUz: String,
    val detectedIndicators: String,
    val aiExplanation: String,
    val actionTaken: String
)

@Entity(tableName = "keyword_rules")
data class KeywordRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val keyword: String,
    val language: String,
    val category: String,
    val isEnabled: Boolean = true,
    val isSystemDefault: Boolean = false
)

@Entity(tableName = "protected_accounts")
data class ProtectedAccountEntity(
    @PrimaryKey val platform: String,
    val handleOrLabel: String,
    val protectionActive: Boolean,
    val sessionMonitorMethod: String,
    val oauthConnected: Boolean,
    val blockedCount: Int,
    val lastCheckedAt: Long,
    val securityScore: Int
)

@Entity(tableName = "whitelist_entries")
data class WhitelistEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val value: String,
    val entryType: String,
    val noteUz: String = "",
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "scanned_files",
    indices = [
        Index(value = ["scannedAt"]),
        Index(value = ["status"])
    ]
)
data class ScannedFileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val packageName: String? = null,
    val filePathOrUri: String,
    val fileSizeBytes: Long = 0L,
    val sha256: String? = null,
    val status: String, // "SAFE" or "MALICIOUS"
    val riskLevel: String, // "SAFE", "SUSPICIOUS", or "CRITICAL"
    val scanSource: String = "APK_SCANNER",
    val summaryUz: String,
    val aiCategory: String? = null,
    val aiConfidencePercent: Int? = null,
    val scannedAt: Long = System.currentTimeMillis()
)
