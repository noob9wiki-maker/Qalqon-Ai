package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.DailyScanStatPoint
import com.example.data.OverviewRange
import com.example.data.SecurityOverviewSummary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import kotlin.math.roundToInt

@Composable
fun SecurityOverviewDashboardCard(
    summary: SecurityOverviewSummary,
    onSelectRange: (OverviewRange) -> Unit,
    onOpenFullOverview: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_security_overview_card"),
        color = CyberSurface,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Analytics,
                        contentDescription = "Xavfsizlik Ko'rinishi",
                        tint = CyberCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "Xavfsizlik Ko'rinishi",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Kunlik bloklangan tahdidlar va toza fayllar dinamikasi",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }
                TextButton(
                    onClick = onOpenFullOverview,
                    modifier = Modifier.testTag("home_open_security_overview_button")
                ) {
                    Text("Batafsil", color = CyberCyan)
                    Spacer(modifier = Modifier.size(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Batafsil ko'rish",
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(OverviewRange.DAYS_7, OverviewRange.DAYS_14).forEach { range ->
                        FilterChip(
                            selected = summary.range == range,
                            onClick = { onSelectRange(range) },
                            label = { Text(range.labelUz) },
                            modifier = Modifier.testTag("overview_home_range_${range.days}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyanContainer,
                                selectedLabelColor = CyberCyan,
                                labelColor = CyberTextSecondary
                            )
                        )
                    }
                }

                StatusBadgePill(
                    text = "Tozalik: ${summary.safetyRatePercent}%",
                    accentColor = if (summary.totalBlockedThreats == 0) ShieldEmerald else CyberCyan,
                    containerColor = if (summary.totalBlockedThreats == 0) ShieldEmeraldContainer else CyberCyanContainer
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(
                            text = "Toza fayllar",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextSecondary
                        )
                        Text(
                            text = "${summary.totalCleanFiles} ta",
                            style = MaterialTheme.typography.titleMedium,
                            color = ShieldEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Surface(
                    modifier = Modifier.weight(1f),
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(
                            text = "Bloklangan tahdidlar",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextSecondary
                        )
                        Text(
                            text = "${summary.totalBlockedThreats} ta",
                            style = MaterialTheme.typography.titleMedium,
                            color = ThreatCrimson,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            DailyScanTrendChart(
                summary = summary,
                chartHeight = 190.dp
            )
        }
    }
}

@Composable
fun DailyScanTrendChart(
    summary: SecurityOverviewSummary,
    modifier: Modifier = Modifier,
    chartHeight: Dp = 220.dp
) {
    val points = summary.points
    if (points.isEmpty()) return

    var selectedIndex by remember(points.size) {
        mutableIntStateOf((points.size - 1).coerceAtLeast(0))
    }
    val safeSelectedIndex = selectedIndex.coerceIn(0, points.lastIndex)
    val selectedPoint = points[safeSelectedIndex]

    var startAnimation by remember(summary.range) { mutableStateOf(false) }
    LaunchedEffect(summary.range, summary.totalScannedEvents) {
        startAnimation = true
    }
    val drawProgress by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "trend_line_reveal"
    )

    val maxCount = remember(points) {
        val rawMax = points.maxOf { maxOf(it.cleanFilesCount, it.totalBlockedThreatsCount) }
        maxOf(rawMax, 3)
    }

    val ySteps = remember(maxCount) {
        val top = if (maxCount % 3 == 0) maxCount else maxCount + (3 - (maxCount % 3))
        listOf(top, (top * 2) / 3, top / 3, 0)
    }
    val yMax = ySteps.first().toFloat().coerceAtLeast(1f)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Legend + Interactive Day Readout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChartLegendItem(label = "Toza fayllar", color = ShieldEmerald)
                ChartLegendItem(label = "Bloklangan tahdidlar", color = ThreatCrimson)
            }
            Text(
                text = selectedPoint.fullDateLabel,
                style = MaterialTheme.typography.labelSmall,
                color = CyberCyan,
                fontWeight = FontWeight.SemiBold
            )
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberSurfaceElevated.copy(alpha = 0.75f),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, CyberOutline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Kunlik ko'rsatkich (${selectedPoint.shortDateLabel}):",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Toza: ${selectedPoint.cleanFilesCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = ShieldEmerald,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Tahdid: ${selectedPoint.totalBlockedThreatsCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = ThreatCrimson,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Chart Canvas + Axes
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(chartHeight)
                .background(CyberNavyBg.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(start = 6.dp, end = 12.dp, top = 12.dp, bottom = 10.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                // Y-Axis Labels
                Column(
                    modifier = Modifier
                        .padding(end = 8.dp, bottom = 22.dp)
                        .height(chartHeight - 44.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.End
                ) {
                    ySteps.forEach { tick ->
                        Text(
                            text = tick.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextMuted
                        )
                    }
                }

                // Plot Area + X-Axis Labels
                Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("security_overview_trend_canvas")
                                .pointerInput(points) {
                                    detectTapGestures { offset ->
                                        if (points.size > 1 && size.width > 0) {
                                            val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                            selectedIndex = (fraction * (points.size - 1)).roundToInt()
                                        }
                                    }
                                }
                                .pointerInput(points) {
                                    detectHorizontalDragGestures { change, _ ->
                                        change.consume()
                                        if (points.size > 1 && size.width > 0) {
                                            val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                            selectedIndex = (fraction * (points.size - 1)).roundToInt()
                                        }
                                    }
                                }
                        ) {
                            val w = size.width
                            val h = size.height
                            if (w <= 0f || h <= 0f) return@Canvas

                            val gridLinesCount = 3
                            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                            for (i in 0..gridLinesCount) {
                                val y = (h / gridLinesCount) * i
                                drawLine(
                                    color = CyberOutline.copy(alpha = 0.65f),
                                    start = Offset(0f, y),
                                    end = Offset(w, y),
                                    strokeWidth = 1.dp.toPx(),
                                    pathEffect = if (i == gridLinesCount) null else dashEffect
                                )
                            }

                            val stepX = if (points.size > 1) w / (points.size - 1).toFloat() else 0f

                            fun pointOffset(index: Int, value: Int): Offset {
                                val x = if (points.size > 1) index * stepX else w / 2f
                                val ratio = (value.toFloat() / yMax).coerceIn(0f, 1f)
                                val y = h - (ratio * (h - 6.dp.toPx())) - 3.dp.toPx()
                                return Offset(x, y)
                            }

                            val cleanOffsets = points.mapIndexed { idx, p -> pointOffset(idx, p.cleanFilesCount) }
                            val threatOffsets = points.mapIndexed { idx, p -> pointOffset(idx, p.totalBlockedThreatsCount) }

                            // Selected Day Vertical Crosshair
                            val selectedX = cleanOffsets[safeSelectedIndex].x
                            drawLine(
                                color = CyberCyan.copy(alpha = 0.45f),
                                start = Offset(selectedX, 0f),
                                end = Offset(selectedX, h),
                                strokeWidth = 1.5.dp.toPx(),
                                pathEffect = dashEffect
                            )

                            clipRect(right = w * drawProgress) {
                                drawTrendSeries(
                                    offsets = cleanOffsets,
                                    chartBottomY = h,
                                    lineColor = ShieldEmerald,
                                    fillColor = ShieldEmerald.copy(alpha = 0.22f)
                                )
                                drawTrendSeries(
                                    offsets = threatOffsets,
                                    chartBottomY = h,
                                    lineColor = ThreatCrimson,
                                    fillColor = ThreatCrimson.copy(alpha = 0.24f)
                                )
                            }

                            // Highlight selected day nodes
                            val selectedClean = cleanOffsets[safeSelectedIndex]
                            val selectedThreat = threatOffsets[safeSelectedIndex]

                            drawCircle(
                                color = ShieldEmerald.copy(alpha = 0.28f),
                                radius = 9.dp.toPx(),
                                center = selectedClean
                            )
                            drawCircle(
                                color = ShieldEmerald,
                                radius = 5.dp.toPx(),
                                center = selectedClean
                            )

                            drawCircle(
                                color = ThreatCrimson.copy(alpha = 0.30f),
                                radius = 9.dp.toPx(),
                                center = selectedThreat
                            )
                            drawCircle(
                                color = ThreatCrimson,
                                radius = 5.dp.toPx(),
                                center = selectedThreat
                            )
                        }

                        if (!summary.hasAnyActivity) {
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .padding(horizontal = 16.dp),
                                color = CyberSurface.copy(alpha = 0.92f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, CyberOutline)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.ShowChart,
                                        contentDescription = null,
                                        tint = CyberCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Fayl skanerlanganda kunlik chiziqli grafik shu yerda jonlanadi.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // X-Axis Labels (spaced so multi-week views never overlap)
                    val labelIndices = remember(points.size) {
                        when {
                            points.size <= 7 -> points.indices.toList()
                            points.size <= 14 -> listOf(0, 3, 6, 9, 13).filter { it < points.size }
                            else -> listOf(0, 7, 14, 21, points.lastIndex).distinct()
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        labelIndices.forEach { idx ->
                            val isSelected = idx == safeSelectedIndex
                            Text(
                                text = points[idx].shortDateLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) CyberCyan else CyberTextMuted,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTrendSeries(
    offsets: List<Offset>,
    chartBottomY: Float,
    lineColor: Color,
    fillColor: Color
) {
    if (offsets.isEmpty()) return

    val linePath = Path().apply {
        moveTo(offsets.first().x, offsets.first().y)
        for (i in 0 until offsets.lastIndex) {
            val current = offsets[i]
            val next = offsets[i + 1]
            val midX = (current.x + next.x) / 2f
            cubicTo(
                midX, current.y,
                midX, next.y,
                next.x, next.y
            )
        }
    }

    val fillPath = Path().apply {
        addPath(linePath)
        lineTo(offsets.last().x, chartBottomY)
        lineTo(offsets.first().x, chartBottomY)
        close()
    }

    drawPath(
        path = fillPath,
        brush = Brush.verticalGradient(
            colors = listOf(fillColor, Color.Transparent),
            startY = 0f,
            endY = chartBottomY
        )
    )

    drawPath(
        path = linePath,
        color = lineColor,
        style = Stroke(
            width = 2.6.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )

    offsets.forEach { pt ->
        drawCircle(
            color = CyberNavyBg,
            radius = 4.dp.toPx(),
            center = pt
        )
        drawCircle(
            color = lineColor,
            radius = 2.6.dp.toPx(),
            center = pt
        )
    }
}

@Composable
private fun ChartLegendItem(
    label: String,
    color: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .background(color, CircleShape)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = CyberTextPrimary
        )
    }
}
