package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface QalqonDao {
    @Query("SELECT * FROM threat_logs ORDER BY timestamp DESC")
    fun observeThreatLogs(): Flow<List<ThreatLogEntity>>

    @Query("SELECT * FROM threat_logs WHERE sourceType = :sourceType ORDER BY timestamp DESC")
    fun observeThreatLogsBySource(sourceType: String): Flow<List<ThreatLogEntity>>

    @Query("SELECT COUNT(*) FROM threat_logs WHERE threatLevel != 'SAFE'")
    fun observeBlockedThreatsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM threat_logs WHERE sourceType = 'APK_SCAN' AND threatLevel != 'SAFE'")
    fun observeBlockedApkCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM threat_logs WHERE sourceType = 'SOCIAL_GUARD' AND threatLevel != 'SAFE'")
    fun observeBlockedSocialCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertThreatLog(log: ThreatLogEntity): Long

    @Query("DELETE FROM threat_logs WHERE id = :id")
    suspend fun deleteThreatLogById(id: Long)

    @Query("DELETE FROM threat_logs")
    suspend fun clearThreatLogs()

    @Query("SELECT * FROM keyword_rules ORDER BY isSystemDefault ASC, id DESC")
    fun observeKeywordRules(): Flow<List<KeywordRuleEntity>>

    @Query("SELECT * FROM keyword_rules WHERE isEnabled = 1")
    suspend fun getEnabledKeywordRules(): List<KeywordRuleEntity>

    @Query("SELECT * FROM keyword_rules WHERE LOWER(keyword) = LOWER(:keyword) LIMIT 1")
    suspend fun findKeywordRuleByKeyword(keyword: String): KeywordRuleEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertKeywordRules(rules: List<KeywordRuleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKeywordRule(rule: KeywordRuleEntity): Long

    @Update
    suspend fun updateKeywordRule(rule: KeywordRuleEntity)

    @Query("DELETE FROM keyword_rules WHERE id = :id")
    suspend fun deleteKeywordRule(id: Long)

    @Query("SELECT * FROM protected_accounts ORDER BY platform ASC")
    fun observeProtectedAccounts(): Flow<List<ProtectedAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProtectedAccounts(accounts: List<ProtectedAccountEntity>)

    @Update
    suspend fun updateProtectedAccount(account: ProtectedAccountEntity)

    @Query("UPDATE protected_accounts SET blockedCount = blockedCount + 1, lastCheckedAt = :timestamp WHERE platform = :platform")
    suspend fun incrementAccountBlockedCount(platform: String, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM protected_accounts")
    suspend fun getAccountsCount(): Int

    @Query("SELECT COUNT(*) FROM keyword_rules")
    suspend fun getKeywordRulesCount(): Int

    @Query("SELECT * FROM whitelist_entries ORDER BY addedAt DESC")
    fun observeWhitelistEntries(): Flow<List<WhitelistEntryEntity>>

    @Query("SELECT * FROM whitelist_entries")
    suspend fun getAllWhitelistEntries(): List<WhitelistEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWhitelistEntry(entry: WhitelistEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertWhitelistEntries(entries: List<WhitelistEntryEntity>)

    @Query("DELETE FROM whitelist_entries WHERE id = :id")
    suspend fun deleteWhitelistEntry(id: Long)

    @Query("SELECT COUNT(*) FROM whitelist_entries")
    suspend fun getWhitelistCount(): Int

    @Query("SELECT * FROM scanned_files ORDER BY scannedAt DESC")
    fun observeScannedFiles(): Flow<List<ScannedFileEntity>>

    @Query("SELECT * FROM scanned_files WHERE status = :status ORDER BY scannedAt DESC")
    fun observeScannedFilesByStatus(status: String): Flow<List<ScannedFileEntity>>

    @Query("SELECT COUNT(*) FROM scanned_files WHERE status = 'MALICIOUS'")
    fun observeMaliciousScannedFilesCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScannedFile(file: ScannedFileEntity): Long

    @Query("DELETE FROM scanned_files WHERE id = :id")
    suspend fun deleteScannedFileById(id: Long)

    @Query("DELETE FROM scanned_files")
    suspend fun clearScannedFiles()
}
