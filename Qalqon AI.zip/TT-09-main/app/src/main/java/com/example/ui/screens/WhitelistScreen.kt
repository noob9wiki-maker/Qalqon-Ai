package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.WhitelistEntryEntity
import com.example.data.WhitelistType
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WhitelistScreen(
    entries: List<WhitelistEntryEntity>,
    onAddEntry: (String, WhitelistType, String) -> Unit,
    onDeleteEntry: (Long) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var selectedAddType by rememberSaveable { mutableStateOf(WhitelistType.PACKAGE_NAME) }
    var valueInput by rememberSaveable { mutableStateOf("") }
    var noteInput by rememberSaveable { mutableStateOf("") }
    var filterType by rememberSaveable { mutableStateOf<String>("ALL") }

    val filteredEntries = entries.filter { entry ->
        filterType == "ALL" || entry.entryType == filterType
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VerifiedUser,
                                contentDescription = "Oq ro'yxat",
                                tint = ShieldEmerald
                            )
                            Text(
                                text = "Oq ro'yxat (Ishonchli manbalar)",
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "Oq ro'yxatga qo'shilgan APK fayllar, ilova paketlari va rasmiy ijtimoiy tarmoq kanallari Qalqon AI tomonidan bloklanmaydi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Yangi ishonchli manba qo'shish",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            WhitelistType.entries.forEach { type ->
                                FilterChip(
                                    selected = selectedAddType == type,
                                    onClick = { selectedAddType = type },
                                    label = { Text(type.labelUz) },
                                    modifier = Modifier.testTag("whitelist_add_type_${type.name.lowercase()}"),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyanContainer,
                                        selectedLabelColor = CyberCyan,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                        }

                        OutlinedTextField(
                            value = valueInput,
                            onValueChange = { valueInput = it },
                            placeholder = { Text(selectedAddType.hintUz, color = CyberTextSecondary) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("whitelist_value_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CyberOutline,
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary
                            )
                        )

                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            placeholder = { Text("Izoh (ixtiyoriy, masalan: Ishxonadagi dastur)", color = CyberTextSecondary) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("whitelist_note_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CyberOutline,
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary
                            )
                        )

                        Button(
                            onClick = {
                                onAddEntry(valueInput, selectedAddType, noteInput)
                                valueInput = ""
                                noteInput = ""
                            },
                            enabled = valueInput.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("whitelist_add_submit_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ShieldEmerald,
                                contentColor = CyberNavyBg
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AddModerator,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(
                                text = "Oq ro'yxatga qo'shish",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Saqlangan yozuvlar (${filteredEntries.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = filterType == "ALL",
                        onClick = { filterType = "ALL" },
                        label = { Text("Barchasi") },
                        modifier = Modifier.testTag("whitelist_filter_all"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyanContainer,
                            selectedLabelColor = CyberCyan,
                            labelColor = CyberTextSecondary
                        )
                    )
                    WhitelistType.entries.forEach { type ->
                        FilterChip(
                            selected = filterType == type.name,
                            onClick = { filterType = type.name },
                            label = { Text(type.labelUz) },
                            modifier = Modifier.testTag("whitelist_filter_${type.name.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyanContainer,
                                selectedLabelColor = CyberCyan,
                                labelColor = CyberTextSecondary
                            )
                        )
                    }
                }
            }

            if (filteredEntries.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = CyberSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CyberOutline)
                    ) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Bu toifada hozircha yozuv yo'q",
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary
                            )
                            Text(
                                text = "Yuqoridagi shakl orqali ishonchli fayl yoki ilova qo'shing.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(filteredEntries, key = { it.id }) { entry ->
                    WhitelistEntryCard(
                        entry = entry,
                        onDelete = { onDeleteEntry(entry.id) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun WhitelistEntryCard(
    entry: WhitelistEntryEntity,
    onDelete: () -> Unit
) {
    val type = runCatching { WhitelistType.valueOf(entry.entryType) }
        .getOrDefault(WhitelistType.PACKAGE_NAME)
    val icon = when (type) {
        WhitelistType.APK_FILE -> Icons.Filled.Description
        WhitelistType.PACKAGE_NAME -> Icons.Filled.Apps
        WhitelistType.SOCIAL_CHANNEL -> Icons.Filled.Public
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurfaceElevated,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    color = ShieldEmeraldContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = type.labelUz,
                        tint = ShieldEmerald,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = entry.value,
                        style = MaterialTheme.typography.titleSmall,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    if (entry.noteUz.isNotBlank()) {
                        Text(
                            text = entry.noteUz,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                    StatusBadgePill(
                        text = type.labelUz,
                        accentColor = ShieldEmerald,
                        containerColor = ShieldEmeraldContainer
                    )
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("whitelist_delete_${entry.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Oq ro'yxatdan o'chirish",
                    tint = ThreatCrimson
                )
            }
        }
    }
}
