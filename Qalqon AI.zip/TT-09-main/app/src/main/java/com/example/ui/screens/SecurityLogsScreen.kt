package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.LogSourceType
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import com.example.data.WhitelistType
import com.example.ui.components.CyberMetricCard
import com.example.ui.components.ThreatLogCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SecurityLogsScreen(
    logs: List<ThreatLogEntity>,
    blockedApkCount: Int,
    blockedSocialCount: Int,
    onDeleteLog: (Long) -> Unit,
    onClearAllLogs: () -> Unit,
    onAddToWhitelist: (String, WhitelistType) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedFilter by rememberSaveable { mutableStateOf("ALL") }
    var showClearConfirm by rememberSaveable { mutableStateOf(false) }

    val filteredLogs = logs.filter { log ->
        val matchesFilter = when (selectedFilter) {
            "APK" -> log.sourceType == LogSourceType.APK_SCAN.name
            "SOCIAL" -> log.sourceType == LogSourceType.SOCIAL_GUARD.name
            "CRITICAL" -> log.threatLevel == ThreatLevel.CRITICAL.name
            else -> true
        }
        val query = searchQuery.trim().lowercase()
        val matchesQuery = query.isEmpty() ||
            log.title.lowercase().contains(query) ||
            log.targetName.lowercase().contains(query) ||
            log.reasonUz.lowercase().contains(query) ||
            log.detectedIndicators.lowercase().contains(query)

        matchesFilter && matchesQuery
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = CyberSurface,
            title = {
                Text(
                    text = "Jurnalni tozalash",
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Barcha saqlangan xavfsizlik hodisalari tarixi o'chiriladi. Davom etasizmi?",
                    color = CyberTextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearAllLogs()
                        showClearConfirm = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = ThreatCrimson)
                ) {
                    Text("O'chirish")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showClearConfirm = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = CyberCyan)
                ) {
                    Text("Bekor qilish")
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CyberMetricCard(
                        label = "Bloklangan APK lar",
                        value = blockedApkCount.toString(),
                        icon = Icons.Filled.BugReport,
                        accentColor = if (blockedApkCount > 0) ThreatCrimson else CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    CyberMetricCard(
                        label = "Ijtimoiy tahdidlar",
                        value = blockedSocialCount.toString(),
                        icon = Icons.Filled.Public,
                        accentColor = if (blockedSocialCount > 0) WarningAmber else ShieldEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    CyberMetricCard(
                        label = "Jami yozuvlar",
                        value = logs.size.toString(),
                        icon = Icons.Filled.Security,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Qidirish",
                            tint = CyberCyan
                        )
                    },
                    placeholder = {
                        Text(
                            text = "Fayl nomi, platforma yoki sabab bo'yicha qidirish...",
                            color = CyberTextSecondary
                        )
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("security_logs_search_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CyberOutline,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hodisalar tarixi (${filteredLogs.size})",
                        style = MaterialTheme.typography.titleLarge,
                        color = CyberTextPrimary
                    )
                    if (logs.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { showClearConfirm = true },
                            modifier = Modifier.testTag("security_logs_clear_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.55f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteSweep,
                                contentDescription = null,
                                tint = ThreatCrimson,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = "Tozalash",
                                color = ThreatCrimson,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "ALL" to "Barchasi",
                        "APK" to "Zararli APK",
                        "SOCIAL" to "Ijtimoiy Tarmoqlar",
                        "CRITICAL" to "Kritik xavf"
                    ).forEach { (key, label) ->
                        FilterChip(
                            selected = selectedFilter == key,
                            onClick = { selectedFilter = key },
                            label = { Text(label) },
                            modifier = Modifier.testTag("security_logs_filter_$key"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyanContainer,
                                selectedLabelColor = CyberCyan,
                                labelColor = CyberTextSecondary
                            )
                        )
                    }
                }
            }

            if (filteredLogs.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = CyberSurface,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, CyberOutline)
                    ) {
                        Column(
                            modifier = Modifier.padding(26.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.GppGood,
                                contentDescription = "Jurnal bo'sh",
                                tint = CyberCyan,
                                modifier = Modifier.size(38.dp)
                            )
                            Text(
                                text = "Mos keluvchi xavfsizlik yozuvlari yo'q",
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Bloklangan zararli APK fayllar va ijtimoiy tarmoqlardagi tahdidlar shu yerda Room bazasida saqlanadi.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(filteredLogs, key = { it.id }) { log ->
                    val whitelistType = if (log.sourceType == LogSourceType.APK_SCAN.name) {
                        WhitelistType.APK_FILE
                    } else {
                        WhitelistType.SOCIAL_CHANNEL
                    }
                    ThreatLogCard(
                        log = log,
                        onAddToWhitelist = { onAddToWhitelist(log.targetName, whitelistType) },
                        onDeleteLog = { onDeleteLog(log.id) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}
