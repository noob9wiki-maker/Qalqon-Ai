package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.GppMaybe
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Phishing
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.NotificationPreferences
import com.example.data.PermissionStatusSnapshot
import com.example.data.ThreatNotificationCategory
import com.example.security.PermissionHelper
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NotificationSettingsScreen(
    preferences: NotificationPreferences,
    permissions: PermissionStatusSnapshot,
    onRefreshPermissions: () -> Unit,
    onToggleGeneralAlerts: (Boolean) -> Unit,
    onToggleCategory: (ThreatNotificationCategory, Boolean) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleQuietHours: (Boolean) -> Unit,
    onToggleCriticalBypass: (Boolean) -> Unit,
    onApplyPreset: (NotificationPreferences) -> Unit,
    onSendTestNotification: (ThreatNotificationCategory) -> String
) {
    val context = LocalContext.current
    var askedRationaleBefore by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            onRefreshPermissions()
            if (!granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val activity = context as? Activity
                val canAskAgain = activity != null && runCatching {
                    ActivityCompat.shouldShowRequestPermissionRationale(
                        activity,
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                }.getOrDefault(false)
                if (!askedRationaleBefore && !canAskAgain) {
                    PermissionHelper.openNotificationSettingsSafely(context)
                }
            }
        }
    )

    var selectedTestCategory by remember { mutableStateOf(ThreatNotificationCategory.PHISHING) }
    var testFeedbackMessage by remember { mutableStateOf<String?>(null) }

    val allEnabledPreset = remember {
        NotificationPreferences(
            generalAlertsEnabled = true,
            notifyPhishing = true,
            notifyMalware = true,
            notifySuspiciousBehavior = true,
            notifySocialThreats = true,
            soundEnabled = true,
            quietHoursEnabled = false,
            criticalBypassQuietHours = true
        )
    }
    val criticalOnlyPreset = remember {
        NotificationPreferences(
            generalAlertsEnabled = true,
            notifyPhishing = true,
            notifyMalware = true,
            notifySuspiciousBehavior = false,
            notifySocialThreats = false,
            soundEnabled = true,
            quietHoursEnabled = false,
            criticalBypassQuietHours = true
        )
    }
    val quietNightPreset = remember {
        NotificationPreferences(
            generalAlertsEnabled = true,
            notifyPhishing = true,
            notifyMalware = true,
            notifySuspiciousBehavior = false,
            notifySocialThreats = true,
            soundEnabled = false,
            quietHoursEnabled = true,
            criticalBypassQuietHours = true
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NotificationHeroCard(
                    preferences = preferences,
                    onToggleMaster = onToggleGeneralAlerts
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !permissions.hasNotificationsPermission) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = WarningAmberContainer,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Tizim bildirishnoma ruxsati o'chirilgan",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = WarningAmber,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tanlangan tahdid xabarlari ekranda ko'rinishi uchun Android bildirishnoma ruxsatini yoqing.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextPrimary
                                )
                            }
                            Button(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        val activity = context as? Activity
                                        askedRationaleBefore = activity != null && runCatching {
                                            ActivityCompat.shouldShowRequestPermissionRationale(
                                                activity,
                                                Manifest.permission.POST_NOTIFICATIONS
                                            )
                                        }.getOrDefault(false)
                                        try {
                                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } catch (_: Exception) {
                                            PermissionHelper.openNotificationSettingsSafely(context)
                                        }
                                    } else {
                                        PermissionHelper.openNotificationSettingsSafely(context)
                                    }
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("notif_pref_grant_permission"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = WarningAmber,
                                    contentColor = CyberNavyBg
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Ruxsat berish", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Tezkor profillar",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PresetChip(
                            label = "Hammasi faol",
                            selected = preferences == allEnabledPreset,
                            testTag = "notif_preset_all",
                            onClick = { onApplyPreset(allEnabledPreset) }
                        )
                        PresetChip(
                            label = "Faqat kritik (Phishing & Malware)",
                            selected = preferences == criticalOnlyPreset,
                            testTag = "notif_preset_critical",
                            onClick = { onApplyPreset(criticalOnlyPreset) }
                        )
                        PresetChip(
                            label = "Sokin himoya",
                            selected = preferences == quietNightPreset,
                            testTag = "notif_preset_quiet",
                            onClick = { onApplyPreset(quietNightPreset) }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Tahdid turlari bo'yicha ogohlantirishlar",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Umumiy bildirishnomalar o'rniga aynan qaysi turdagi xavflar haqida xabar olishni tanlang.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )
            }

            item {
                ThreatCategoryPreferenceCard(
                    category = ThreatNotificationCategory.PHISHING,
                    icon = Icons.Filled.Phishing,
                    accentColor = WarningAmber,
                    accentContainer = WarningAmberContainer,
                    checked = preferences.notifyPhishing,
                    masterEnabled = preferences.generalAlertsEnabled,
                    exampleTags = listOf("Soxta taklifnoma", "Karta/SMS phishing", ".jpg.apk niqobi"),
                    testTag = "notif_pref_phishing_switch",
                    onCheckedChange = { onToggleCategory(ThreatNotificationCategory.PHISHING, it) }
                )
            }

            item {
                ThreatCategoryPreferenceCard(
                    category = ThreatNotificationCategory.MALWARE,
                    icon = Icons.Filled.BugReport,
                    accentColor = ThreatCrimson,
                    accentContainer = ThreatCrimsonContainer,
                    checked = preferences.notifyMalware,
                    masterEnabled = preferences.generalAlertsEnabled,
                    exampleTags = listOf("Troyan APK", "Accessibility xavfi", "Yashirin dropper"),
                    testTag = "notif_pref_malware_switch",
                    onCheckedChange = { onToggleCategory(ThreatNotificationCategory.MALWARE, it) }
                )
            }

            item {
                ThreatCategoryPreferenceCard(
                    category = ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR,
                    icon = Icons.Filled.GppMaybe,
                    accentColor = CyberCyan,
                    accentContainer = CyberCyanContainer,
                    checked = preferences.notifySuspiciousBehavior,
                    masterEnabled = preferences.generalAlertsEnabled,
                    exampleTags = listOf("Evristik xavf", "Imzosiz APK", "Eski targetSdk"),
                    testTag = "notif_pref_suspicious_switch",
                    onCheckedChange = { onToggleCategory(ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR, it) }
                )
            }

            item {
                ThreatCategoryPreferenceCard(
                    category = ThreatNotificationCategory.SOCIAL_THREATS,
                    icon = Icons.Filled.Public,
                    accentColor = ShieldEmerald,
                    accentContainer = ShieldEmeraldContainer,
                    checked = preferences.notifySocialThreats,
                    masterEnabled = preferences.generalAlertsEnabled,
                    exampleTags = listOf("Instagram", "YouTube", "Facebook filtri"),
                    testTag = "notif_pref_social_switch",
                    onCheckedChange = { onToggleCategory(ThreatNotificationCategory.SOCIAL_THREATS, it) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Yetkazish usuli va sokin rejim",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        DeliveryToggleRow(
                            icon = if (preferences.soundEnabled) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                            iconTint = if (preferences.soundEnabled) CyberCyan else CyberTextSecondary,
                            title = "Ovozli signal va tebranish",
                            subtitle = "Xavf bildirishnomalarini yuqori ustuvorlikda ovoz bilan chiqarish",
                            checked = preferences.soundEnabled,
                            enabled = preferences.generalAlertsEnabled,
                            testTag = "notif_pref_sound_switch",
                            onCheckedChange = onToggleSound
                        )

                        DeliveryToggleRow(
                            icon = Icons.Filled.Bedtime,
                            iconTint = if (preferences.quietHoursEnabled) WarningAmber else CyberTextSecondary,
                            title = "Tungi sokin rejim (23:00 – 07:00)",
                            subtitle = "Tungi vaqtda odatiy va shubhali ogohlantirishlarni bezovta qilmasdan jurnalga yozish",
                            checked = preferences.quietHoursEnabled,
                            enabled = preferences.generalAlertsEnabled,
                            testTag = "notif_pref_quiet_hours_switch",
                            onCheckedChange = onToggleQuietHours
                        )

                        AnimatedVisibility(visible = preferences.quietHoursEnabled) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = CyberSurfaceElevated,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.35f))
                            ) {
                                Box(modifier = Modifier.padding(12.dp)) {
                                    DeliveryToggleRow(
                                        icon = Icons.Filled.Shield,
                                        iconTint = ThreatCrimson,
                                        title = "Kritik xavflar sokin rejimdan o'tsin",
                                        subtitle = "Kritik troyan va phishing hujumlarida tunda ham darhol ogohlantirish",
                                        checked = preferences.criticalBypassQuietHours,
                                        enabled = preferences.generalAlertsEnabled,
                                        testTag = "notif_pref_critical_bypass_switch",
                                        onCheckedChange = onToggleCriticalBypass
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = "Sinov bildirishnomasi",
                                tint = CyberCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Column {
                                Text(
                                    text = "Tanlangan sozlamalarni sinash",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tanlangan tur bo'yicha bildirishnoma qanday ishlashini tekshiring.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ThreatNotificationCategory.entries.forEach { category ->
                                FilterChip(
                                    selected = selectedTestCategory == category,
                                    onClick = { selectedTestCategory = category },
                                    label = { Text(category.shortBadgeUz) },
                                    modifier = Modifier.testTag("notif_test_chip_${category.name.lowercase()}"),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyanContainer,
                                        selectedLabelColor = CyberCyan,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                testFeedbackMessage = onSendTestNotification(selectedTestCategory)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("notif_pref_send_test_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Send,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(
                                text = "Sinov bildirishnomasini yuborish",
                                color = CyberCyan,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        AnimatedVisibility(visible = testFeedbackMessage != null) {
                            Text(
                                text = testFeedbackMessage.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberCyan
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationHeroCard(
    preferences: NotificationPreferences,
    onToggleMaster: (Boolean) -> Unit
) {
    val active = preferences.generalAlertsEnabled
    val accent = when {
        !active -> ThreatCrimson
        preferences.enabledThreatCategoryCount == 0 -> WarningAmber
        else -> ShieldEmerald
    }
    val container = when {
        !active -> ThreatCrimsonContainer
        preferences.enabledThreatCategoryCount == 0 -> WarningAmberContainer
        else -> ShieldEmeraldContainer
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        color = CyberSurface
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            accent.copy(alpha = 0.14f),
                            CyberSurface,
                            CyberSurfaceElevated
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (active) Icons.Filled.NotificationsActive else Icons.Filled.NotificationsOff,
                            contentDescription = "Tahdid bildirishnomalari holati",
                            tint = accent,
                            modifier = Modifier.size(26.dp)
                        )
                        Column {
                            Text(
                                text = "Tahdid bildirishnomalari",
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (active) {
                                    "${preferences.enabledThreatCategoryCount}/4 tahdid turi tanlangan"
                                } else {
                                    "Umumiy bildirishnomalar o'chirilgan"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = accent
                            )
                        }
                    }
                    Switch(
                        checked = active,
                        onCheckedChange = onToggleMaster,
                        modifier = Modifier.testTag("notif_pref_master_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberNavyBg,
                            checkedTrackColor = ShieldEmerald
                        )
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadgePill(
                        text = if (active) "Faol filtrlash" else "To'xtatilgan",
                        accentColor = accent,
                        containerColor = container
                    )
                    if (preferences.quietHoursEnabled) {
                        StatusBadgePill(
                            text = "Sokin rejim: 23:00–07:00",
                            accentColor = WarningAmber,
                            containerColor = WarningAmberContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetChip(
    label: String,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag(testTag),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = CyberCyanContainer,
            selectedLabelColor = CyberCyan,
            labelColor = CyberTextSecondary
        )
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ThreatCategoryPreferenceCard(
    category: ThreatNotificationCategory,
    icon: ImageVector,
    accentColor: Color,
    accentContainer: Color,
    checked: Boolean,
    masterEnabled: Boolean,
    exampleTags: List<String>,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    val active = masterEnabled && checked
    val borderColor = if (active) accentColor.copy(alpha = 0.55f) else CyberOutline

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (masterEnabled) 1f else 0.58f),
        color = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        color = if (active) accentContainer else CyberSurfaceElevated,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = category.titleUz,
                            tint = if (active) accentColor else CyberTextSecondary,
                            modifier = Modifier
                                .padding(10.dp)
                                .size(22.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = category.titleUz,
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        StatusBadgePill(
                            text = if (active) "Ogohlantirish yoqilgan" else "O'chirilgan",
                            accentColor = if (active) accentColor else CyberTextSecondary,
                            containerColor = if (active) accentContainer else CyberSurfaceElevated
                        )
                    }
                }

                Switch(
                    checked = checked,
                    enabled = masterEnabled,
                    onCheckedChange = onCheckedChange,
                    modifier = Modifier.testTag(testTag),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberNavyBg,
                        checkedTrackColor = accentColor
                    )
                )
            }

            Text(
                text = category.subtitleUz,
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                exampleTags.forEach { tag ->
                    Surface(
                        color = CyberSurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CyberOutline.copy(alpha = 0.65f))
                    ) {
                        Text(
                            text = tag,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (active) CyberTextPrimary else CyberTextSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeliveryToggleRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.58f),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )
            }
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberNavyBg,
                checkedTrackColor = CyberCyan
            )
        )
    }
}
