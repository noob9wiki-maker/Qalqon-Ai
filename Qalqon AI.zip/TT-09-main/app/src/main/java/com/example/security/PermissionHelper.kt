package com.example.security

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.PermissionStatusSnapshot

object PermissionHelper {

    fun getPermissionSnapshot(context: Context): PermissionStatusSnapshot {
        return PermissionStatusSnapshot(
            hasAllFilesAccess = hasAllFilesAccess(context),
            hasAccessibilityService = isAccessibilityServiceEnabled(context),
            hasOverlayPermission = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false),
            hasNotificationsPermission = hasNotificationPermission(context),
            isBatteryOptimizationIgnored = isIgnoringBatteryOptimizations(context)
        )
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        return runCatching {
            val pm = context.getSystemService(PowerManager::class.java)
            pm?.isIgnoringBatteryOptimizations(context.packageName) == true
        }.getOrDefault(false)
    }

    fun hasAllFilesAccess(context: Context): Boolean {
        // MANAGE_EXTERNAL_STORAGE is intentionally not requested anymore. A persisted
        // Storage Access Framework tree grant (folder picker) is the Play-safe equivalent.
        val hasSafTreeGrant = runCatching {
            context.contentResolver.persistedUriPermissions.any { it.isReadPermission }
        }.getOrDefault(false)
        if (hasSafTreeGrant) return true
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        }.getOrDefault(false)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }.getOrDefault(false)
    }

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        return runCatching {
            val expectedComponent = ComponentName(context, ContentGuardAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val flattened = expectedComponent.flattenToString()
            val shortFlattened = expectedComponent.flattenToShortString()
            enabledServices.split(':').any { entry ->
                entry.equals(flattened, ignoreCase = true) ||
                    entry.equals(shortFlattened, ignoreCase = true)
            }
        }.getOrDefault(false)
    }

    fun createAllFilesAccessIntent(context: Context): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            createAppDetailsIntent(context)
        }
    }

    fun createAccessibilitySettingsIntent(): Intent {
        return Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun createOverlayPermissionIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun createBatteryOptimizationSettingsIntent(context: Context): Intent {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (runCatching { intent.resolveActivity(context.packageManager) }.getOrNull() != null) {
            intent
        } else {
            createAppDetailsIntent(context)
        }
    }

    fun createNotificationSettingsIntent(context: Context): Intent {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notifIntent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (runCatching { notifIntent.resolveActivity(context.packageManager) }.getOrNull() != null) {
                return notifIntent
            }
        }
        return createAppDetailsIntent(context)
    }

    fun openNotificationSettingsSafely(context: Context) {
        try {
            context.startActivity(createNotificationSettingsIntent(context))
        } catch (_: Exception) {
            try {
                context.startActivity(createAppDetailsIntent(context))
            } catch (_: Exception) {
                // Ignore if device OEM blocks settings intent
            }
        }
    }

    fun createAppDetailsIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
