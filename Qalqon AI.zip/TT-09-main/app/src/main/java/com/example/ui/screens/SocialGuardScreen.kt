package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.KeywordRuleEntity
import com.example.data.PermissionStatusSnapshot
import com.example.data.ProtectedAccountEntity
import com.example.data.SocialPlatform
import com.example.security.PermissionHelper
import com.example.ui.AiAnalysisUiState
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SocialGuardScreen(
    permissions: PermissionStatusSnapshot,
    protectedAccounts: List<ProtectedAccountEntity>,
    keywordRules: List<KeywordRuleEntity>,
    aiAnalysisState: AiAnalysisUiState,
    onToggleAccountProtection: (ProtectedAccountEntity) -> Unit,
    onAnalyzePost: (SocialPlatform, String) -> Unit,
    onPreviewSocialBlockOverlay: (SocialPlatform, String) -> Unit,
    onAddKeywordRule: (String, String, String) -> Unit,
    onToggleKeywordRule: (KeywordRuleEntity) -> Unit,
    onDeleteKeywordRule: (Long) -> Unit
) {
    val context = LocalContext.current
    var selectedPlatform by rememberSaveable { mutableStateOf(SocialPlatform.INSTAGRAM) }
    var postTextInput by rememberSaveable { mutableStateOf("") }
    var newKeywordInput by rememberSaveable { mutableStateOf("") }
    var newKeywordLang by rememberSaveable { mutableStateOf("UZ") }
    var newKeywordCategory by rememberSaveable { mutableStateOf("EKSTREMIZM") }

    val socialAccounts = protectedAccounts.filter { it.platform != SocialPlatform.TELEGRAM.name }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(
                        1.dp,
                        if (permissions.hasAccessibilityService) ShieldEmerald.copy(alpha = 0.55f)
                        else WarningAmber.copy(alpha = 0.6f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AccessibilityNew,
                                    contentDescription = "Accessibility xizmati",
                                    tint = if (permissions.hasAccessibilityService) ShieldEmerald else WarningAmber
                                )
                                Text(
                                    text = "Real-vaqt Kontent Qalqoni",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            StatusBadgePill(
                                text = if (permissions.hasAccessibilityService) "Faol" else "Yoqilmagan",
                                accentColor = if (permissions.hasAccessibilityService) ShieldEmerald else WarningAmber,
                                containerColor = if (permissions.hasAccessibilityService) ShieldEmeraldContainer else WarningAmberContainer
                            )
                        }
                        Text(
                            text = "Instagram, YouTube va Facebook ochilganda zararli, ekstremistik va nafrat uyg'otuvchi matnlarni tekshiradi hamda Like, Ulashish, Saqlash, Izoh tugmalarini bloklaydi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                        if (!permissions.hasAccessibilityService) {
                            Button(
                                onClick = {
                                    runCatching {
                                        context.startActivity(PermissionHelper.createAccessibilitySettingsIntent())
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("social_enable_a11y_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = CyberNavyBg
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "Accessibility xizmatini yoqish",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Kuzatiladigan ilovalar",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            }

            items(socialAccounts, key = { it.platform }) { acc ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = acc.platform,
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Bloklangan kontent: ${acc.blockedCount} • ${acc.sessionMonitorMethod}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                        Switch(
                            checked = acc.protectionActive,
                            onCheckedChange = { onToggleAccountProtection(acc) },
                            modifier = Modifier.testTag("social_toggle_${acc.platform.lowercase()}"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberNavyBg,
                                checkedTrackColor = CyberCyan
                            )
                        )
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "Gemini AI",
                                tint = CyberCyan
                            )
                            Text(
                                text = "Gemini AI Post / Izoh Tahlilchisi",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "Post, Reels sarlavhasi, izoh yoki #hashtag matnini joylang. Gemini AI O'zbek, Rus va Ingliz tillarida haqiqiy ma'noni (so'z o'yini va niqoblangan ma'nolarni ham) tahlil qiladi. Xavf aniqlansa, xavfli kalit so'z avtomatik ravishda oflayn filtrga qo'shiladi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                SocialPlatform.INSTAGRAM,
                                SocialPlatform.YOUTUBE,
                                SocialPlatform.FACEBOOK
                            ).forEach { platform ->
                                FilterChip(
                                    selected = selectedPlatform == platform,
                                    onClick = { selectedPlatform = platform },
                                    label = { Text(platform.displayName) },
                                    modifier = Modifier.testTag("ai_platform_${platform.name.lowercase()}"),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyanContainer,
                                        selectedLabelColor = CyberCyan,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                        }

                        OutlinedTextField(
                            value = postTextInput,
                            onValueChange = { postTextInput = it },
                            placeholder = {
                                Text(
                                    "Matn, izoh yoki Reels hashtaglari (#...) ...",
                                    color = CyberTextSecondary
                                )
                            },
                            minLines = 3,
                            maxLines = 5,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("social_ai_text_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CyberOutline,
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary
                            )
                        )

                        Button(
                            onClick = { onAnalyzePost(selectedPlatform, postTextInput) },
                            enabled = postTextInput.isNotBlank() && aiAnalysisState !is AiAnalysisUiState.Loading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("social_ai_analyze_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = CyberNavyBg
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (aiAnalysisState is AiAnalysisUiState.Loading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = CyberNavyBg,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Gemini AI tahlil qilmoqda...")
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Gemini AI bilan tekshirish")
                            }
                        }

                        when (aiAnalysisState) {
                            is AiAnalysisUiState.Success -> {
                                val accent = if (aiAnalysisState.isHarmful) ThreatCrimson else ShieldEmerald
                                val container = if (aiAnalysisState.isHarmful) {
                                    ThreatCrimsonContainer.copy(alpha = 0.65f)
                                } else {
                                    ShieldEmeraldContainer.copy(alpha = 0.4f)
                                }
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = container,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, accent)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (aiAnalysisState.isHarmful) Icons.Filled.GppBad else Icons.Filled.GppGood,
                                                contentDescription = null,
                                                tint = accent
                                            )
                                            Text(
                                                text = "${aiAnalysisState.category} • ${aiAnalysisState.riskLevel.labelUz}",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = accent,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = aiAnalysisState.explanationUz,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = CyberTextPrimary
                                        )
                                        Text(
                                            text = aiAnalysisState.recommendedActionUz,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = accent
                                        )
                                        if (!aiAnalysisState.detectedLanguage.isNullOrBlank()) {
                                            StatusBadgePill(
                                                text = "Til: ${aiAnalysisState.detectedLanguage}",
                                                accentColor = CyberCyan,
                                                containerColor = CyberCyanContainer
                                            )
                                        }
                                        if (aiAnalysisState.autoFilteredKeywords.isNotEmpty()) {
                                            Surface(
                                                modifier = Modifier.fillMaxWidth(),
                                                color = CyberSurface,
                                                shape = RoundedCornerShape(12.dp),
                                                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Text(
                                                        text = "Gemini AI tomonidan oflayn filtrga qo'shildi:",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = CyberCyan,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    FlowRow(
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        aiAnalysisState.autoFilteredKeywords.forEach { keyword ->
                                                            StatusBadgePill(
                                                                text = "#$keyword",
                                                                accentColor = ThreatCrimson,
                                                                containerColor = ThreatCrimsonContainer
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if (aiAnalysisState.isHarmful) {
                                            OutlinedButton(
                                                onClick = {
                                                    onPreviewSocialBlockOverlay(
                                                        selectedPlatform,
                                                        aiAnalysisState.explanationUz
                                                    )
                                                },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(46.dp)
                                                    .testTag("preview_social_block_button"),
                                                border = BorderStroke(1.dp, ThreatCrimson)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Shield,
                                                    contentDescription = null,
                                                    tint = ThreatCrimson,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.size(6.dp))
                                                Text(
                                                    text = "Bloklash oynasini ko'rish",
                                                    color = ThreatCrimson
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            is AiAnalysisUiState.Error -> {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = ThreatCrimsonContainer.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, ThreatCrimson)
                                ) {
                                    Text(
                                        text = aiAnalysisState.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CyberTextPrimary,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                            else -> Unit
                        }
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Kalit so'zlar filtri (UZ / RU / EN)",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newKeywordInput,
                                onValueChange = { newKeywordInput = it },
                                placeholder = { Text("Yangi taqiqlangan ibora...", color = CyberTextSecondary) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("new_keyword_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberCyan,
                                    unfocusedBorderColor = CyberOutline,
                                    focusedTextColor = CyberTextPrimary,
                                    unfocusedTextColor = CyberTextPrimary
                                )
                            )
                            Button(
                                onClick = {
                                    onAddKeywordRule(newKeywordInput, newKeywordLang, newKeywordCategory)
                                    newKeywordInput = ""
                                },
                                enabled = newKeywordInput.isNotBlank(),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("add_keyword_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = CyberNavyBg
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = "Qo'shish")
                            }
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("UZ", "RU", "EN").forEach { lang ->
                                FilterChip(
                                    selected = newKeywordLang == lang,
                                    onClick = { newKeywordLang = lang },
                                    label = { Text(lang) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyanContainer,
                                        selectedLabelColor = CyberCyan,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                            listOf("EKSTREMIZM", "NAFRAT", "ZO'RAVONLIK", "FIRIBGARLIK").forEach { cat ->
                                FilterChip(
                                    selected = newKeywordCategory == cat,
                                    onClick = { newKeywordCategory = cat },
                                    label = { Text(cat) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ThreatCrimsonContainer,
                                        selectedLabelColor = ThreatCrimson,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            items(keywordRules, key = { it.id }) { rule ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = rule.keyword,
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary
                            )
                            Text(
                                text = "${rule.language} • ${rule.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = rule.isEnabled,
                                onCheckedChange = { onToggleKeywordRule(rule) },
                                modifier = Modifier.testTag("keyword_switch_${rule.id}"),
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = CyberNavyBg,
                                    checkedTrackColor = CyberCyan
                                )
                            )
                            if (!rule.isSystemDefault) {
                                IconButton(
                                    onClick = { onDeleteKeywordRule(rule.id) },
                                    modifier = Modifier.testTag("keyword_delete_${rule.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = "Qoidani o'chirish",
                                        tint = ThreatCrimson
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}
