package com.example.security

import android.app.ActivityManager
import android.content.Context
import androidx.work.WorkManager
import java.io.File

data class PanicExecutionResult(
    val terminatedProcessesCount: Int,
    val targetedPackages: List<String>,
    val stoppedBackgroundTasksCount: Int,
    val clearedCacheBytes: Long,
    val clearedCacheFilesCount: Int,
    val lockedSensitiveTabs: Boolean = true,
    val executedAt: Long = System.currentTimeMillis()
)

object PanicModeManager {

    private val protectedSystemPrefixes = listOf(
        "android",
        "com.android.systemui",
        "com.google.android.gms"
    )

    fun executePanicLockdown(
        context: Context,
        flaggedSuspiciousPackages: Set<String>
    ): PanicExecutionResult {
        val appContext = context.applicationContext
        val selfPkg = appContext.packageName
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager

        val targets = linkedSetOf<String>()

        flaggedSuspiciousPackages.forEach { pkg ->
            val clean = pkg.trim()
            if (isKillableThirdPartyPackage(clean, selfPkg)) {
                targets.add(clean)
            }
        }

        // Inspect currently visible running app processes for deceptive or flagged names
        runCatching {
            am?.runningAppProcesses?.forEach { proc ->
                val procPkg = proc.processName.substringBefore(':')
                val isFlaggedByList = targets.contains(procPkg)
                val isDeceptive = ApkThreatAnalyzer.detectDeceptiveFilename(proc.processName) != null
                if ((isFlaggedByList || isDeceptive) && isKillableThirdPartyPackage(procPkg, selfPkg)) {
                    targets.add(procPkg)
                }
            }
        }

        var killedCount = 0
        targets.forEach { pkg ->
            val invoked = runCatching {
                am?.killBackgroundProcesses(pkg)
                true
            }.getOrDefault(false)
            if (invoked) killedCount++
        }

        // Immediately stop active Qalqon background scanner service & queued background WorkManager tasks
        var stoppedTasks = 0
        if (runCatching { DownloadGuardService.stop(appContext); true }.getOrDefault(false)) {
            stoppedTasks++
        }
        if (runCatching { WorkManager.getInstance(appContext).cancelAllWork(); true }.getOrDefault(false)) {
            stoppedTasks++
        }

        // Clear all sensitive application cache directories (cacheDir, codeCacheDir, externalCacheDir)
        var clearedBytes = 0L
        var clearedFiles = 0
        val cacheDirs = listOfNotNull(
            appContext.cacheDir,
            appContext.codeCacheDir,
            appContext.externalCacheDir
        ).distinctBy { it.absolutePath }

        cacheDirs.forEach { dir ->
            val stats = clearDirectoryContents(dir)
            clearedBytes += stats.first
            clearedFiles += stats.second
        }

        return PanicExecutionResult(
            terminatedProcessesCount = killedCount,
            targetedPackages = targets.toList(),
            stoppedBackgroundTasksCount = stoppedTasks,
            clearedCacheBytes = clearedBytes,
            clearedCacheFilesCount = clearedFiles,
            lockedSensitiveTabs = true
        )
    }

    private fun isKillableThirdPartyPackage(packageName: String, selfPackage: String): Boolean {
        if (packageName.isBlank()) return false
        if (packageName == selfPackage) return false
        if (!packageName.contains('.') || packageName.contains('/')) return false
        if (protectedSystemPrefixes.any { packageName == it }) return false
        return true
    }

    internal fun clearDirectoryContents(dir: File): Pair<Long, Int> {
        if (!dir.exists() || !dir.isDirectory) return 0L to 0
        var totalBytes = 0L
        var totalFiles = 0
        val children = dir.listFiles() ?: return 0L to 0
        children.forEach { child ->
            if (child.isDirectory) {
                val (subBytes, subFiles) = clearDirectoryContents(child)
                totalBytes += subBytes
                totalFiles += subFiles
                runCatching { child.delete() }
            } else if (child.isFile) {
                val len = child.length()
                if (runCatching { child.delete() }.getOrDefault(false)) {
                    totalBytes += len
                    totalFiles++
                }
            }
        }
        return totalBytes to totalFiles
    }
}
