package com.example.security

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.LogSourceType
import com.example.data.QalqonRepository
import com.example.data.ScannedFileEntity
import com.example.data.SocialPlatform
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import com.example.ui.ThreatAlertActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.Collections

class DownloadGuardService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var repository: QalqonRepository
    private val observers = mutableListOf<DownloadFileObserver>()
    private val recentlyScanned = Collections.synchronizedSet(mutableSetOf<String>())

    override fun onCreate() {
        super.onCreate()
        repository = QalqonRepository(applicationContext)
        createNotificationChannels()
        startForegroundSafely()
        startWatchingDirectories()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_GUARD) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        observers.forEach { it.stop() }
        observers.clear()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundSafely() {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_GUARD)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Qalqon AI — 24/7 Himoya Faol")
            .setContentText("Telegram va Yuklanmalar papkasi real vaqtda tekshirilmoqda")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startWatchingDirectories() {
        val candidateDirs = getMonitoredDirectories()
        candidateDirs.forEach { dir ->
            if (dir.exists() && dir.isDirectory) {
                val obs = DownloadFileObserver.create(dir) { apkFile ->
                    handleDetectedApk(apkFile)
                }
                obs.start()
                observers.add(obs)
                Log.d(TAG, "Watching directory: ${dir.absolutePath}")
            }
        }
    }

    private fun handleDetectedApk(file: File) {
        val key = "${file.absolutePath}:${file.length()}"
        if (!recentlyScanned.add(key)) return

        serviceScope.launch {
            try {
                val report = ApkThreatAnalyzer.analyzeFile(applicationContext, file)
                repository.incrementScannedFilesCount(1)

                if (repository.isApkWhitelisted(report.fileName, report.packageName)) {
                    repository.logThreat(
                        ThreatLogEntity(
                            sourceType = LogSourceType.APK_SCAN.name,
                            title = "Oq ro'yxatdagi ishonchli fayl",
                            targetName = report.fileName,
                            packageNameOrPath = report.filePathOrUri,
                            threatLevel = ThreatLevel.SAFE.name,
                            reasonUz = "Fayl yoki paket nomi Oq ro'yxatda bo'lgani uchun ruxsat berildi.",
                            detectedIndicators = report.packageName.orEmpty(),
                            aiExplanation = "Oq ro'yxat qoidasi faol.",
                            actionTaken = "OQ RO'YXAT"
                        )
                    )
                    repository.recordScannedFile(
                        ScannedFileEntity(
                            fileName = report.fileName,
                            packageName = report.packageName,
                            filePathOrUri = report.filePathOrUri,
                            fileSizeBytes = report.metadata.fileSizeBytes,
                            sha256 = report.metadata.sha256,
                            status = "SAFE",
                            riskLevel = ThreatLevel.SAFE.name,
                            scanSource = "Fon FileObserver (Oq ro'yxat)",
                            summaryUz = "Fayl yoki paket nomi Oq ro'yxatda bo'lgani uchun xavfsiz deb belgilandi."
                        )
                    )
                    return@launch
                }

                repository.logThreat(
                    ThreatLogEntity(
                        sourceType = LogSourceType.APK_SCAN.name,
                        title = if (report.threatLevel == ThreatLevel.SAFE) {
                            "Fayl xavfsiz deb topildi"
                        } else {
                            "XAVF! Zararli fayl aniqlandi!"
                        },
                        targetName = report.fileName,
                        packageNameOrPath = report.filePathOrUri,
                        threatLevel = report.threatLevel.name,
                        reasonUz = report.reasonUz,
                        detectedIndicators = report.suspiciousPermissions.joinToString(" • "),
                        aiExplanation = report.recommendationUz,
                        actionTaken = if (report.threatLevel == ThreatLevel.SAFE) "XAVFSIZ" else "BLOKLANDI"
                    )
                )

                repository.recordScannedFile(
                    ScannedFileEntity(
                        fileName = report.fileName,
                        packageName = report.packageName,
                        filePathOrUri = report.filePathOrUri,
                        fileSizeBytes = report.metadata.fileSizeBytes,
                        sha256 = report.metadata.sha256,
                        status = if (report.threatLevel == ThreatLevel.SAFE) "SAFE" else "MALICIOUS",
                        riskLevel = report.threatLevel.name,
                        scanSource = "Fon FileObserver",
                        summaryUz = report.reasonUz
                    )
                )

                if (report.threatLevel != ThreatLevel.SAFE) {
                    if (file.absolutePath.contains("telegram", ignoreCase = true)) {
                        repository.incrementAccountBlocked(SocialPlatform.TELEGRAM)
                    }
                    SecurityNotificationService.notifyMaliciousFile(
                        context = applicationContext,
                        report = report
                    )
                    ThreatAlertActivity.launchApkAlert(
                        context = applicationContext,
                        fileName = report.fileName,
                        filePath = report.filePathOrUri,
                        reason = report.reasonUz,
                        indicators = report.suspiciousPermissions.joinToString("\n"),
                        recommendation = report.recommendationUz
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed scanning detected APK ${file.name}", e)
            }
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val guardChannel = NotificationChannel(
                CHANNEL_GUARD,
                getString(R.string.notification_channel_guard_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_guard_desc)
            }
            val threatChannel = NotificationChannel(
                CHANNEL_THREAT,
                getString(R.string.notification_channel_threat_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notification_channel_threat_desc)
            }
            nm.createNotificationChannel(guardChannel)
            nm.createNotificationChannel(threatChannel)
        }
    }

    companion object {
        private const val TAG = "DownloadGuardService"
        const val CHANNEL_GUARD = "qalqon_guard_channel"
        const val CHANNEL_THREAT = "qalqon_threat_channel"
        private const val NOTIFICATION_ID = 4101
        private const val ACTION_STOP_GUARD = "com.example.action.STOP_GUARD"

        fun getMonitoredDirectories(): List<File> {
            val root = Environment.getExternalStorageDirectory()
            return listOf(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                File(root, "Telegram/Telegram Documents"),
                File(root, "Telegram/Telegram Files"),
                File(root, "Download/Telegram"),
                File(root, "Android/media/org.telegram.messenger/Telegram/Telegram Documents")
            )
        }

        fun start(context: Context) {
            val intent = Intent(context, DownloadGuardService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, DownloadGuardService::class.java))
        }
    }
}
