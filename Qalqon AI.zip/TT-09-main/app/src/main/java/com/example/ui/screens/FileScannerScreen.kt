package com.example.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ApkScanReport
import com.example.data.PermissionStatusSnapshot
import com.example.data.ScannedFileEntity
import com.example.data.ThreatLevel
import com.example.ui.ApkScannerUiState
import com.example.ui.components.StatusBadgePill
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

private const val PICKER_MODE_FILE = "file"
private const val PICKER_MODE_FOLDER = "folder"

@Composable
fun FileScannerScreen(
    scannerState: ApkScannerUiState,
    permissions: PermissionStatusSnapshot,
    scannedFiles: List<ScannedFileEntity>,
    whitelistCount: Int,
    onScanPickedApk: (Uri) -> Unit,
    onScanPickedFolder: (Uri) -> Unit = {},
    onPickerError: (String) -> Unit = {},
    onRetryGeminiHeuristic: () -> Unit,
    onLaunchAlertForReport: (ApkScanReport) -> Unit,
    onScanFoldersNow: () -> Unit,
    onCheckFileName: (String) -> Unit,
    onTriggerSampleAlertDemo: () -> Unit,
    onOpenWhitelist: () -> Unit,
    onWhitelistFile: (String) -> Unit,
    onDeleteScannedFile: (Long) -> Unit,
    onClearScannedFiles: () -> Unit
) {
    var fileNameInput by rememberSaveable { mutableStateOf("") }
    var selectedFilter by rememberSaveable { mutableStateOf("ALL") }
    var showClearDialog by rememberSaveable { mutableStateOf(false) }

    // MIUI/HyperOS may crash when several ActivityResultContracts launchers register
    // requestCodes at once ("Can only use lower 16 bits for requestCode"). One plain
    // StartActivityForResult launcher handles both files and folders safely.
    var pendingPickerMode by remember { mutableStateOf<String?>(null) }
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val pickerMode = pendingPickerMode
        pendingPickerMode = null
        if (result.resultCode != Activity.RESULT_OK) {
            if (result.resultCode != Activity.RESULT_CANCELED) {
                onPickerError("Fayl tanlash bekor qilindi yoki qurilma tomonidan rad etildi.")
            }
            return@rememberLauncherForActivityResult
        }
        val pickedUri = result.data?.data
        if (pickedUri == null) {
            onPickerError("Tanlangan fayl yoki papka aniqlanmadi. Qaytadan urinib ko'ring.")
            return@rememberLauncherForActivityResult
        }
        runCatching {
            if (pickerMode == PICKER_MODE_FOLDER) {
                onScanPickedFolder(pickedUri)
            } else {
                onScanPickedApk(pickedUri)
            }
        }.onFailure { err ->
            onPickerError("Tanlangan manbani o'qishda xatolik: ${err.localizedMessage ?: "noma'lum xatolik"}")
        }
    }

    fun launchSafeDocumentPicker(mode: String) {
        val pickerIntent = if (mode == PICKER_MODE_FOLDER) {
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        try {
            pendingPickerMode = mode
            documentPickerLauncher.launch(pickerIntent)
        } catch (_: ActivityNotFoundException) {
            pendingPickerMode = null
            if (mode == PICKER_MODE_FOLDER) {
                onPickerError("Papka tanlash oynasi bu qurilmada mavjud emas — standart papkalar tekshirilmoqda.")
                onScanFoldersNow()
            } else {
                onPickerError("Fayl tanlash oynasini ochib bo'lmadi: qurilmada mos fayl menejeri topilmadi.")
            }
        } catch (e: Exception) {
            pendingPickerMode = null
            if (mode == PICKER_MODE_FOLDER) {
                onPickerError("Papkani ochishda xatolik (${e.localizedMessage ?: "noma'lum"}) — standart papkalar tekshirilmoqda.")
                onScanFoldersNow()
            } else {
                onPickerError("Fayl tanlash oynasini ochishda xatolik: ${e.localizedMessage ?: "noma'lum xatolik"}")
            }
        }
    }

    val filteredFiles = remember(scannedFiles, selectedFilter) {
        scannedFiles.filter { file ->
            when (selectedFilter) {
                "MALICIOUS" -> file.status == "MALICIOUS"
                "SAFE" -> file.status == "SAFE"
                else -> true
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = CyberSurface,
            icon = {
                Icon(
                    imageVector = Icons.Filled.DeleteSweep,
                    contentDescription = null,
                    tint = ThreatCrimson
                )
            },
            title = {
                Text(
                    text = "Ro'yxatni tozalash",
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Tekshirilgan fayllar ro'yxatidagi barcha yozuvlarni (${scannedFiles.size} ta) o'chirib tashlashni tasdiqlaysizmi?",
                    color = CyberTextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        onClearScannedFiles()
                    },
                    modifier = Modifier.testTag("confirm_clear_scanned_files")
                ) {
                    Text("Tozalash", color = ThreatCrimson, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showClearDialog = false },
                    modifier = Modifier.testTag("cancel_clear_scanned_files")
                ) {
                    Text("Bekor qilish", color = CyberCyan)
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "APK Evristik AI Skaner",
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberTextPrimary
                            )
                            StatusBadgePill(
                                text = if (permissions.hasAllFilesAccess) "FileObserver + AI" else "Gemini AI Tayyor",
                                accentColor = if (permissions.hasAllFilesAccess) ShieldEmerald else CyberCyan,
                                containerColor = if (permissions.hasAllFilesAccess) ShieldEmeraldContainer else CyberCyanContainer
                            )
                        }

                        Text(
                            text = "Qurilmadan istalgan .apk faylni tanlang: Qalqon AI fayl manifesti, ruxsatlar, SHA-256, DEX va yashirin resurslarni ajratib, Gemini AI orqali evristik xavfsizlik tahlilini o'tkazadi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { launchSafeDocumentPicker(PICKER_MODE_FILE) },
                                enabled = !scannerState.isScanning,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("pick_apk_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = CyberNavyBg
                                ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.FileOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "APK tanlash",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }

                            OutlinedButton(
                                onClick = { launchSafeDocumentPicker(PICKER_MODE_FOLDER) },
                                enabled = !scannerState.isScanning,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("scan_folders_button"),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.FolderShared,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "Papkani tekshirish",
                                    color = CyberCyan,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }

                        if (scannerState.isScanning) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = CyberCyan,
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = scannerState.statusMessage ?: "Tekshirilmoqda...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberCyan
                                )
                            }
                        } else if (!scannerState.statusMessage.isNullOrBlank()) {
                            Text(
                                text = scannerState.statusMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberCyan
                            )
                        }
                    }
                }
            }

            scannerState.lastReport?.let { report ->
                item {
                    ApkHeuristicReportCard(
                        report = report,
                        isScanning = scannerState.isScanning,
                        onRetryGemini = onRetryGeminiHeuristic,
                        onWhitelist = { onWhitelistFile(report.fileName) },
                        onOpenFullAlert = { onLaunchAlertForReport(report) }
                    )
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Fayl nomini tezkor tekshirish",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        OutlinedTextField(
                            value = fileNameInput,
                            onValueChange = { fileNameInput = it },
                            placeholder = {
                                Text(
                                    "Masalan: To'yga taklifnoma.apk yoki Sening videong.apk",
                                    color = CyberTextSecondary
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("filename_check_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CyberOutline,
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    onCheckFileName(fileNameInput)
                                    fileNameInput = ""
                                },
                                enabled = fileNameInput.isNotBlank() && !scannerState.isScanning,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("check_filename_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberSurfaceElevated,
                                    contentColor = CyberCyan
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Tekshirish", style = MaterialTheme.typography.labelLarge)
                            }

                            OutlinedButton(
                                onClick = onTriggerSampleAlertDemo,
                                enabled = !scannerState.isScanning,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("demo_apk_alert_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.6f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Warning,
                                    contentDescription = null,
                                    tint = ThreatCrimson,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "Namuna sinovi",
                                    color = ThreatCrimson,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Tekshirilgan fayllar (${filteredFiles.size})",
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberTextPrimary
                            )
                            val safeCount = scannedFiles.count { it.status == "SAFE" }
                            val maliciousCount = scannedFiles.count { it.status == "MALICIOUS" }
                            Text(
                                text = "Xavfsiz: $safeCount • Zararli: $maliciousCount",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextSecondary
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (scannedFiles.isNotEmpty()) {
                                IconButton(
                                    onClick = { showClearDialog = true },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("clear_scanned_files_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.DeleteSweep,
                                        contentDescription = "Ro'yxatni tozalash",
                                        tint = ThreatCrimson
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = onOpenWhitelist,
                                modifier = Modifier.testTag("files_open_whitelist_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.55f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Shield,
                                    contentDescription = null,
                                    tint = ShieldEmerald,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.size(6.dp))
                                Text(
                                    text = "Oq ro'yxat ($whitelistCount)",
                                    color = ShieldEmerald,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "ALL" to "Barchasi",
                            "SAFE" to "Xavfsiz",
                            "MALICIOUS" to "Zararli"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = selectedFilter == key,
                                onClick = { selectedFilter = key },
                                label = { Text(label) },
                                modifier = Modifier.testTag("apk_filter_$key"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberCyanContainer,
                                    selectedLabelColor = CyberCyan,
                                    labelColor = CyberTextSecondary
                                )
                            )
                        }
                    }
                }
            }

            if (filteredFiles.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = CyberSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CyberOutline)
                    ) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = if (scannedFiles.isEmpty()) {
                                    "Hali fayllar tekshirilmagan"
                                } else {
                                    "Tanlangan filtr bo'yicha fayllar topilmadi"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary
                            )
                            Text(
                                text = "Yuqoridagi \"APK tanlash\" tugmasi orqali faylni tekshiring — barcha natijalar sana va holati bilan shu ro'yxatda saqlanadi.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(filteredFiles, key = { it.id }) { file ->
                    ScannedFileHistoryCard(
                        file = file,
                        onWhitelist = { onWhitelistFile(file.fileName) },
                        onDelete = { onDeleteScannedFile(file.id) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ScannedFileHistoryCard(
    file: ScannedFileEntity,
    onWhitelist: () -> Unit,
    onDelete: () -> Unit
) {
    val isSafe = file.status == "SAFE"
    val isSuspicious = !isSafe && file.riskLevel == ThreatLevel.SUSPICIOUS.name
    val (accent, container, statusLabel, icon) = when {
        isSafe -> QuadTuple(ShieldEmerald, ShieldEmeraldContainer, "XAVFSIZ", Icons.Filled.GppGood)
        isSuspicious -> QuadTuple(WarningAmber, WarningAmberContainer, "ZARARLI", Icons.Filled.Warning)
        else -> QuadTuple(ThreatCrimson, ThreatCrimsonContainer, "ZARARLI", Icons.Filled.GppBad)
    }

    val formattedTime = remember(file.scannedAt) {
        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(file.scannedAt))
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("scanned_file_card_${file.id}"),
        color = CyberSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = statusLabel,
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = file.fileName,
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = file.packageName ?: file.scanSource,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                StatusBadgePill(
                    text = statusLabel,
                    accentColor = accent,
                    containerColor = container
                )
            }

            Text(
                text = file.summaryUz,
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Schedule,
                            contentDescription = "Vaqt",
                            tint = CyberCyan,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextPrimary
                        )
                    }
                }

                StatusBadgePill(
                    text = file.scanSource,
                    accentColor = CyberCyan,
                    containerColor = CyberSurfaceElevated
                )

                if (file.fileSizeBytes > 0L) {
                    val kb = (file.fileSizeBytes / 1024L).coerceAtLeast(1L)
                    val sizeLabel = if (kb >= 1024L) "${kb / 1024L} MB" else "$kb KB"
                    StatusBadgePill(
                        text = sizeLabel,
                        accentColor = CyberTextSecondary,
                        containerColor = CyberSurfaceElevated
                    )
                }

                if (!file.aiCategory.isNullOrBlank()) {
                    val aiLabel = if (file.aiConfidencePercent != null) {
                        "${file.aiCategory} (${file.aiConfidencePercent}%)"
                    } else {
                        file.aiCategory
                    }
                    StatusBadgePill(
                        text = aiLabel,
                        accentColor = accent,
                        containerColor = container
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = file.sha256?.take(12)?.let { "SHA-256: $it..." } ?: file.filePathOrUri,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (!isSafe) {
                        TextButton(
                            onClick = onWhitelist,
                            modifier = Modifier.testTag("scanned_whitelist_${file.id}")
                        ) {
                            Text(
                                text = "Oq ro'yxat",
                                style = MaterialTheme.typography.labelMedium,
                                color = ShieldEmerald
                            )
                        }
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("delete_scanned_file_${file.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Yozuvni o'chirish",
                            tint = CyberTextSecondary
                        )
                    }
                }
            }
        }
    }
}

private data class QuadTuple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ApkHeuristicReportCard(
    report: ApkScanReport,
    isScanning: Boolean,
    onRetryGemini: () -> Unit,
    onWhitelist: () -> Unit,
    onOpenFullAlert: () -> Unit
) {
    val (accent, container, icon) = when (report.threatLevel) {
        ThreatLevel.SAFE -> Triple(ShieldEmerald, ShieldEmeraldContainer, Icons.Filled.GppGood)
        ThreatLevel.SUSPICIOUS -> Triple(WarningAmber, WarningAmberContainer, Icons.Filled.Warning)
        ThreatLevel.CRITICAL -> Triple(ThreatCrimson, ThreatCrimsonContainer, Icons.Filled.GppBad)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("apk_heuristic_report_card"),
        color = container.copy(alpha = 0.42f),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.85f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = report.threatLevel.labelUz,
                        tint = accent,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = report.fileName,
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = report.packageName ?: "Paket nomi aniqlanmadi",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextSecondary
                        )
                    }
                }
                StatusBadgePill(
                    text = report.threatLevel.labelUz,
                    accentColor = accent,
                    containerColor = container
                )
            }

            val meta = report.metadata
            val forensicTags = buildList {
                if (meta.fileSizeBytes > 0L) {
                    val kb = (meta.fileSizeBytes / 1024L).coerceAtLeast(1L)
                    add(if (kb >= 1024L) "${kb / 1024L} MB" else "$kb KB")
                }
                meta.targetSdk?.let { add("targetSdk $it") }
                if (meta.dexFileCount > 0) add("${meta.dexFileCount} DEX")
                if (meta.allRequestedPermissions.isNotEmpty()) {
                    add("${meta.allRequestedPermissions.size} ruxsat")
                }
                if (meta.signatureCount > 0) {
                    add("Imzo: ${meta.signatureCount}")
                } else if (meta.signatureChecked) {
                    add("Imzosiz APK")
                }
                if (meta.hasHiddenLauncherIcon) {
                    add("Yashirin belgi")
                }
                meta.sha256?.take(10)?.let { add("SHA256: $it...") }
            }
            if (forensicTags.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    forensicTags.forEach { tag ->
                        StatusBadgePill(
                            text = tag,
                            accentColor = CyberCyan,
                            containerColor = CyberSurface
                        )
                    }
                }
            }

            Text(
                text = report.reasonUz,
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextPrimary
            )

            report.aiHeuristicResult?.let { ai ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "Gemini AI",
                                    tint = CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Gemini AI Evristik Xulosa",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CyberCyan
                                )
                            }
                            StatusBadgePill(
                                text = "${ai.category} • ${ai.confidencePercent}%",
                                accentColor = accent,
                                containerColor = container
                            )
                        }

                        Text(
                            text = ai.explanationUz,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextPrimary
                        )

                        ai.heuristicFindingsUz.forEach { finding ->
                            Text(
                                text = "• $finding",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }

                        Text(
                            text = ai.recommendedActionUz,
                            style = MaterialTheme.typography.labelMedium,
                            color = accent
                        )
                    }
                }
            }

            if (report.aiErrorMessage != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = WarningAmberContainer.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Gemini AI tahlilida ogohlantirish: ${report.aiErrorMessage}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextPrimary
                        )
                        OutlinedButton(
                            onClick = onRetryGemini,
                            enabled = !isScanning,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("retry_gemini_apk_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Gemini AI bilan qayta tahlil", color = CyberCyan)
                        }
                    }
                }
            } else if (report.aiHeuristicResult == null) {
                OutlinedButton(
                    onClick = onRetryGemini,
                    enabled = !isScanning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("run_gemini_apk_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Gemini AI evristik tahlilni ishga tushirish", color = CyberCyan)
                }
            }

            if (report.suspiciousPermissions.isNotEmpty()) {
                Text(
                    text = "Xavfli ruxsatlar (${report.suspiciousPermissions.size}): ${report.suspiciousPermissions.joinToString("; ")}",
                    style = MaterialTheme.typography.labelSmall,
                    color = accent
                )
            }

            if (report.threatLevel != ThreatLevel.SAFE) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onWhitelist,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("report_whitelist_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.55f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.VerifiedUser,
                            contentDescription = null,
                            tint = ShieldEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Oq ro'yxat", color = ShieldEmerald)
                    }
                    Button(
                        onClick = onOpenFullAlert,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("report_open_alert_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ThreatCrimson,
                            contentColor = CyberTextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Ogohlantirish")
                    }
                }
            }
        }
    }
}
