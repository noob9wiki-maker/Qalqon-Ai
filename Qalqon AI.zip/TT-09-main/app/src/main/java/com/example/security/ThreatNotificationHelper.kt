package com.example.security

import android.content.Context
import com.example.data.ApkScanReport

object ThreatNotificationHelper {

    fun ensureThreatNotificationChannel(context: Context) {
        SecurityNotificationService.ensureThreatNotificationChannel(context)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return SecurityNotificationService.hasNotificationPermission(context)
    }

    fun notifyMaliciousInstalledApp(
        context: Context,
        report: ApkScanReport,
        @Suppress("UNUSED_PARAMETER") notificationId: Int = 0
    ): Boolean {
        return SecurityNotificationService.notifyMaliciousInstalledApp(context, report)
    }

    fun notifyMaliciousFile(
        context: Context,
        report: ApkScanReport
    ): Boolean {
        return SecurityNotificationService.notifyMaliciousFile(context, report)
    }
}
