package com.example.security

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.KeywordRuleEntity
import org.json.JSONObject
import java.io.InputStream

data class ApkPhishingPattern(
    val pattern: String,
    val language: String,
    val descriptionUz: String
)

data class BlacklistRuleSeed(
    val keyword: String,
    val language: String,
    val category: String,
    val severity: String
)

data class BlacklistCatalog(
    val version: Int = 1,
    val apkPhishingPatterns: List<ApkPhishingPattern> = emptyList(),
    val contentRules: List<BlacklistRuleSeed> = emptyList()
)

object BlacklistResourceLoader {
    private const val TAG = "BlacklistLoader"

    @Volatile
    private var cachedCatalog: BlacklistCatalog? = null

    fun loadCatalog(context: Context): BlacklistCatalog {
        cachedCatalog?.let { return it }

        return synchronized(this) {
            cachedCatalog?.let { return it }
            val loaded = runCatching {
                context.resources.openRawResource(R.raw.keyword_blacklist).use { stream ->
                    parseBlacklistJson(stream)
                }
            }.onFailure { err ->
                Log.e(TAG, "Failed to load res/raw/keyword_blacklist.json", err)
            }.getOrDefault(BlacklistCatalog())
            cachedCatalog = loaded
            loaded
        }
    }

    fun parseBlacklistJson(inputStream: InputStream): BlacklistCatalog {
        val rawText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(rawText)
        val version = root.optInt("version", 1)

        val apkArray = root.optJSONArray("apk_phishing_patterns")
        val apkPatterns = buildList {
            if (apkArray != null) {
                for (i in 0 until apkArray.length()) {
                    val obj = apkArray.optJSONObject(i) ?: continue
                    val pattern = obj.optString("pattern").trim()
                    val language = obj.optString("language", "UZ").trim()
                    val descriptionUz = obj.optString("descriptionUz").trim()
                    if (pattern.isNotEmpty() && descriptionUz.isNotEmpty()) {
                        add(ApkPhishingPattern(pattern, language, descriptionUz))
                    }
                }
            }
        }

        val rulesArray = root.optJSONArray("content_blacklist_rules")
        val contentRules = buildList {
            if (rulesArray != null) {
                for (i in 0 until rulesArray.length()) {
                    val obj = rulesArray.optJSONObject(i) ?: continue
                    val keyword = obj.optString("keyword").trim()
                    val language = obj.optString("language", "UZ").trim()
                    val category = obj.optString("category", "EKSTREMIZM").trim()
                    val severity = obj.optString("severity", "CRITICAL").trim()
                    if (keyword.isNotEmpty()) {
                        add(BlacklistRuleSeed(keyword, language, category, severity))
                    }
                }
            }
        }

        return BlacklistCatalog(
            version = version,
            apkPhishingPatterns = apkPatterns,
            contentRules = contentRules
        )
    }

    fun toKeywordRuleEntities(catalog: BlacklistCatalog): List<KeywordRuleEntity> {
        return catalog.contentRules.map { seed ->
            KeywordRuleEntity(
                keyword = seed.keyword,
                language = seed.language,
                category = seed.category,
                isEnabled = true,
                isSystemDefault = true
            )
        }
    }
}
