package com.example.data

enum class ThreatLevel(val labelUz: String) {
    SAFE("XAVFSIZ"),
    SUSPICIOUS("SHUBHALI"),
    CRITICAL("KRITIK XAVF")
}

enum class LogSourceType(val labelUz: String) {
    APK_SCAN("APK Qalqoni"),
    SOCIAL_GUARD("Kontent Qalqoni"),
    ACCOUNT_GUARD("Akkaunt Himoyasi")
}

enum class WhitelistType(val labelUz: String, val hintUz: String) {
    APK_FILE("APK fayl", "Masalan: Ishonchli_Dastur.apk"),
    PACKAGE_NAME("Ilova paketi", "Masalan: uz.gov.my yoki com.click.uz"),
    SOCIAL_CHANNEL("Ijtimoiy kanal", "Masalan: @rasmiy_yangiliklar")
}

enum class AiSensitivity(val titleUz: String, val descriptionUz: String) {
    LOW("Past", "Faqat aniq va kritik xavflarni bloklaydi"),
    MEDIUM("O'rta", "Muvozanatli himoya: firibgarlik va zararli kontent"),
    HIGH("Yuqori", "Maksimal AI sezgirlik: har qanday shubhali ohangni tekshiradi")
}

enum class SocialPlatform(
    val displayName: String,
    val packageNames: List<String>,
    val defaultMonitorMethod: String
) {
    TELEGRAM(
        displayName = "Telegram",
        packageNames = listOf("org.telegram.messenger", "org.thunderdog.challegram"),
        defaultMonitorMethod = "Fayl + OAuth Sessiya Qalqoni"
    ),
    INSTAGRAM(
        displayName = "Instagram",
        packageNames = listOf("com.instagram.android"),
        defaultMonitorMethod = "Accessibility Kontent Qalqoni"
    ),
    YOUTUBE(
        displayName = "YouTube",
        packageNames = listOf("com.google.android.youtube"),
        defaultMonitorMethod = "Accessibility Kontent Qalqoni"
    ),
    FACEBOOK(
        displayName = "Facebook",
        packageNames = listOf("com.facebook.katana", "com.facebook.lite"),
        defaultMonitorMethod = "Accessibility Kontent Qalqoni"
    )
}

data class PermissionStatusSnapshot(
    val hasAllFilesAccess: Boolean = false,
    val hasAccessibilityService: Boolean = false,
    val hasOverlayPermission: Boolean = false,
    val hasNotificationsPermission: Boolean = false,
    val isBatteryOptimizationIgnored: Boolean = false
) {
    val grantedCount: Int
        get() = listOf(
            hasAllFilesAccess,
            hasAccessibilityService,
            hasOverlayPermission,
            hasNotificationsPermission
        ).count { it }

    val allCoreGranted: Boolean
        get() = hasAllFilesAccess && hasAccessibilityService && hasOverlayPermission
}

data class ApkHeuristicMetadata(
    val appLabel: String? = null,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val minSdk: Int? = null,
    val targetSdk: Int? = null,
    val fileSizeBytes: Long = 0L,
    val sha256: String? = null,
    val hasValidApkStructure: Boolean = false,
    val dexFileCount: Int = 0,
    val nativeLibs: List<String> = emptyList(),
    val suspiciousAssets: List<String> = emptyList(),
    val declaredServices: List<String> = emptyList(),
    val declaredReceivers: List<String> = emptyList(),
    val allRequestedPermissions: List<String> = emptyList(),
    val signatureCount: Int = 0,
    val signatureChecked: Boolean = false,
    val activityCount: Int = 0,
    val hasHiddenLauncherIcon: Boolean = false
)

data class ApkHeuristicAiResult(
    val isMalicious: Boolean,
    val riskLevel: ThreatLevel,
    val category: String,
    val confidencePercent: Int,
    val heuristicFindingsUz: List<String>,
    val explanationUz: String,
    val recommendedActionUz: String
)

data class ApkScanReport(
    val fileName: String,
    val filePathOrUri: String,
    val packageName: String?,
    val threatLevel: ThreatLevel,
    val deceptiveNameMatched: String?,
    val suspiciousPermissions: List<String>,
    val reasonUz: String,
    val recommendationUz: String,
    val metadata: ApkHeuristicMetadata = ApkHeuristicMetadata(),
    val aiHeuristicResult: ApkHeuristicAiResult? = null,
    val aiErrorMessage: String? = null
)

data class GeminiAnalysisResult(
    val isHarmful: Boolean,
    val riskLevel: ThreatLevel,
    val category: String,
    val explanationUz: String,
    val recommendedActionUz: String,
    // Dangerous words/hashtags extracted by Gemini from UZ/RU/EN captions and Reels.
    val dangerousKeywords: List<String> = emptyList(),
    val detectedLanguage: String? = null
)

enum class ThreatNotificationCategory(
    val titleUz: String,
    val subtitleUz: String,
    val shortBadgeUz: String
) {
    PHISHING(
        titleUz = "Phishing va aldamchi niqoblar",
        subtitleUz = "Soxta taklifnoma, bank kartasi, SMS-kod phishingi va ikki qavatli (.jpg.apk) fayl niqoblari",
        shortBadgeUz = "Phishing"
    ),
    MALWARE(
        titleUz = "Zararli dasturlar (Malware)",
        subtitleUz = "Kritik troyanlar, SMS/Accessibility ruxsatlarini suiiste'mol qiluvchi APK va zararli yuklovchilar",
        shortBadgeUz = "Malware"
    ),
    SUSPICIOUS_BEHAVIOR(
        titleUz = "Shubhali xatti-harakat",
        subtitleUz = "Evristik xavf signallari, raqamli imzosiz APKlar, eski targetSdk va nostandart fon ruxsatlari",
        shortBadgeUz = "Shubhali xatti-harakat"
    ),
    SOCIAL_THREATS(
        titleUz = "Ijtimoiy tarmoq tahdidlari",
        subtitleUz = "Instagram, YouTube va Facebook'dagi ekstremistik, nafrat va xavfli kontent bloklari",
        shortBadgeUz = "Ijtimoiy tarmoq"
    )
}

data class NotificationPreferences(
    val generalAlertsEnabled: Boolean = true,
    val notifyPhishing: Boolean = true,
    val notifyMalware: Boolean = true,
    val notifySuspiciousBehavior: Boolean = true,
    val notifySocialThreats: Boolean = true,
    val soundEnabled: Boolean = true,
    val quietHoursEnabled: Boolean = false,
    val criticalBypassQuietHours: Boolean = true
) {
    val enabledThreatCategoryCount: Int
        get() = listOf(
            notifyPhishing,
            notifyMalware,
            notifySuspiciousBehavior,
            notifySocialThreats
        ).count { it }

    fun isCategoryEnabled(category: ThreatNotificationCategory): Boolean {
        if (!generalAlertsEnabled) return false
        return when (category) {
            ThreatNotificationCategory.PHISHING -> notifyPhishing
            ThreatNotificationCategory.MALWARE -> notifyMalware
            ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR -> notifySuspiciousBehavior
            ThreatNotificationCategory.SOCIAL_THREATS -> notifySocialThreats
        }
    }

    fun summaryUz(): String {
        if (!generalAlertsEnabled) return "Barcha tahdid bildirishnomalari o'chirilgan"
        val activeNames = buildList {
            if (notifyPhishing) add("Phishing")
            if (notifyMalware) add("Malware")
            if (notifySuspiciousBehavior) add("Shubhali")
            if (notifySocialThreats) add("Ijtimoiy")
        }
        return if (activeNames.isEmpty()) {
            "Hech qaysi tahdid turi tanlanmagan"
        } else {
            activeNames.joinToString(" • ")
        }
    }
}

