package com.example

import android.Manifest
import android.app.Application
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import androidx.biometric.BiometricManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import com.example.data.LogSourceType
import com.example.data.NotificationPreferences
import com.example.data.OverviewRange
import com.example.data.QalqonDatabase
import com.example.data.QalqonPreferencesRepository
import com.example.data.QalqonRepository
import com.example.data.QalqonSettingsState
import com.example.data.ScannedFileEntity
import com.example.data.SecurityOverviewAggregator
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import com.example.data.ThreatNotificationCategory
import com.example.security.ApkThreatAnalyzer
import com.example.security.BiometricAuthManager
import com.example.security.BiometricAvailabilityStatus
import com.example.security.BlacklistResourceLoader
import com.example.security.ContentSafetyClassifier
import com.example.security.InstalledAppsAuditWorker
import com.example.security.PackageInstallReceiver
import com.example.security.PanicModeManager
import com.example.security.SecurityNotificationService
import com.example.security.SensitiveArea
import com.example.ui.QalqonViewModel
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Qalqon AI", appName)
  }

  @Test
  fun `loads externalized keyword blacklist JSON across UZ RU and EN`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val catalog = BlacklistResourceLoader.loadCatalog(context)

    assertTrue(catalog.apkPhishingPatterns.isNotEmpty())
    assertTrue(catalog.contentRules.any { it.language == "UZ" })
    assertTrue(catalog.contentRules.any { it.language == "RU" })
    assertTrue(catalog.contentRules.any { it.language == "EN" })

    ContentSafetyClassifier.loadFromCatalog(catalog)
    val result = ContentSafetyClassifier.classifyText("Iltimos, click parolini kiriting!")
    assertTrue(result.isHarmful)
  }

  @Test
  fun `stores and queries blocked APK and social media threats in Room database`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, QalqonDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    try {
      val dao = db.qalqonDao()
      dao.insertThreatLog(
        ThreatLogEntity(
          sourceType = LogSourceType.APK_SCAN.name,
          title = "XAVF! Zararli fayl aniqlandi!",
          targetName = "To'yga taklifnoma.apk",
          packageNameOrPath = "/storage/Download/Telegram/To'yga taklifnoma.apk",
          threatLevel = ThreatLevel.CRITICAL.name,
          reasonUz = "Aldamchi nom va READ_SMS ruxsati",
          detectedIndicators = "READ_SMS",
          aiExplanation = "Darhol o'chiring",
          actionTaken = "BLOKLANDI"
        )
      )
      dao.insertThreatLog(
        ThreatLogEntity(
          sourceType = LogSourceType.SOCIAL_GUARD.name,
          title = "Bu kontent xavfsiz emas va bloklandi",
          targetName = "Instagram: Zararli post",
          packageNameOrPath = "com.instagram.android",
          threatLevel = ThreatLevel.CRITICAL.name,
          reasonUz = "Ekstremistik chaqiriq",
          detectedIndicators = "jihodga da'vat",
          aiExplanation = "Bloklandi",
          actionTaken = "BLOKLANDI"
        )
      )

      val logs = dao.observeThreatLogs().first()
      assertEquals(2, logs.size)
      assertEquals(1, dao.observeBlockedApkCount().first())
      assertEquals(1, dao.observeBlockedSocialCount().first())
    } finally {
      db.close()
    }
  }

  @Test
  fun `biometric manager configures authenticators and viewModel locks sensitive tabs by default`() {
    val context = ApplicationProvider.getApplicationContext<android.app.Application>()
    val authenticators = BiometricAuthManager.allowedAuthenticators()
    assertTrue((authenticators and BiometricManager.Authenticators.BIOMETRIC_STRONG) != 0)
    assertTrue((authenticators and BiometricManager.Authenticators.BIOMETRIC_WEAK) != 0)
    assertTrue((authenticators and BiometricManager.Authenticators.DEVICE_CREDENTIAL) != 0)

    val availability = BiometricAuthManager.checkAvailability(context)
    assertTrue(availability in BiometricAvailabilityStatus.entries)

    assertTrue(QalqonSettingsState().isBiometricLockEnabled)

    val viewModel = QalqonViewModel(context)
    assertTrue(viewModel.unlockedAreas.value.isEmpty())

    viewModel.unlockSensitiveArea(SensitiveArea.SETTINGS)
    assertTrue(viewModel.unlockedAreas.value.contains(SensitiveArea.SETTINGS))
    assertFalse(viewModel.unlockedAreas.value.contains(SensitiveArea.ACCOUNTS))

    viewModel.unlockSensitiveArea(SensitiveArea.ACCOUNTS)
    assertTrue(viewModel.unlockedAreas.value.contains(SensitiveArea.ACCOUNTS))

    viewModel.lockSensitiveArea(SensitiveArea.SETTINGS)
    assertFalse(viewModel.unlockedAreas.value.contains(SensitiveArea.SETTINGS))
    assertTrue(viewModel.unlockedAreas.value.contains(SensitiveArea.ACCOUNTS))

    viewModel.lockAllSensitiveAreas()
    assertTrue(viewModel.unlockedAreas.value.isEmpty())
  }

  @Test
  fun `apk analyzer extracts forensic metadata and flags hidden dropper assets`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val tempApk = File(context.cacheDir, "test_dropper_app.apk")
    try {
      ZipOutputStream(FileOutputStream(tempApk)).use { zos ->
        zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
        zos.write(byteArrayOf(0x03, 0x00, 0x08, 0x00))
        zos.closeEntry()

        zos.putNextEntry(ZipEntry("classes.dex"))
        zos.write("dex\n035\u0000".toByteArray())
        zos.closeEntry()

        zos.putNextEntry(ZipEntry("assets/hidden_stage2.apk"))
        zos.write(byteArrayOf(0x50, 0x4B, 0x03, 0x04))
        zos.closeEntry()
      }

      val report = ApkThreatAnalyzer.analyzeFile(context, tempApk)
      assertTrue(report.metadata.hasValidApkStructure)
      assertEquals(1, report.metadata.dexFileCount)
      assertTrue(report.metadata.fileSizeBytes > 0L)
      assertTrue(!report.metadata.sha256.isNullOrBlank())
      assertTrue(report.metadata.suspiciousAssets.contains("hidden_stage2.apk"))
      assertEquals(ThreatLevel.SUSPICIOUS, report.threatLevel)
    } finally {
      tempApk.delete()
    }
  }

  @Test
  fun `stores and queries scanned files history with safe or malicious status and timestamp in Room`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, QalqonDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    try {
      val dao = db.qalqonDao()
      val olderSafeId = dao.insertScannedFile(
        ScannedFileEntity(
          fileName = "IshonchliIlova.apk",
          packageName = "uz.trusted.app",
          filePathOrUri = "/storage/emulated/0/Download/IshonchliIlova.apk",
          fileSizeBytes = 2_450_000L,
          sha256 = "abc123def456",
          status = "SAFE",
          riskLevel = ThreatLevel.SAFE.name,
          scanSource = "Qurilmadan tanlangan",
          summaryUz = "Ilova tekshirildi va xavfsiz deb topildi.",
          scannedAt = 1_700_000_000_000L
        )
      )
      val newerMaliciousId = dao.insertScannedFile(
        ScannedFileEntity(
          fileName = "To'yga taklifnoma.apk",
          packageName = "com.fake.taklifnoma",
          filePathOrUri = "/storage/emulated/0/Download/Telegram/To'yga taklifnoma.apk",
          fileSizeBytes = 512_000L,
          sha256 = "deadbeef0011",
          status = "MALICIOUS",
          riskLevel = ThreatLevel.CRITICAL.name,
          scanSource = "Fon FileObserver",
          summaryUz = "Aldamchi nom va SMS o'qish ruxsati aniqlandi.",
          aiCategory = "IJTIMOIY MUHANDISLIK",
          aiConfidencePercent = 97,
          scannedAt = 1_700_000_500_000L
        )
      )

      val allFiles = dao.observeScannedFiles().first()
      assertEquals(2, allFiles.size)
      // Newest timestamp must appear first
      assertEquals(newerMaliciousId, allFiles[0].id)
      assertEquals("MALICIOUS", allFiles[0].status)
      assertEquals(1_700_000_500_000L, allFiles[0].scannedAt)

      assertEquals(olderSafeId, allFiles[1].id)
      assertEquals("SAFE", allFiles[1].status)
      assertEquals(1_700_000_000_000L, allFiles[1].scannedAt)

      assertEquals(1, dao.observeScannedFilesByStatus("SAFE").first().size)
      assertEquals(1, dao.observeScannedFilesByStatus("MALICIOUS").first().size)
      assertEquals(1, dao.observeMaliciousScannedFilesCount().first())

      dao.deleteScannedFileById(olderSafeId)
      assertEquals(1, dao.observeScannedFiles().first().size)

      dao.clearScannedFiles()
      assertTrue(dao.observeScannedFiles().first().isEmpty())
    } finally {
      db.close()
    }
  }

  @Test
  fun `security overview aggregator computes daily blocked threats versus clean files without double counting`() {
    val now = 1_763_481_600_000L // fixed timestamp
    val oneDayMs = 86_400_000L
    val yesterday = now - oneDayMs
    val twoDaysAgo = now - (2 * oneDayMs)

    val scannedFiles = listOf(
      ScannedFileEntity(
        fileName = "safe_today_1.apk",
        filePathOrUri = "/Download/safe_today_1.apk",
        status = "SAFE",
        riskLevel = ThreatLevel.SAFE.name,
        summaryUz = "Xavfsiz",
        scannedAt = now
      ),
      ScannedFileEntity(
        fileName = "safe_today_2.apk",
        filePathOrUri = "/Download/safe_today_2.apk",
        status = "SAFE",
        riskLevel = ThreatLevel.SAFE.name,
        summaryUz = "Xavfsiz",
        scannedAt = now - 60_000L
      ),
      ScannedFileEntity(
        fileName = "trojan_yesterday.apk",
        filePathOrUri = "/Download/Telegram/trojan.apk",
        status = "MALICIOUS",
        riskLevel = ThreatLevel.CRITICAL.name,
        summaryUz = "Zararli",
        scannedAt = yesterday
      )
    )

    val threatLogs = listOf(
      // APK_SCAN log should NOT be double counted with scannedFiles MALICIOUS entry
      ThreatLogEntity(
        timestamp = yesterday,
        sourceType = LogSourceType.APK_SCAN.name,
        title = "XAVF!",
        targetName = "trojan_yesterday.apk",
        packageNameOrPath = "/Download/Telegram/trojan.apk",
        threatLevel = ThreatLevel.CRITICAL.name,
        reasonUz = "Zararli",
        detectedIndicators = "READ_SMS",
        aiExplanation = "Bloklandi",
        actionTaken = "BLOKLANDI"
      ),
      // SOCIAL_GUARD threat SHOULD be included in blocked threats
      ThreatLogEntity(
        timestamp = twoDaysAgo,
        sourceType = LogSourceType.SOCIAL_GUARD.name,
        title = "Bloklangan post",
        targetName = "Instagram: Xavfli post",
        packageNameOrPath = "com.instagram.android",
        threatLevel = ThreatLevel.CRITICAL.name,
        reasonUz = "Ekstremizm",
        detectedIndicators = "keyword",
        aiExplanation = "Bloklandi",
        actionTaken = "BLOKLANDI"
      )
    )

    val summary = SecurityOverviewAggregator.buildOverview(
      scannedFiles = scannedFiles,
      threatLogs = threatLogs,
      range = OverviewRange.DAYS_7,
      nowMillis = now
    )

    assertEquals(7, summary.points.size)
    assertTrue(summary.hasAnyActivity)
    assertEquals(2, summary.totalCleanFiles)
    assertEquals(1, summary.totalBlockedMaliciousApks)
    assertEquals(1, summary.totalBlockedSocialThreats)
    assertEquals(2, summary.totalBlockedThreats)
    assertEquals(4, summary.totalScannedEvents)
    assertEquals(50, summary.safetyRatePercent)

    // Today (last bucket) has 2 clean, 0 threats; yesterday (index 5) has 1 malicious APK; 2 days ago (index 4) has 1 social threat
    val todayPoint = summary.points[6]
    val yesterdayPoint = summary.points[5]
    val twoDaysAgoPoint = summary.points[4]
    assertEquals(2, todayPoint.cleanFilesCount)
    assertEquals(0, todayPoint.totalBlockedThreatsCount)
    assertEquals(1, yesterdayPoint.blockedMaliciousFilesCount)
    assertEquals(1, twoDaysAgoPoint.blockedSocialThreatsCount)

    val emptySummary = SecurityOverviewAggregator.buildOverview(
      scannedFiles = emptyList(),
      threatLogs = emptyList(),
      range = OverviewRange.DAYS_14,
      nowMillis = now
    )
    assertEquals(14, emptySummary.points.size)
    assertFalse(emptySummary.hasAnyActivity)
    assertEquals(100, emptySummary.safetyRatePercent)
  }

  @Test
  fun `workmanager audit worker flags newly installed malicious apk and notifies user once`() = runBlocking {
    val app = ApplicationProvider.getApplicationContext<Application>()
    shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)

    val maliciousPkg = PackageInfo().apply {
      packageName = "com.fake.taklifnoma.audit"
      lastUpdateTime = 1_763_481_000_000L
      requestedPermissions = arrayOf(
        "android.permission.READ_SMS",
        "android.permission.BIND_ACCESSIBILITY_SERVICE"
      )
      applicationInfo = ApplicationInfo().apply {
        packageName = "com.fake.taklifnoma.audit"
        nonLocalizedLabel = "To'yga taklifnoma"
        flags = 0
      }
    }
    shadowOf(app.packageManager).installPackage(maliciousPkg)

    val workerFirstRun = TestListenableWorkerBuilder<InstalledAppsAuditWorker>(app).build()
    val firstResult = workerFirstRun.doWork()
    assertTrue(firstResult is ListenableWorker.Result.Success)
    val output1 = (firstResult as ListenableWorker.Result.Success).outputData
    assertTrue(output1.getInt(InstalledAppsAuditWorker.KEY_CHECKED_COUNT, 0) >= 1)
    assertTrue(output1.getInt(InstalledAppsAuditWorker.KEY_MALICIOUS_COUNT, 0) >= 1)

    val nm = app.getSystemService(NotificationManager::class.java)
    val notifications = shadowOf(nm).allNotifications
    assertTrue(notifications.isNotEmpty())

    val repo = QalqonRepository(app)
    val scanned = repo.scannedFiles.first()
    assertTrue(scanned.any { it.packageName == "com.fake.taklifnoma.audit" && it.status == "MALICIOUS" })

    // Second run with no new/updated apps skips already-audited packages cleanly
    val workerSecondRun = TestListenableWorkerBuilder<InstalledAppsAuditWorker>(app).build()
    val secondResult = workerSecondRun.doWork()
    assertTrue(secondResult is ListenableWorker.Result.Success)
    val output2 = (secondResult as ListenableWorker.Result.Success).outputData
    assertEquals(0, output2.getInt(InstalledAppsAuditWorker.KEY_CHECKED_COUNT, -1))
  }

  @Test
  fun `system notification service pushes immediate local alerts for malicious file and newly installed app`() = runBlocking {
    val app = ApplicationProvider.getApplicationContext<Application>()
    shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
    val nm = app.getSystemService(NotificationManager::class.java)
    nm.cancelAll()

    // 1) Malicious scanned file -> immediate notification
    val maliciousFileReport = ApkThreatAnalyzer.analyzeNameAndPermissions(
      fileName = "Sening videong.apk",
      packageName = "com.fake.video.stealer",
      requestedPermissions = listOf("android.permission.READ_SMS"),
      filePathOrUri = "/storage/emulated/0/Download/Telegram/Sening videong.apk"
    )
    val fileNotified = SecurityNotificationService.notifyMaliciousFile(app, maliciousFileReport)
    assertTrue(fileNotified)
    assertTrue(
      shadowOf(nm).allNotifications.any { n ->
        n.extras.getString("android.title")?.contains("Sening videong.apk") == true
      }
    )

    // 2) Newly installed malicious app event -> logs, records, and notifies immediately
    val pkgName = "com.evil.newly.installed"
    val installedPkg = PackageInfo().apply {
      packageName = pkgName
      lastUpdateTime = 1_763_482_000_000L
      requestedPermissions = arrayOf(
        "android.permission.READ_SMS",
        "android.permission.SYSTEM_ALERT_WINDOW"
      )
      applicationInfo = ApplicationInfo().apply {
        packageName = pkgName
        nonLocalizedLabel = "Karta pul o'tkazmasi"
        flags = 0
      }
    }
    shadowOf(app.packageManager).installPackage(installedPkg)

    PackageInstallReceiver.handleInstalledPackageEvent(app, pkgName)

    assertTrue(
      shadowOf(nm).allNotifications.any { n ->
        n.extras.getString("android.title")?.contains("Karta pul o'tkazmasi") == true
      }
    )
    val repo = QalqonRepository(app)
    assertTrue(repo.scannedFiles.first().any { it.packageName == pkgName && it.status == "MALICIOUS" })
  }

  @Test
  fun `panic mode clears sensitive cache files stops background tasks and locks sensitive areas`() {
    val app = ApplicationProvider.getApplicationContext<Application>()

    // Populate sensitive cache artifacts inside cacheDir and nested subdirs
    val tempScanFile = File(app.cacheDir, "scan_sensitive_123.apk")
    tempScanFile.writeText("sensitive-temp-apk-bytes")
    val nestedDir = File(app.cacheDir, "sensitive_subdir").apply { mkdirs() }
    val nestedFile = File(nestedDir, "token_cache.bin")
    nestedFile.writeBytes(ByteArray(2048) { 0x42 })

    assertTrue(tempScanFile.exists())
    assertTrue(nestedFile.exists())

    val result = PanicModeManager.executePanicLockdown(
      context = app,
      flaggedSuspiciousPackages = setOf("com.fake.trojan.app", "com.spyware.stealer")
    )

    assertFalse(tempScanFile.exists())
    assertFalse(nestedFile.exists())
    assertTrue(result.clearedCacheFilesCount >= 2)
    assertTrue(result.clearedCacheBytes >= 2048L)
    assertEquals(2, result.terminatedProcessesCount)
    assertTrue(result.stoppedBackgroundTasksCount >= 1)
    assertTrue(result.lockedSensitiveTabs)

    val viewModel = QalqonViewModel(app)
    viewModel.unlockSensitiveArea(SensitiveArea.SETTINGS)
    viewModel.unlockSensitiveArea(SensitiveArea.ACCOUNTS)
    assertTrue(viewModel.unlockedAreas.value.isNotEmpty())

    viewModel.triggerPanicMode()
    assertTrue(viewModel.unlockedAreas.value.isEmpty())
  }

  @Test
  fun `notification preferences filter alerts by phishing malware suspicious behavior and quiet hours`() = runBlocking {
    val app = ApplicationProvider.getApplicationContext<Application>()
    shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
    val nm = app.getSystemService(NotificationManager::class.java)
    nm.cancelAll()

    // 1) Verify DataStore persistence of granular notification preferences
    val prefsRepo = QalqonPreferencesRepository(app)
    prefsRepo.applyNotificationPreset(
      NotificationPreferences(
        generalAlertsEnabled = true,
        notifyPhishing = true,
        notifyMalware = false,
        notifySuspiciousBehavior = false,
        notifySocialThreats = true,
        soundEnabled = false,
        quietHoursEnabled = true,
        criticalBypassQuietHours = true
      )
    )
    val stored = prefsRepo.getNotificationPreferences()
    assertTrue(stored.generalAlertsEnabled)
    assertTrue(stored.notifyPhishing)
    assertFalse(stored.notifyMalware)
    assertFalse(stored.notifySuspiciousBehavior)
    assertTrue(stored.notifySocialThreats)
    assertFalse(stored.soundEnabled)
    assertTrue(stored.quietHoursEnabled)
    assertEquals(2, stored.enabledThreatCategoryCount)

    // 2) Verify category classification
    val phishingOnlyReport = ApkThreatAnalyzer.analyzeNameAndPermissions(
      fileName = "To'yga taklifnoma.apk",
      packageName = "com.fake.invite",
      requestedPermissions = emptyList(),
      filePathOrUri = "/Download/To'yga taklifnoma.apk"
    )
    assertTrue(
      SecurityNotificationService.classifyApkThreatCategories(phishingOnlyReport)
        .contains(ThreatNotificationCategory.PHISHING)
    )

    val suspiciousOnlyReport = ApkThreatAnalyzer.analyzeNameAndPermissions(
      fileName = "NostandartIlova.apk",
      packageName = "com.example.nostandart",
      requestedPermissions = listOf(
        "android.permission.INTERNET",
        "android.permission.RECORD_AUDIO"
      ),
      filePathOrUri = "/Download/NostandartIlova.apk",
      hasHiddenLauncherIcon = true
    )
    assertEquals(ThreatLevel.SUSPICIOUS, suspiciousOnlyReport.threatLevel)
    assertEquals(
      setOf(ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR),
      SecurityNotificationService.classifyApkThreatCategories(suspiciousOnlyReport)
    )

    // 3) Filtered delivery: suspicious behavior disabled -> NOT notified
    val suspiciousSent = SecurityNotificationService.notifyMaliciousFile(
      context = app,
      report = suspiciousOnlyReport,
      preferencesOverride = stored,
      currentHourOverride = 14
    )
    assertFalse(suspiciousSent)

    // Phishing enabled -> delivered even during daytime
    val phishingSent = SecurityNotificationService.notifyMaliciousFile(
      context = app,
      report = phishingOnlyReport,
      preferencesOverride = stored,
      currentHourOverride = 14
    )
    assertTrue(phishingSent)

    // 4) General notifications disabled -> nothing delivered
    val disabledAllSent = SecurityNotificationService.notifyMaliciousFile(
      context = app,
      report = phishingOnlyReport,
      preferencesOverride = NotificationPreferences(generalAlertsEnabled = false),
      currentHourOverride = 14
    )
    assertFalse(disabledAllSent)

    // 5) Quiet hours at 23:00: non-critical suppressed even if category enabled, critical bypasses when enabled
    val quietPrefs = NotificationPreferences(
      generalAlertsEnabled = true,
      notifyPhishing = true,
      notifyMalware = true,
      notifySuspiciousBehavior = true,
      notifySocialThreats = true,
      quietHoursEnabled = true,
      criticalBypassQuietHours = true
    )
    assertFalse(
      SecurityNotificationService.notifyMaliciousFile(
        context = app,
        report = suspiciousOnlyReport,
        preferencesOverride = quietPrefs,
        currentHourOverride = 23
      )
    )
    assertTrue(
      SecurityNotificationService.notifyMaliciousFile(
        context = app,
        report = phishingOnlyReport,
        preferencesOverride = quietPrefs,
        currentHourOverride = 23
      )
    )
    assertFalse(
      SecurityNotificationService.notifySocialThreat(
        context = app,
        platformName = "Telegram",
        summaryUz = "Zararli post",
        threatLevel = ThreatLevel.CRITICAL,
        preferencesOverride = stored.copy(notifySocialThreats = false),
        currentHourOverride = 14
      )
    )
  }

  @Test
  fun `excludes Android Google Xiaomi and MIUI system or updated-system apps from malware audit`() = runBlocking {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val pmShadow = shadowOf(app.packageManager)

    val googlePlayServices = PackageInfo().apply {
      packageName = "com.google.android.gms"
      lastUpdateTime = 1_763_481_000_000L
      requestedPermissions = arrayOf(
        "android.permission.READ_SMS",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.QUERY_ALL_PACKAGES"
      )
      applicationInfo = ApplicationInfo().apply {
        packageName = "com.google.android.gms"
        nonLocalizedLabel = "Google Play services"
        flags = ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP
      }
    }
    val xiaomiService = PackageInfo().apply {
      packageName = "com.miui.securitycenter"
      lastUpdateTime = 1_763_481_000_000L
      requestedPermissions = arrayOf("android.permission.BIND_ACCESSIBILITY_SERVICE")
      applicationInfo = ApplicationInfo().apply {
        packageName = "com.miui.securitycenter"
        nonLocalizedLabel = "Security"
        flags = ApplicationInfo.FLAG_UPDATED_SYSTEM_APP
      }
    }
    val oemFlaggedOnly = PackageInfo().apply {
      packageName = "com.xiaomi.mipicks"
      lastUpdateTime = 1_763_481_000_000L
      requestedPermissions = arrayOf("android.permission.REQUEST_INSTALL_PACKAGES")
      applicationInfo = ApplicationInfo().apply {
        packageName = "com.xiaomi.mipicks"
        nonLocalizedLabel = "GetApps"
        flags = 0
      }
    }
    pmShadow.installPackage(googlePlayServices)
    pmShadow.installPackage(xiaomiService)
    pmShadow.installPackage(oemFlaggedOnly)

    assertTrue(ApkThreatAnalyzer.isSystemOrOemApp("com.google.android.gms", googlePlayServices.applicationInfo))
    assertTrue(ApkThreatAnalyzer.isSystemOrOemApp("com.miui.securitycenter", xiaomiService.applicationInfo))
    assertTrue(ApkThreatAnalyzer.isSystemOrOemApp("com.xiaomi.mipicks", oemFlaggedOnly.applicationInfo))
    assertTrue(ApkThreatAnalyzer.isSystemOrOemApp("com.android.vending", null))
    assertFalse(ApkThreatAnalyzer.isSystemOrOemApp("com.thirdparty.userapp", ApplicationInfo().apply { flags = 0 }))

    assertEquals(null, ApkThreatAnalyzer.analyzeInstalledPackage(app, "com.google.android.gms"))
    assertEquals(null, ApkThreatAnalyzer.analyzeInstalledPackage(app, "com.miui.securitycenter"))
    assertEquals(null, ApkThreatAnalyzer.analyzeInstalledPackage(app, "com.xiaomi.mipicks"))
  }

  @Test
  fun `gemini api key defaults to preconfigured key and persists updates in DataStore and SharedPreferences`() = runBlocking {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val prefsRepo = QalqonPreferencesRepository(app)

    assertEquals(
      QalqonPreferencesRepository.DEFAULT_GEMINI_API_KEY,
      prefsRepo.getGeminiApiKeySync()
    )
    assertEquals(
      "AQ.Ab8RN6Jke5z6NQn_x-XqVLs_t-NJLYzuETW1eorI8htPON0R7g",
      prefsRepo.settingsFlow.first().geminiApiKey
    )

    prefsRepo.setGeminiApiKey("custom-test-key-123")
    assertEquals("custom-test-key-123", prefsRepo.getGeminiApiKeySync())
    assertEquals("custom-test-key-123", prefsRepo.settingsFlow.first().geminiApiKey)
  }

  @Test
  fun `analyzeUriSafely filters non-apk URIs and copies valid apk URIs safely to cacheDir`() {
    val app = ApplicationProvider.getApplicationContext<Application>()

    // 1) Non-APK URI returns failure cleanly without crashing
    val textFile = File(app.filesDir, "document.pdf").apply { writeText("not an apk") }
    try {
      val nonApkResult = ApkThreatAnalyzer.analyzeUriSafely(app, android.net.Uri.fromFile(textFile))
      assertTrue(nonApkResult.isFailure)
    } finally {
      textFile.delete()
    }

    // 2) Valid APK URI copies to cacheDir, extracts metadata, and cleans up temp file
    val validApk = File(app.filesDir, "To'y_video.apk")
    try {
      ZipOutputStream(FileOutputStream(validApk)).use { zos ->
        zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
        zos.write(byteArrayOf(0x03, 0x00, 0x08, 0x00))
        zos.closeEntry()
        zos.putNextEntry(ZipEntry("classes.dex"))
        zos.write("dex\n035\u0000".toByteArray())
        zos.closeEntry()
      }

      val apkResult = ApkThreatAnalyzer.analyzeUriSafely(app, android.net.Uri.fromFile(validApk))
      assertTrue(apkResult.isSuccess)
      val report = apkResult.getOrThrow()
      assertEquals("To'y_video.apk", report.fileName)
      assertEquals(ThreatLevel.CRITICAL, report.threatLevel)
      assertTrue(report.metadata.hasValidApkStructure)
      // Temp scan_* file must be deleted after analysis
      assertFalse(app.cacheDir.listFiles()?.any { it.name.startsWith("scan_") } == true)
    } finally {
      validApk.delete()
    }
  }
}
