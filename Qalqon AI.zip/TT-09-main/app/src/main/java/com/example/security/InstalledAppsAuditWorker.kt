package com.example.security

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.data.ApkScanReport
import com.example.data.LogSourceType
import com.example.data.QalqonRepository
import com.example.data.ScannedFileEntity
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

data class InstalledAppsAuditResult(
    val checkedNewAppsCount: Int,
    val maliciousAppsFoundCount: Int,
    val flaggedReports: List<ApkScanReport>,
    val summaryUz: String
)

object InstalledAppsAuditEngine {

    private const val TAG = "InstalledAppsAudit"

    suspend fun runLightweightAudit(
        context: Context,
        forceAudit: Boolean = false
    ): InstalledAppsAuditResult {
        val appContext = context.applicationContext
        val repository = QalqonRepository(appContext)
        val settings = repository.settings.first()

        if (!forceAudit && (!settings.isMasterShieldEnabled || !settings.isPeriodicAppAuditEnabled)) {
            return InstalledAppsAuditResult(
                checkedNewAppsCount = 0,
                maliciousAppsFoundCount = 0,
                flaggedReports = emptyList(),
                summaryUz = "Davriy tekshiruv o'chirilgan."
            )
        }

        val candidatePackages = discoverInstalledUserPackages(appContext)
        val existingSignatures = repository.getAuditedPackageSignatures().toMutableSet()
        val newlyInstalledOrUpdated = candidatePackages.filter { info ->
            val signature = packageSignature(info)
            signature !in existingSignatures
        }

        val flaggedReports = mutableListOf<ApkScanReport>()
        var checkedCount = 0

        for (pkgInfo in newlyInstalledOrUpdated) {
            val pkgName = pkgInfo.packageName ?: continue
            val signature = packageSignature(pkgInfo)
            if (pkgName == appContext.packageName ||
                ApkThreatAnalyzer.isSystemOrOemApp(pkgName, pkgInfo.applicationInfo) ||
                ApkThreatAnalyzer.isOfficialAppPackage(pkgName)
            ) {
                existingSignatures.add(signature)
                continue
            }
            val appLabel = pkgInfo.applicationInfo?.loadLabel(appContext.packageManager)?.toString() ?: pkgName

            if (repository.isApkWhitelisted(appLabel, pkgName)) {
                existingSignatures.add(signature)
                continue
            }

            val report = ApkThreatAnalyzer.analyzeInstalledPackage(appContext, pkgName)
            if (report != null) {
                checkedCount++
                repository.incrementScannedFilesCount(1)

                if (report.threatLevel != ThreatLevel.SAFE) {
                    flaggedReports.add(report)
                    val indicatorsText = report.suspiciousPermissions.joinToString(" • ")

                    repository.logThreat(
                        ThreatLogEntity(
                            sourceType = LogSourceType.APK_SCAN.name,
                            title = "Yangi o'rnatilgan zararli ilova aniqlandi",
                            targetName = report.fileName,
                            packageNameOrPath = pkgName,
                            threatLevel = report.threatLevel.name,
                            reasonUz = report.reasonUz,
                            detectedIndicators = indicatorsText,
                            aiExplanation = report.recommendationUz,
                            actionTaken = "OGOHLANTIRILDI"
                        )
                    )

                    repository.recordScannedFile(
                        ScannedFileEntity(
                            fileName = report.fileName,
                            packageName = pkgName,
                            filePathOrUri = pkgName,
                            status = "MALICIOUS",
                            riskLevel = report.threatLevel.name,
                            scanSource = "WorkManager Davriy Tekshiruvi",
                            summaryUz = report.reasonUz
                        )
                    )

                    SecurityNotificationService.notifyMaliciousInstalledApp(
                        context = appContext,
                        report = report
                    )
                }
            }

            existingSignatures.add(signature)
        }

        val now = System.currentTimeMillis()
        val summaryUz = when {
            flaggedReports.isNotEmpty() ->
                "$checkedCount ta yangi ilova tekshirildi — ${flaggedReports.size} ta zararli APK aniqlandi!"
            checkedCount > 0 ->
                "$checkedCount ta yangi o'rnatilgan ilova tekshirildi — xavf topilmadi."
            else ->
                "Yangi o'rnatilgan ilovalar aniqlanmadi (${candidatePackages.size} ta ilova nazoratda)."
        }

        repository.recordAppAuditRun(
            auditedSignatures = existingSignatures,
            timestamp = now,
            summaryUz = summaryUz
        )

        Log.d(TAG, summaryUz)
        return InstalledAppsAuditResult(
            checkedNewAppsCount = checkedCount,
            maliciousAppsFoundCount = flaggedReports.size,
            flaggedReports = flaggedReports,
            summaryUz = summaryUz
        )
    }

    internal fun discoverInstalledUserPackages(context: Context): List<PackageInfo> {
        val pm = context.packageManager
        val discovered = linkedMapOf<String, PackageInfo>()

        // 1) Visible installed packages
        val installedList = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }
        }.getOrDefault(emptyList())

        installedList.forEach { info ->
            info.packageName?.let { pkg -> discovered[pkg] = info }
        }

        // 2) Launchable apps via <queries> MAIN/LAUNCHER intent (Play-Policy compliant without QUERY_ALL_PACKAGES)
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(launcherIntent, 0)
            }
        }.getOrDefault(emptyList())

        resolveInfos.forEach { ri ->
            val pkg = ri.activityInfo?.packageName ?: return@forEach
            if (!discovered.containsKey(pkg)) {
                runCatching {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkg, 0)
                    }
                }.getOrNull()?.let { info ->
                    discovered[pkg] = info
                }
            }
        }

        return discovered.values.filter { info ->
            val pkg = info.packageName
            val appInfo = info.applicationInfo
            val isSelf = pkg == context.packageName
            !isSelf && !ApkThreatAnalyzer.isSystemOrOemApp(pkg, appInfo) &&
                !ApkThreatAnalyzer.isOfficialAppPackage(pkg)
        }
    }

    internal fun packageSignature(info: PackageInfo): String {
        return "${info.packageName}:${info.lastUpdateTime}"
    }
}

class InstalledAppsAuditWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val forceAudit = inputData.getBoolean(KEY_FORCE_AUDIT, false)
            val result = InstalledAppsAuditEngine.runLightweightAudit(
                context = applicationContext,
                forceAudit = forceAudit
            )
            Result.success(
                workDataOf(
                    KEY_CHECKED_COUNT to result.checkedNewAppsCount,
                    KEY_MALICIOUS_COUNT to result.maliciousAppsFoundCount,
                    KEY_SUMMARY_UZ to result.summaryUz
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Periodic installed apps audit failed", e)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val TAG = "InstalledAppsAuditWorker"
        const val KEY_FORCE_AUDIT = "force_audit"
        const val KEY_CHECKED_COUNT = "checked_count"
        const val KEY_MALICIOUS_COUNT = "malicious_count"
        const val KEY_SUMMARY_UZ = "summary_uz"
    }
}

object InstalledAppsAuditScheduler {
    const val PERIODIC_WORK_NAME = "qalqon_installed_apps_periodic_audit"
    const val IMMEDIATE_WORK_NAME = "qalqon_installed_apps_immediate_audit"
    const val REPEAT_INTERVAL_HOURS = 6L

    fun schedulePeriodicAudit(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .build()

        val request = PeriodicWorkRequestBuilder<InstalledAppsAuditWorker>(
            REPEAT_INTERVAL_HOURS,
            TimeUnit.HOURS
        )
            .setConstraints(constraints)
            .addTag(PERIODIC_WORK_NAME)
            .build()

        runCatching {
            WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }

    fun cancelPeriodicAudit(context: Context) {
        runCatching {
            WorkManager.getInstance(context.applicationContext).cancelUniqueWork(PERIODIC_WORK_NAME)
        }
    }

    fun enqueueImmediateAudit(context: Context) {
        val request = OneTimeWorkRequestBuilder<InstalledAppsAuditWorker>()
            .setInputData(workDataOf(InstalledAppsAuditWorker.KEY_FORCE_AUDIT to true))
            .addTag(IMMEDIATE_WORK_NAME)
            .build()

        runCatching {
            WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                IMMEDIATE_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
