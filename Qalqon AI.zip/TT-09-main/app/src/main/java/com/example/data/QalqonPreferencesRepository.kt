package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

private val Context.qalqonDataStore: DataStore<Preferences> by preferencesDataStore(name = "qalqon_preferences")

data class QalqonSettingsState(
    val isOnboardingCompleted: Boolean = false,
    val isMasterShieldEnabled: Boolean = true,
    val isApkAutoScanEnabled: Boolean = true,
    val isSocialGuardEnabled: Boolean = true,
    val isGeminiAnalysisEnabled: Boolean = true,
    val aiSensitivity: AiSensitivity = AiSensitivity.MEDIUM,
    val scannedFilesCount: Int = 0,
    val isBiometricLockEnabled: Boolean = true,
    val isPeriodicAppAuditEnabled: Boolean = true,
    val lastAppAuditTimestamp: Long = 0L,
    val lastAppAuditSummaryUz: String = "",
    val geminiApiKey: String = QalqonPreferencesRepository.DEFAULT_GEMINI_API_KEY,
    val notificationPreferences: NotificationPreferences = NotificationPreferences()
)

class QalqonPreferencesRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val MASTER_SHIELD = booleanPreferencesKey("master_shield")
        val APK_AUTO_SCAN = booleanPreferencesKey("apk_auto_scan")
        val SOCIAL_GUARD = booleanPreferencesKey("social_guard")
        val GEMINI_ANALYSIS = booleanPreferencesKey("gemini_analysis")
        val AI_SENSITIVITY = stringPreferencesKey("ai_sensitivity")
        val SCANNED_FILES_COUNT = intPreferencesKey("scanned_files_count")
        val BIOMETRIC_LOCK = booleanPreferencesKey("biometric_lock")
        val PERIODIC_APP_AUDIT = booleanPreferencesKey("periodic_app_audit")
        val LAST_APP_AUDIT_TIME = longPreferencesKey("last_app_audit_time")
        val LAST_APP_AUDIT_SUMMARY = stringPreferencesKey("last_app_audit_summary")
        val AUDITED_PACKAGE_SIGNATURES = stringSetPreferencesKey("audited_package_signatures")
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")

        val NOTIF_GENERAL_ALERTS = booleanPreferencesKey("notif_general_alerts")
        val NOTIF_PHISHING = booleanPreferencesKey("notif_phishing")
        val NOTIF_MALWARE = booleanPreferencesKey("notif_malware")
        val NOTIF_SUSPICIOUS = booleanPreferencesKey("notif_suspicious")
        val NOTIF_SOCIAL = booleanPreferencesKey("notif_social")
        val NOTIF_SOUND = booleanPreferencesKey("notif_sound")
        val NOTIF_QUIET_HOURS = booleanPreferencesKey("notif_quiet_hours")
        val NOTIF_CRITICAL_BYPASS = booleanPreferencesKey("notif_critical_bypass")
    }

    val settingsFlow: Flow<QalqonSettingsState> = context.qalqonDataStore.data.map { prefs ->
        val sensitivityName = prefs[Keys.AI_SENSITIVITY] ?: AiSensitivity.MEDIUM.name
        val sensitivity = runCatching { AiSensitivity.valueOf(sensitivityName) }
            .getOrDefault(AiSensitivity.MEDIUM)
        val notifPrefs = mapNotificationPreferences(prefs)
        latestNotificationPreferences = notifPrefs

        val storedApiKey = prefs[Keys.GEMINI_API_KEY]?.takeIf { it.isNotBlank() }
            ?: getMirrorSharedPreferences().getString(SHARED_PREF_API_KEY, null)?.takeIf { it.isNotBlank() }
            ?: DEFAULT_GEMINI_API_KEY

        QalqonSettingsState(
            isOnboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            isMasterShieldEnabled = prefs[Keys.MASTER_SHIELD] ?: true,
            isApkAutoScanEnabled = prefs[Keys.APK_AUTO_SCAN] ?: true,
            isSocialGuardEnabled = prefs[Keys.SOCIAL_GUARD] ?: true,
            isGeminiAnalysisEnabled = prefs[Keys.GEMINI_ANALYSIS] ?: true,
            aiSensitivity = sensitivity,
            scannedFilesCount = prefs[Keys.SCANNED_FILES_COUNT] ?: 0,
            isBiometricLockEnabled = prefs[Keys.BIOMETRIC_LOCK] ?: true,
            isPeriodicAppAuditEnabled = prefs[Keys.PERIODIC_APP_AUDIT] ?: true,
            lastAppAuditTimestamp = prefs[Keys.LAST_APP_AUDIT_TIME] ?: 0L,
            lastAppAuditSummaryUz = prefs[Keys.LAST_APP_AUDIT_SUMMARY] ?: "",
            geminiApiKey = storedApiKey,
            notificationPreferences = notifPrefs
        )
    }

    val notificationPreferencesFlow: Flow<NotificationPreferences> = settingsFlow.map {
        it.notificationPreferences
    }

    private fun mapNotificationPreferences(prefs: Preferences): NotificationPreferences {
        return NotificationPreferences(
            generalAlertsEnabled = prefs[Keys.NOTIF_GENERAL_ALERTS] ?: true,
            notifyPhishing = prefs[Keys.NOTIF_PHISHING] ?: true,
            notifyMalware = prefs[Keys.NOTIF_MALWARE] ?: true,
            notifySuspiciousBehavior = prefs[Keys.NOTIF_SUSPICIOUS] ?: true,
            notifySocialThreats = prefs[Keys.NOTIF_SOCIAL] ?: true,
            soundEnabled = prefs[Keys.NOTIF_SOUND] ?: true,
            quietHoursEnabled = prefs[Keys.NOTIF_QUIET_HOURS] ?: false,
            criticalBypassQuietHours = prefs[Keys.NOTIF_CRITICAL_BYPASS] ?: true
        )
    }

    suspend fun getNotificationPreferences(): NotificationPreferences {
        val loaded = context.qalqonDataStore.data.first().let(::mapNotificationPreferences)
        latestNotificationPreferences = loaded
        return loaded
    }

    fun getNotificationPreferencesBlocking(): NotificationPreferences {
        latestNotificationPreferences?.let { return it }
        return runCatching {
            runBlocking(Dispatchers.IO) { getNotificationPreferences() }
        }.getOrDefault(NotificationPreferences())
    }

    suspend fun setGeneralAlertsEnabled(enabled: Boolean) {
        updateNotificationPreferences { it.copy(generalAlertsEnabled = enabled) }
    }

    suspend fun setCategoryNotificationEnabled(
        category: ThreatNotificationCategory,
        enabled: Boolean
    ) {
        updateNotificationPreferences { current ->
            when (category) {
                ThreatNotificationCategory.PHISHING -> current.copy(notifyPhishing = enabled)
                ThreatNotificationCategory.MALWARE -> current.copy(notifyMalware = enabled)
                ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR -> current.copy(notifySuspiciousBehavior = enabled)
                ThreatNotificationCategory.SOCIAL_THREATS -> current.copy(notifySocialThreats = enabled)
            }
        }
    }

    suspend fun setNotificationSoundEnabled(enabled: Boolean) {
        updateNotificationPreferences { it.copy(soundEnabled = enabled) }
    }

    suspend fun setQuietHoursEnabled(enabled: Boolean) {
        updateNotificationPreferences { it.copy(quietHoursEnabled = enabled) }
    }

    suspend fun setCriticalBypassQuietHours(enabled: Boolean) {
        updateNotificationPreferences { it.copy(criticalBypassQuietHours = enabled) }
    }

    suspend fun applyNotificationPreset(preset: NotificationPreferences) {
        updateNotificationPreferences { preset }
    }

    suspend fun updateNotificationPreferences(
        transform: (NotificationPreferences) -> NotificationPreferences
    ) {
        context.qalqonDataStore.edit { prefs ->
            val current = mapNotificationPreferences(prefs)
            val next = transform(current)
            prefs[Keys.NOTIF_GENERAL_ALERTS] = next.generalAlertsEnabled
            prefs[Keys.NOTIF_PHISHING] = next.notifyPhishing
            prefs[Keys.NOTIF_MALWARE] = next.notifyMalware
            prefs[Keys.NOTIF_SUSPICIOUS] = next.notifySuspiciousBehavior
            prefs[Keys.NOTIF_SOCIAL] = next.notifySocialThreats
            prefs[Keys.NOTIF_SOUND] = next.soundEnabled
            prefs[Keys.NOTIF_QUIET_HOURS] = next.quietHoursEnabled
            prefs[Keys.NOTIF_CRITICAL_BYPASS] = next.criticalBypassQuietHours
            latestNotificationPreferences = next
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.qalqonDataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setMasterShieldEnabled(enabled: Boolean) {
        context.qalqonDataStore.edit { it[Keys.MASTER_SHIELD] = enabled }
    }

    suspend fun setApkAutoScanEnabled(enabled: Boolean) {
        context.qalqonDataStore.edit { it[Keys.APK_AUTO_SCAN] = enabled }
    }

    suspend fun setSocialGuardEnabled(enabled: Boolean) {
        context.qalqonDataStore.edit { it[Keys.SOCIAL_GUARD] = enabled }
    }

    suspend fun setGeminiAnalysisEnabled(enabled: Boolean) {
        context.qalqonDataStore.edit { it[Keys.GEMINI_ANALYSIS] = enabled }
    }

    suspend fun setAiSensitivity(sensitivity: AiSensitivity) {
        context.qalqonDataStore.edit { it[Keys.AI_SENSITIVITY] = sensitivity.name }
    }

    suspend fun incrementScannedFilesCount(by: Int = 1) {
        context.qalqonDataStore.edit { prefs ->
            val current = prefs[Keys.SCANNED_FILES_COUNT] ?: 0
            prefs[Keys.SCANNED_FILES_COUNT] = current + by
        }
    }

    suspend fun setBiometricLockEnabled(enabled: Boolean) {
        context.qalqonDataStore.edit { it[Keys.BIOMETRIC_LOCK] = enabled }
    }

    suspend fun setPeriodicAppAuditEnabled(enabled: Boolean) {
        context.qalqonDataStore.edit { it[Keys.PERIODIC_APP_AUDIT] = enabled }
    }

    suspend fun getAuditedPackageSignatures(): Set<String> {
        return context.qalqonDataStore.data.first()[Keys.AUDITED_PACKAGE_SIGNATURES] ?: emptySet()
    }

    suspend fun recordAppAuditRun(
        auditedSignatures: Set<String>,
        timestamp: Long,
        summaryUz: String
    ) {
        context.qalqonDataStore.edit { prefs ->
            prefs[Keys.AUDITED_PACKAGE_SIGNATURES] = auditedSignatures
            prefs[Keys.LAST_APP_AUDIT_TIME] = timestamp
            prefs[Keys.LAST_APP_AUDIT_SUMMARY] = summaryUz
        }
    }

    suspend fun setGeminiApiKey(apiKey: String) {
        val cleaned = apiKey.trim().ifBlank { DEFAULT_GEMINI_API_KEY }
        getMirrorSharedPreferences().edit().putString(SHARED_PREF_API_KEY, cleaned).apply()
        context.qalqonDataStore.edit { it[Keys.GEMINI_API_KEY] = cleaned }
    }

    fun getGeminiApiKeySync(): String {
        val cached = getMirrorSharedPreferences().getString(SHARED_PREF_API_KEY, null)
        if (!cached.isNullOrBlank()) return cached
        return runCatching {
            runBlocking(Dispatchers.IO) {
                context.qalqonDataStore.data.first()[Keys.GEMINI_API_KEY]
            }
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: DEFAULT_GEMINI_API_KEY
    }

    private fun getMirrorSharedPreferences() =
        context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        const val DEFAULT_GEMINI_API_KEY = "AQ.Ab8RN6Jke5z6NQn_x-XqVLs_t-NJLYzuETW1eorI8htPON0R7g"
        private const val SHARED_PREFS_NAME = "qalqon_gemini_prefs"
        private const val SHARED_PREF_API_KEY = "gemini_api_key"

        @Volatile
        internal var latestNotificationPreferences: NotificationPreferences? = null
    }
}
