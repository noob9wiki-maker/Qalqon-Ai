package com.example.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class OverviewRange(val days: Int, val labelUz: String) {
    DAYS_7(7, "7 kun"),
    DAYS_14(14, "14 kun"),
    DAYS_30(30, "30 kun")
}

data class DailyScanStatPoint(
    val dayStartMillis: Long,
    val shortDateLabel: String,
    val fullDateLabel: String,
    val cleanFilesCount: Int,
    val blockedMaliciousFilesCount: Int,
    val blockedSocialThreatsCount: Int
) {
    val totalBlockedThreatsCount: Int
        get() = blockedMaliciousFilesCount + blockedSocialThreatsCount

    val totalEventsCount: Int
        get() = cleanFilesCount + totalBlockedThreatsCount
}

data class SecurityOverviewSummary(
    val range: OverviewRange,
    val points: List<DailyScanStatPoint>,
    val totalCleanFiles: Int,
    val totalBlockedMaliciousApks: Int,
    val totalBlockedSocialThreats: Int,
    val totalBlockedThreats: Int,
    val totalScannedEvents: Int,
    val safetyRatePercent: Int,
    val peakDay: DailyScanStatPoint?,
    val hasAnyActivity: Boolean
)

object SecurityOverviewAggregator {

    fun empty(range: OverviewRange = OverviewRange.DAYS_7): SecurityOverviewSummary {
        return buildOverview(
            scannedFiles = emptyList(),
            threatLogs = emptyList(),
            range = range
        )
    }

    fun buildOverview(
        scannedFiles: List<ScannedFileEntity>,
        threatLogs: List<ThreatLogEntity>,
        range: OverviewRange,
        nowMillis: Long = System.currentTimeMillis()
    ): SecurityOverviewSummary {
        val dayCount = range.days
        val todayStart = startOfDayMillis(nowMillis)
        val shortFmt = SimpleDateFormat("dd.MM", Locale.getDefault())
        val fullFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

        val cal = Calendar.getInstance().apply {
            timeInMillis = todayStart
            add(Calendar.DAY_OF_YEAR, -(dayCount - 1))
        }

        val dayBuckets = ArrayList<Long>(dayCount)
        repeat(dayCount) {
            dayBuckets.add(cal.timeInMillis)
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        val cleanByDay = HashMap<Long, Int>()
        val maliciousFilesByDay = HashMap<Long, Int>()
        scannedFiles.forEach { file ->
            val key = startOfDayMillis(file.scannedAt)
            if (file.status == "SAFE") {
                cleanByDay[key] = (cleanByDay[key] ?: 0) + 1
            } else {
                maliciousFilesByDay[key] = (maliciousFilesByDay[key] ?: 0) + 1
            }
        }

        // Count social guard threats separately from APK_SCAN threat logs to prevent double counting
        val socialBlockedByDay = HashMap<Long, Int>()
        threatLogs.forEach { log ->
            if (log.sourceType == LogSourceType.SOCIAL_GUARD.name && log.threatLevel != ThreatLevel.SAFE.name) {
                val key = startOfDayMillis(log.timestamp)
                socialBlockedByDay[key] = (socialBlockedByDay[key] ?: 0) + 1
            }
        }

        val points = dayBuckets.map { dayMillis ->
            val date = Date(dayMillis)
            DailyScanStatPoint(
                dayStartMillis = dayMillis,
                shortDateLabel = shortFmt.format(date),
                fullDateLabel = fullFmt.format(date),
                cleanFilesCount = cleanByDay[dayMillis] ?: 0,
                blockedMaliciousFilesCount = maliciousFilesByDay[dayMillis] ?: 0,
                blockedSocialThreatsCount = socialBlockedByDay[dayMillis] ?: 0
            )
        }

        val totalClean = points.sumOf { it.cleanFilesCount }
        val totalMaliciousApks = points.sumOf { it.blockedMaliciousFilesCount }
        val totalSocial = points.sumOf { it.blockedSocialThreatsCount }
        val totalBlocked = totalMaliciousApks + totalSocial
        val totalEvents = totalClean + totalBlocked
        val safetyRate = if (totalEvents == 0) {
            100
        } else {
            ((totalClean * 100f) / totalEvents.toFloat()).roundToInt().coerceIn(0, 100)
        }
        val peakDay = points.maxByOrNull { it.totalEventsCount }?.takeIf { it.totalEventsCount > 0 }

        return SecurityOverviewSummary(
            range = range,
            points = points,
            totalCleanFiles = totalClean,
            totalBlockedMaliciousApks = totalMaliciousApks,
            totalBlockedSocialThreats = totalSocial,
            totalBlockedThreats = totalBlocked,
            totalScannedEvents = totalEvents,
            safetyRatePercent = safetyRate,
            peakDay = peakDay,
            hasAnyActivity = totalEvents > 0
        )
    }

    fun startOfDayMillis(epochMillis: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = epochMillis
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
