package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.R
import com.example.data.PermissionStatusSnapshot
import com.example.security.PermissionHelper
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

private enum class OnboardingStep(val index: Int, val labelUz: String) {
    WELCOME(0, "Tanishuv"),
    STORAGE(1, "Xotira ruxsati"),
    ACCESSIBILITY(2, "Accessibility"),
    OVERLAY(3, "Overlay oynasi"),
    SUMMARY(4, "Tayyor")
}

@Composable
fun OnboardingScreen(
    permissions: PermissionStatusSnapshot,
    onRefreshPermissions: () -> Unit,
    onContinueToApp: () -> Unit
) {
    val context = LocalContext.current
    var currentStepIndex by rememberSaveable { mutableIntStateOf(0) }
    val steps = OnboardingStep.entries
    val currentStep = steps[currentStepIndex]

    BackHandler(enabled = currentStepIndex > 0) {
        currentStepIndex = (currentStepIndex - 1).coerceAtLeast(0)
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        onRefreshPermissions()
    }

    var askedRationaleBefore by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            onRefreshPermissions()
            if (!granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val activity = context as? Activity
                val canAskAgain = activity != null && runCatching {
                    ActivityCompat.shouldShowRequestPermissionRationale(
                        activity,
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                }.getOrDefault(false)
                if (!askedRationaleBefore && !canAskAgain) {
                    PermissionHelper.openNotificationSettingsSafely(context)
                }
            }
        }
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg)
            .safeDrawingPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top stepper bar
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadgePill(
                        text = "BOSQICH ${currentStepIndex + 1} / ${steps.size} • ${currentStep.labelUz.uppercase()}",
                        accentColor = CyberCyan,
                        containerColor = CyberCyanContainer
                    )
                    if (currentStepIndex < steps.lastIndex) {
                        TextButton(
                            onClick = onContinueToApp,
                            modifier = Modifier.testTag("onboarding_skip_button")
                        ) {
                            Text(
                                text = "O'tkazib yuborish",
                                color = CyberTextSecondary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    steps.forEach { step ->
                        val active = step.index <= currentStepIndex
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    if (active) CyberCyan else CyberSurfaceElevated
                                )
                        )
                    }
                }
            }

            // Animated Step Content
            AnimatedContent(
                targetState = currentStep,
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 16.dp),
                transitionSpec = {
                    val forward = targetState.index >= initialState.index
                    val enter = slideInHorizontally { width -> if (forward) width else -width } + fadeIn()
                    val exit = slideOutHorizontally { width -> if (forward) -width else width } + fadeOut()
                    (enter togetherWith exit).using(SizeTransform(clip = false))
                },
                label = "onboarding_step_transition"
            ) { step ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    when (step) {
                        OnboardingStep.WELCOME -> {
                            WelcomeStepContent()
                        }

                        OnboardingStep.STORAGE -> {
                            PermissionStepContent(
                                stepTitle = "Barcha fayllarga ruxsat (Storage Access)",
                                stepSubtitle = "Telegram va Yuklanmalar papkasini real vaqtda himoyalash",
                                description = "Firibgarlar ko'pincha Telegram orqali \"To'yga taklifnoma.apk\", \"Foto albom.apk\" yoki \"Karta pul o'tkazmasi.apk\" kabi zararli ilovalarni yuboradi. Ushbu ruxsat Qalqon AI ga yangi yuklangan fayllarni o'rnatishdan oldin skanerlash imkonini beradi.",
                                bulletPoints = listOf(
                                    "Telegram Documents va Downloads papkalarini jonli kuzatish",
                                    "Ikki qavatli aldamchi kengaytmalarni (.jpg.apk) darhol tutib olish",
                                    "Xavfsiz fayllar uchun Oq ro'yxat (Whitelist) ni qo'llab-quvvatlash"
                                ),
                                icon = Icons.Filled.FolderOpen,
                                granted = permissions.hasAllFilesAccess,
                                actionLabel = if (permissions.hasAllFilesAccess) "Xotira ruxsati berilgan" else "Barcha fayllarga ruxsat berish",
                                buttonTag = "onboarding_perm_storage",
                                onAction = {
                                    runCatching {
                                        context.startActivity(PermissionHelper.createAllFilesAccessIntent(context))
                                    }
                                }
                            )
                        }

                        OnboardingStep.ACCESSIBILITY -> {
                            PermissionStepContent(
                                stepTitle = "Maxsus imkoniyatlar (Accessibility Service)",
                                stepSubtitle = "Instagram, YouTube va Facebook kontent qalqoni",
                                description = "Ijtimoiy tarmoqlarda zararli, ekstremistik, radikal yoki nafrat uyg'otuvchi postlar ochilganda Qalqon AI matnlarni real vaqtda tahlil qiladi va xavfli harakatlarni to'xtatadi.",
                                bulletPoints = listOf(
                                    "O'zbek, Rus va Ingliz tillaridagi post va izohlarni tekshirish",
                                    "Xavfli kontentda Like, Ulashish, Saqlash va Izoh tugmalarini bloklash",
                                    "Faqat tanlangan ijtimoiy tarmoqlarda ishlaydi, shaxsiy parollarni o'qimaydi"
                                ),
                                icon = Icons.Filled.AccessibilityNew,
                                granted = permissions.hasAccessibilityService,
                                actionLabel = if (permissions.hasAccessibilityService) "Accessibility xizmati faol" else "Accessibility xizmatini yoqish",
                                buttonTag = "onboarding_perm_accessibility",
                                onAction = {
                                    runCatching {
                                        context.startActivity(PermissionHelper.createAccessibilitySettingsIntent())
                                    }
                                }
                            )
                        }

                        OnboardingStep.OVERLAY -> {
                            PermissionStepContent(
                                stepTitle = "Ilovalar ustidan ko'rsatish (Overlay)",
                                stepSubtitle = "Zararli fayllarda darhol qizil ogohlantirish chiqarish",
                                description = "Telegram yoki boshqa ilovada zararli APK aniqlanganda Qalqon AI barcha oynalar ustidan \"XAVF! Zararli fayl aniqlandi!\" ogohlantirishini chiqarib, o'rnatishni to'xtatishga yordam beradi.",
                                bulletPoints = listOf(
                                    "Kritik xavflarda tezkor to'liq ekranli qizil ogohlantirish",
                                    "Zararli faylni 1 bosishda o'chirishga yo'naltirish",
                                    "Ijtimoiy tarmoqlarda bloklash ekranini ko'rsatish"
                                ),
                                icon = Icons.Filled.Layers,
                                granted = permissions.hasOverlayPermission,
                                actionLabel = if (permissions.hasOverlayPermission) "Overlay ruxsati berilgan" else "Overlay ruxsatini yoqish",
                                buttonTag = "onboarding_perm_overlay",
                                onAction = {
                                    runCatching {
                                        context.startActivity(PermissionHelper.createOverlayPermissionIntent(context))
                                    }
                                }
                            )
                        }

                        OnboardingStep.SUMMARY -> {
                            SummaryStepContent(
                                permissions = permissions,
                                onRequestNotifications = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        if (permissions.hasNotificationsPermission) {
                                            PermissionHelper.openNotificationSettingsSafely(context)
                                        } else {
                                            val activity = context as? Activity
                                            askedRationaleBefore = activity != null && runCatching {
                                                ActivityCompat.shouldShowRequestPermissionRationale(
                                                    activity,
                                                    Manifest.permission.POST_NOTIFICATIONS
                                                )
                                            }.getOrDefault(false)
                                            try {
                                                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                            } catch (_: Exception) {
                                                PermissionHelper.openNotificationSettingsSafely(context)
                                            }
                                        }
                                    } else {
                                        PermissionHelper.openNotificationSettingsSafely(context)
                                    }
                                },
                                onJumpToStep = { stepIndex -> currentStepIndex = stepIndex }
                            )
                        }
                    }
                }
            }

            // Bottom Stepper Navigation Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStepIndex > 0) {
                    OutlinedButton(
                        onClick = { currentStepIndex-- },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("onboarding_back_button"),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CyberOutline)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = null,
                            tint = CyberTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Orqaga", color = CyberTextPrimary)
                    }
                }

                Button(
                    onClick = {
                        if (currentStepIndex < steps.lastIndex) {
                            currentStepIndex++
                        } else {
                            onContinueToApp()
                        }
                    },
                    modifier = Modifier
                        .weight(if (currentStepIndex > 0) 1.5f else 1f)
                        .height(52.dp)
                        .testTag(
                            if (currentStepIndex == steps.lastIndex) {
                                "onboarding_continue_button"
                            } else {
                                "onboarding_next_button"
                            }
                        ),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = CyberNavyBg
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = when (currentStep) {
                            OnboardingStep.WELCOME -> "Sozlashni boshlash"
                            OnboardingStep.SUMMARY -> "Qalqon AI ni ishga tushirish"
                            else -> "Keyingi bosqich"
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Icon(
                        imageVector = if (currentStep == OnboardingStep.SUMMARY) {
                            Icons.Filled.Shield
                        } else {
                            Icons.AutoMirrored.Filled.ArrowForward
                        },
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun WelcomeStepContent() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(CyberSurface)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_shield_hero),
            contentDescription = "Qalqon AI qalqoni",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, CyberNavyBg.copy(alpha = 0.9f))
                    )
                )
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "Qalqon AI ga xush kelibsiz",
                style = MaterialTheme.typography.headlineMedium,
                color = CyberTextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Qurilmangiz va ijtimoiy tarmoqlaringiz uchun aqlli kiberxavfsizlik himoyasi.",
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )
        }
    }

    WelcomeFeatureTile(
        icon = Icons.Filled.FolderOpen,
        title = "Telegram & APK Phishing Qalqoni",
        subtitle = "Soxta taklifnoma va karta o'tkazmasi ko'rinishidagi zararli APK larni aniqlaydi."
    )
    WelcomeFeatureTile(
        icon = Icons.Filled.AccessibilityNew,
        title = "Instagram, YouTube & Facebook Himoyasi",
        subtitle = "Ekstremistik va zararli kontentga Like, Share va Izoh tugmalarini bloklaydi."
    )
    WelcomeFeatureTile(
        icon = Icons.Filled.VerifiedUser,
        title = "Oq ro'yxat va 24/7 AI Bot",
        subtitle = "Ishonchli ilova hamda kanallarni Oq ro'yxatga qo'shib, qalqonni moslang."
    )
}

@Composable
private fun WelcomeFeatureTile(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, CyberOutline)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = CyberCyanContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = CyberCyan,
                    modifier = Modifier
                        .padding(10.dp)
                        .size(24.dp)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )
            }
        }
    }
}

@Composable
private fun PermissionStepContent(
    stepTitle: String,
    stepSubtitle: String,
    description: String,
    bulletPoints: List<String>,
    icon: ImageVector,
    granted: Boolean,
    actionLabel: String,
    buttonTag: String,
    onAction: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, if (granted) ShieldEmerald.copy(alpha = 0.6f) else CyberCyan.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(
                            if (granted) ShieldEmeraldContainer else CyberCyanContainer,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = stepTitle,
                        tint = if (granted) ShieldEmerald else CyberCyan,
                        modifier = Modifier.size(28.dp)
                    )
                }

                StatusBadgePill(
                    text = if (granted) "Ruxsat berilgan" else "Ruxsat kutilmoqda",
                    accentColor = if (granted) ShieldEmerald else WarningAmber,
                    containerColor = if (granted) ShieldEmeraldContainer else WarningAmberContainer
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stepTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stepSubtitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = CyberCyan
                )
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = CyberTextSecondary
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                bulletPoints.forEach { point ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Security,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier
                                .padding(top = 2.dp)
                                .size(16.dp)
                        )
                        Text(
                            text = point,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onAction,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag(buttonTag),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (granted) ShieldEmeraldContainer else CyberCyan,
                    contentColor = if (granted) ShieldEmerald else CyberNavyBg
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = if (granted) Icons.Filled.CheckCircle else icon,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun SummaryStepContent(
    permissions: PermissionStatusSnapshot,
    onRequestNotifications: () -> Unit,
    onJumpToStep: (Int) -> Unit
) {
    Text(
        text = "Tayyorgarlik holati",
        style = MaterialTheme.typography.headlineSmall,
        color = CyberTextPrimary,
        fontWeight = FontWeight.Bold
    )
    Text(
        text = "Asosiy tizim ruxsatlari holatini tekshiring. Xohlasangiz istalgan bosqichga qaytib ruxsat berishingiz mumkin.",
        style = MaterialTheme.typography.bodySmall,
        color = CyberTextSecondary
    )

    SummaryCheckRow(
        title = "Barcha fayllarga ruxsat (Storage Access)",
        granted = permissions.hasAllFilesAccess,
        onClick = { onJumpToStep(OnboardingStep.STORAGE.index) }
    )
    SummaryCheckRow(
        title = "Maxsus imkoniyatlar (Accessibility Service)",
        granted = permissions.hasAccessibilityService,
        onClick = { onJumpToStep(OnboardingStep.ACCESSIBILITY.index) }
    )
    SummaryCheckRow(
        title = "Ilovalar ustidan ko'rsatish (Overlay)",
        granted = permissions.hasOverlayPermission,
        onClick = { onJumpToStep(OnboardingStep.OVERLAY.index) }
    )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Surface(
            onClick = onRequestNotifications,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("onboarding_perm_notifications"),
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(
                1.dp,
                if (permissions.hasNotificationsPermission) ShieldEmerald.copy(alpha = 0.5f) else CyberOutline
            )
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.NotificationsActive,
                        contentDescription = "Bildirishnomalar",
                        tint = if (permissions.hasNotificationsPermission) ShieldEmerald else CyberCyan
                    )
                    Column {
                        Text(
                            text = "Bildirishnomalar (Tavsiya etiladi)",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = if (permissions.hasNotificationsPermission) "Ruxsat berilgan" else "Bosib ruxsat bering",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }
                Icon(
                    imageVector = if (permissions.hasNotificationsPermission) {
                        Icons.Filled.CheckCircle
                    } else {
                        Icons.Filled.RadioButtonUnchecked
                    },
                    contentDescription = null,
                    tint = if (permissions.hasNotificationsPermission) ShieldEmerald else CyberTextMuted
                )
            }
        }
    }
}

@Composable
private fun SummaryCheckRow(
    title: String,
    granted: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (granted) ShieldEmerald.copy(alpha = 0.5f) else WarningAmber.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = CyberTextPrimary,
                modifier = Modifier.weight(1f)
            )
            StatusBadgePill(
                text = if (granted) "Tayyor" else "O'tish",
                accentColor = if (granted) ShieldEmerald else WarningAmber,
                containerColor = if (granted) ShieldEmeraldContainer else WarningAmberContainer
            )
        }
    }
}
