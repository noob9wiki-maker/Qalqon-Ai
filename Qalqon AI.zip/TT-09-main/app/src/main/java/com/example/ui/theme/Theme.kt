package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val QalqonDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = CyberNavyBg,
    primaryContainer = CyberCyanContainer,
    onPrimaryContainer = CyberCyan,
    secondary = ShieldEmerald,
    onSecondary = CyberNavyBg,
    secondaryContainer = ShieldEmeraldContainer,
    onSecondaryContainer = ShieldEmerald,
    tertiary = WarningAmber,
    onTertiary = CyberNavyBg,
    tertiaryContainer = WarningAmberContainer,
    onTertiaryContainer = WarningAmber,
    error = ThreatCrimson,
    onError = CyberTextPrimary,
    errorContainer = ThreatCrimsonContainer,
    onErrorContainer = ThreatCrimson,
    background = CyberNavyBg,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = CyberTextSecondary,
    surfaceContainerLow = CyberSurface,
    surfaceContainer = CyberSurfaceElevated,
    surfaceContainerHigh = CyberSurfaceBright,
    outline = CyberOutline,
    outlineVariant = CyberOutline
)

val QalqonShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun QalqonAITheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = QalqonDarkColorScheme,
        typography = QalqonTypography,
        shapes = QalqonShapes,
        content = content
    )
}
