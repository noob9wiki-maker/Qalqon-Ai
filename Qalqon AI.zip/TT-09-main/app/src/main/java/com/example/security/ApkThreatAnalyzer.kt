package com.example.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.data.ApkHeuristicMetadata
import com.example.data.ApkScanReport
import com.example.data.ThreatLevel
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipFile

object ApkThreatAnalyzer {

    @Volatile
    private var externalDeceptivePatterns: List<Pair<String, String>> = emptyList()

    fun ensureInitialized(context: Context) {
        if (externalDeceptivePatterns.isEmpty()) {
            val catalog = BlacklistResourceLoader.loadCatalog(context)
            externalDeceptivePatterns = catalog.apkPhishingPatterns.map {
                it.pattern to it.descriptionUz
            }
        }
    }

    private val deceptiveNamePatterns = listOf(
        // Uzbek social engineering traps
        "toyga taklifnoma" to "\"To'yga taklifnoma\" niqobi (Telegram troyani)",
        "taklifnoma" to "Soxta taklifnoma APK niqobi",
        "foto albom" to "\"Foto albom\" aldamchi APK niqobi",
        "fotoalbom" to "\"Foto albom\" aldamchi APK niqobi",
        "albom" to "\"Albom\" ko'rinishidagi aldamchi APK niqobi",
        "sening videong" to "\"Sening videong\" phishing APK niqobi",
        "sizning videongiz" to "\"Sizning videongiz\" phishing APK niqobi",
        "karta pul otkazmasi" to "\"Karta pul o'tkazmasi\" moliyaviy troyan niqobi",
        "pul otkazmasi" to "Soxta pul o'tkazmasi APK niqobi",
        "karta" to "Bank kartasi bilan bog'liq shubhali APK niqobi",
        "tabriknoma" to "\"Tabriknoma\" aldamchi APK niqobi",
        "rasm" to "\"Rasm\" ko'rinishidagi zararli APK niqobi",
        "rasmlar" to "\"Rasmlar\" ko'rinishidagi zararli APK niqobi",
        "sovga" to "Soxta sovg'a/yutuq APK niqobi",
        "yutuq" to "Soxta yutuq APK niqobi",
        "mukofot" to "Soxta mukofot APK niqobi",
        "ish haqi" to "Soxta maosh hujjati APK niqobi",
        "oylik" to "Soxta oylik hisobot APK niqobi",
        "hujjat" to "Hujjat ko'rinishidagi APK niqobi",
        "video" to "Video fayl ko'rinishidagi APK niqobi",
        "toy" to "\"To'y\" ko'rinishidagi aldamchi APK niqobi",
        "toyga" to "\"To'yga\" taklif niqobidagi APK",
        // Russian social engineering traps
        "приглашение на свадьбу" to "\"Приглашение на свадьбу\" zararli APK niqobi",
        "приглашение" to "Soxta taklifnoma (приглашение) APK niqobi",
        "фотоальбом" to "\"Фотоальбом\" aldamchi APK niqobi",
        "альбом" to "\"Альбом\" aldamchi APK niqobi",
        "твое видео" to "\"Твое видео\" phishing APK niqobi",
        "ваше видео" to "\"Ваше видео\" phishing APK niqobi",
        "перевод на карту" to "\"Перевод на карту\" bank troyani niqobi",
        "поздравление" to "\"Поздравление\" aldamchi APK niqobi",
        "открытка" to "\"Открытка\" aldamchi APK niqobi",
        "фото" to "\"Фото\" ko'rinishidagi APK niqobi",
        "выигрыш" to "Soxta yutuq (выигрыш) APK niqobi"
    )

    private val apkOnlyAmbiguousKeywords = setOf(
        "video", "rasm", "rasmlar", "karta", "hujjat", "oylik", "фото"
    )

    private val highRiskPermissions = mapOf(
        "android.permission.READ_SMS" to "SMS xabarlarni o'qish (OTP o'g'irlash xavfi)",
        "android.permission.RECEIVE_SMS" to "Kiruvchi SMSlarni tutib olish",
        "android.permission.SEND_SMS" to "Yashirin SMS yuborish",
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to "Ekranni to'liq boshqarish (Accessibility suiiste'moli)",
        "android.permission.SYSTEM_ALERT_WINDOW" to "Soxta ekran oynasi chiqarish",
        "android.permission.REQUEST_INSTALL_PACKAGES" to "Boshqa zararli ilovalarni yashirin o'rnatish",
        "android.permission.READ_CALL_LOG" to "Qo'ng'iroqlar tarixini o'qish",
        "android.permission.READ_CONTACTS" to "Kontaktlar ro'yxatini yuklab olish",
        "android.permission.QUERY_ALL_PACKAGES" to "Barcha o'rnatilgan ilovalar ro'yxatini ko'rish"
    )

    fun analyzeFile(context: Context, file: File): ApkScanReport {
        return analyzeFileWithName(
            context = context,
            file = file,
            displayName = file.name,
            filePathOrUri = file.absolutePath
        )
    }

    fun analyzeFileWithName(
        context: Context,
        file: File,
        displayName: String,
        filePathOrUri: String
    ): ApkScanReport {
        ensureInitialized(context)
        val packageInfo = getArchiveInfo(context, file.absolutePath)
        val metadata = extractArchiveMetadata(context, file, packageInfo)
        return buildReport(
            fileName = displayName,
            filePathOrUri = filePathOrUri,
            packageInfo = packageInfo,
            metadata = metadata
        )
    }

    fun analyzeUriSafely(context: Context, uri: Uri): Result<ApkScanReport> {
        ensureInitialized(context)
        val fileName = resolveDisplayName(context, uri)
        val mimeType = runCatching { context.contentResolver.getType(uri) }.getOrNull()
        val hasApkExtension = fileName.endsWith(".apk", ignoreCase = true)
        val isApkMime = mimeType.equals("application/vnd.android.package-archive", ignoreCase = true)

        if (!hasApkExtension && !isApkMime) {
            return Result.failure(
                IllegalArgumentException("Faqat .apk kengaytmali fayllarni tanlang (tanlangan: $fileName).")
            )
        }

        val uniqueSuffix = kotlin.math.abs(uri.toString().hashCode())
        val tempFile = File(context.cacheDir, "scan_${System.currentTimeMillis()}_$uniqueSuffix.apk")
        return try {
            val copied = try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                    true
                } ?: false
            } catch (e: Exception) {
                return Result.failure(
                    IllegalStateException("Fayl oqimini o'qib bo'lmadi: ${e.localizedMessage ?: "ruxsat yoki I/O xatoligi"}")
                )
            }

            if (!copied || !tempFile.exists() || tempFile.length() == 0L) {
                return Result.failure(
                    IllegalStateException("Tanlangan fayl bo'sh yoki ochilmadi: $fileName")
                )
            }

            val report = analyzeFileWithName(
                context = context,
                file = tempFile,
                displayName = fileName,
                filePathOrUri = uri.toString()
            )
            Result.success(report)
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("APK tahlilida xatolik: ${e.localizedMessage ?: "noma'lum xatolik"}")
            )
        } finally {
            runCatching { tempFile.delete() }
        }
    }

    fun analyzeUri(context: Context, uri: Uri): ApkScanReport {
        val fileName = resolveDisplayName(context, uri)
        return analyzeUriSafely(context, uri).getOrElse { err ->
            ApkScanReport(
                fileName = fileName,
                filePathOrUri = uri.toString(),
                packageName = null,
                threatLevel = ThreatLevel.SAFE,
                deceptiveNameMatched = null,
                suspiciousPermissions = emptyList(),
                reasonUz = err.message ?: "Faylni o'qib bo'lmadi.",
                recommendationUz = "Faylni qayta tanlab tekshiring."
            )
        }
    }

    fun analyzeNameAndPermissions(
        fileName: String,
        packageName: String?,
        requestedPermissions: List<String>,
        filePathOrUri: String = fileName,
        hasHiddenLauncherIcon: Boolean = false,
        isUnsigned: Boolean = false
    ): ApkScanReport {
        val deceptiveMatch = detectDeceptiveFilename(fileName)
        val doubleExtension = detectDoubleExtension(fileName)
        val matchedPermissions = requestedPermissions.filter { highRiskPermissions.containsKey(it) }
        val metadata = ApkHeuristicMetadata(
            hasValidApkStructure = true,
            allRequestedPermissions = requestedPermissions,
            signatureCount = if (isUnsigned) 0 else 1,
            signatureChecked = isUnsigned,
            hasHiddenLauncherIcon = hasHiddenLauncherIcon
        )
        return evaluateThreat(
            fileName = fileName,
            filePathOrUri = filePathOrUri,
            packageName = packageName,
            deceptiveMatch = deceptiveMatch,
            doubleExtension = doubleExtension,
            suspiciousPermissions = matchedPermissions,
            metadata = metadata
        )
    }

    private val systemPackagePrefixes = listOf(
        "com.android.",
        "com.google.android.",
        "com.xiaomi.",
        "com.miui.",
        "android."
    )

    // Well-known first-party packages must never be reported as malicious, even when
    // a heuristic rule or Gemini would otherwise flag one of their permissions.
    private val officialTrustedPackagePrefixes = listOf(
        "org.telegram.",
        "com.whatsapp",
        "com.instagram.",
        "com.google.",
        "com.facebook.",
        "com.openai.",
        "com.microsoft.",
        "com.android.",
        "com.xiaomi.",
        "com.miui."
    )

    fun isOfficialAppPackage(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        val lowerPkg = packageName.lowercase(Locale.ROOT)
        return officialTrustedPackagePrefixes.any { lowerPkg.startsWith(it) }
    }

    fun isSystemOrOemApp(packageName: String?, appInfo: ApplicationInfo?): Boolean {
        if (packageName.isNullOrBlank()) return false
        val lowerPkg = packageName.lowercase()
        if (lowerPkg == "android" || systemPackagePrefixes.any { lowerPkg.startsWith(it) }) {
            return true
        }
        if (appInfo != null) {
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            if (isSystem || isUpdatedSystem) {
                return true
            }
        }
        return false
    }

    fun analyzeInstalledPackage(context: Context, packageName: String): ApkScanReport? {
        return try {
            if (packageName == context.packageName || isOfficialAppPackage(packageName)) return null
            ensureInitialized(context)
            val pm = context.packageManager
            val queryFlags = PackageManager.GET_PERMISSIONS or
                PackageManager.GET_ACTIVITIES or
                PackageManager.GET_SERVICES or
                PackageManager.GET_RECEIVERS
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(
                    packageName,
                    PackageManager.PackageInfoFlags.of(queryFlags.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, queryFlags)
            }
            if (isSystemOrOemApp(packageName, info.applicationInfo)) {
                return null
            }
            val appLabel = info.applicationInfo?.loadLabel(pm)?.toString() ?: packageName
            val perms = info.requestedPermissions?.toList().orEmpty()
            val deceptiveMatch = detectDeceptiveFilename(
                rawName = appLabel,
                isInstalledPackageLabel = true
            )
            val matchedPerms = perms.filter { highRiskPermissions.containsKey(it) }
            val hasLaunchIntent = runCatching {
                pm.getLaunchIntentForPackage(packageName) != null
            }.getOrDefault(true)
            val activityCount = info.activities?.size ?: 0
            val hasBackgroundComponents = !info.services.isNullOrEmpty() || !info.receivers.isNullOrEmpty()
            val hasHiddenLauncherIcon = !hasLaunchIntent &&
                (activityCount == 0 || hasBackgroundComponents) &&
                perms.any { it != "android.permission.INTERNET" }

            evaluateThreat(
                fileName = appLabel,
                filePathOrUri = packageName,
                packageName = packageName,
                deceptiveMatch = deceptiveMatch,
                doubleExtension = false,
                suspiciousPermissions = matchedPerms,
                metadata = ApkHeuristicMetadata(
                    appLabel = appLabel,
                    versionName = info.versionName,
                    versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else @Suppress("DEPRECATION") info.versionCode.toLong(),
                    targetSdk = info.applicationInfo?.targetSdkVersion,
                    hasValidApkStructure = true,
                    declaredServices = info.services?.mapNotNull { it.name?.substringAfterLast('.') }?.distinct()?.take(12).orEmpty(),
                    declaredReceivers = info.receivers?.mapNotNull { it.name?.substringAfterLast('.') }?.distinct()?.take(12).orEmpty(),
                    allRequestedPermissions = perms,
                    activityCount = activityCount,
                    hasHiddenLauncherIcon = hasHiddenLauncherIcon
                )
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun buildReport(
        fileName: String,
        filePathOrUri: String,
        packageInfo: PackageInfo?,
        metadata: ApkHeuristicMetadata
    ): ApkScanReport {
        val deceptiveMatch = detectDeceptiveFilename(fileName)
        val doubleExtension = detectDoubleExtension(fileName)
        val requestedPermissions = packageInfo?.requestedPermissions?.toList().orEmpty()
        val suspiciousPermissions = requestedPermissions.filter { highRiskPermissions.containsKey(it) }

        return evaluateThreat(
            fileName = fileName,
            filePathOrUri = filePathOrUri,
            packageName = packageInfo?.packageName ?: if (metadata.hasValidApkStructure) "noma'lum.paket" else null,
            deceptiveMatch = deceptiveMatch,
            doubleExtension = doubleExtension,
            suspiciousPermissions = suspiciousPermissions,
            metadata = metadata
        )
    }

    private fun evaluateThreat(
        fileName: String,
        filePathOrUri: String,
        packageName: String?,
        deceptiveMatch: String?,
        doubleExtension: Boolean,
        suspiciousPermissions: List<String>,
        metadata: ApkHeuristicMetadata
    ): ApkScanReport {
        if (isOfficialAppPackage(packageName)) {
            return ApkScanReport(
                fileName = fileName,
                filePathOrUri = filePathOrUri,
                packageName = packageName,
                threatLevel = ThreatLevel.SAFE,
                deceptiveNameMatched = null,
                suspiciousPermissions = emptyList(),
                reasonUz = "Rasmiy taniqlangan ilova paketi ($packageName) ishonchli manba sifatida xavfsiz deb belgilandi.",
                recommendationUz = "Rasmiy ilova: qo'shimcha chora talab qilinmaydi. Yangilanishlarni faqat rasmiy do'kondan oling.",
                metadata = metadata
            )
        }

        val allPerms = metadata.allRequestedPermissions.toSet()
        val hasInternet = allPerms.contains("android.permission.INTERNET")
        val hasBoot = allPerms.contains("android.permission.RECEIVE_BOOT_COMPLETED")
        val hasCameraOrMic = allPerms.contains("android.permission.CAMERA") ||
            allPerms.contains("android.permission.RECORD_AUDIO")

        val hasSmsReadOrReceive = allPerms.contains("android.permission.READ_SMS") ||
            allPerms.contains("android.permission.RECEIVE_SMS")
        val hasAnySms = hasSmsReadOrReceive || allPerms.contains("android.permission.SEND_SMS")
        val hasAccessibility = allPerms.contains("android.permission.BIND_ACCESSIBILITY_SERVICE")
        val hasOverlay = allPerms.contains("android.permission.SYSTEM_ALERT_WINDOW")
        val hasInstallPackages = allPerms.contains("android.permission.REQUEST_INSTALL_PACKAGES")
        val hasContacts = allPerms.contains("android.permission.READ_CONTACTS")
        val hasCallLog = allPerms.contains("android.permission.READ_CALL_LOG")

        val hasDropperAssets = metadata.suspiciousAssets.isNotEmpty()
        val hasLowTargetSdk = metadata.targetSdk != null && metadata.targetSdk in 1..28
        val isUnsignedValidApk = metadata.signatureChecked && metadata.signatureCount == 0
        val hasHiddenIcon = metadata.hasHiddenLauncherIcon

        val hasSmsNetworkCombo = hasAnySms && (hasInternet || hasContacts || hasBoot || hasOverlay || isUnsignedValidApk)
        val hasAccessibilityOverlayCombo = hasAccessibility && (hasOverlay || hasInternet || hasInstallPackages || hasAnySms || isUnsignedValidApk)
        val hasHiddenIconCriticalCombo = hasHiddenIcon && (hasAnySms || hasAccessibility || (hasOverlay && hasInternet) || hasInstallPackages)
        val hasHiddenIconSpyware = hasHiddenIcon && hasInternet && (hasCameraOrMic || hasContacts || hasCallLog || hasBoot)
        val hasDropperCriticalCombo = hasDropperAssets && (hasInstallPackages || hasAnySms || hasAccessibility || isUnsignedValidApk)
        val hasOverlayInstallerCombo = hasOverlay && hasInstallPackages && (hasInternet || isUnsignedValidApk || hasBoot)
        val hasSpywareDataCombo = hasCallLog && hasContacts && hasInternet && (hasBoot || isUnsignedValidApk)

        val coreMalwarePermCount = listOf(
            hasSmsReadOrReceive,
            allPerms.contains("android.permission.SEND_SMS"),
            hasAccessibility,
            hasOverlay,
            hasInstallPackages,
            hasCallLog
        ).count { it }

        val threatLevel = when {
            deceptiveMatch != null -> ThreatLevel.CRITICAL
            doubleExtension -> ThreatLevel.CRITICAL
            hasSmsNetworkCombo -> ThreatLevel.CRITICAL
            hasAccessibilityOverlayCombo -> ThreatLevel.CRITICAL
            hasHiddenIconCriticalCombo -> ThreatLevel.CRITICAL
            hasDropperCriticalCombo -> ThreatLevel.CRITICAL
            coreMalwarePermCount >= 3 -> ThreatLevel.CRITICAL
            hasDropperAssets -> ThreatLevel.SUSPICIOUS
            hasHiddenIcon || hasHiddenIconSpyware -> ThreatLevel.SUSPICIOUS
            hasOverlayInstallerCombo || hasSpywareDataCombo -> ThreatLevel.SUSPICIOUS
            hasSmsReadOrReceive || hasAccessibility -> ThreatLevel.SUSPICIOUS
            else -> ThreatLevel.SAFE
        }

        val reasons = buildList {
            if (deceptiveMatch != null) add(deceptiveMatch)
            if (doubleExtension) add("Ikki qavatli aldamchi fayl kengaytmasi (.jpg/.mp4/.pdf bilan niqoblangan .apk)")
            if (hasHiddenIcon) add("Yashirin ishga tushirgich (launcher belgisi yashirilgan APK)")
            if (hasSmsNetworkCombo) {
                add("Bank va Telegram SMS kodlarini o'qib internetga uzatish kombinatsiyasi (SMS + INTERNET)")
            } else if (hasSmsReadOrReceive) {
                add("Bank va Telegram SMS kodlarini yashirin o'qish ruxsati aniqlandi")
            }
            if (hasAccessibilityOverlayCombo) {
                add("Accessibility va ekran usti oynasi (Overlay) kombinatsiyasi — qurilmani yashirin boshqarish xavfi")
            } else if (hasAccessibility) {
                add("Qurilmani masofadan boshqaruvchi Accessibility suiiste'moli")
            }
            if (hasOverlayInstallerCombo) {
                add("Soxta oyna (Overlay) va yashirin APK o'rnatish kombinatsiyasi")
            }
            if (hasDropperAssets) {
                add("Arxiv ichida yashirin bajariluvchi fayllar topildi (${metadata.suspiciousAssets.joinToString(", ")})")
            }
            if (threatLevel != ThreatLevel.SAFE && hasLowTargetSdk) {
                add("Eski Android targetSdk (${metadata.targetSdk}) — tizim cheklovlarini aylanib o'tish alomati")
            }
            if (threatLevel != ThreatLevel.SAFE && isUnsignedValidApk) {
                add("APK raqamli imzosi aniqlanmadi")
            }
        }

        val reasonUz = if (reasons.isEmpty()) {
            if (!metadata.hasValidApkStructure && metadata.fileSizeBytes > 0L) {
                "Fayl standart Android APK tuzilmasiga ega emas, lekin lokal xavfli alomat topilmadi."
            } else {
                "Lokal tekshiruvda aldamchi nom, yashirin belgi yoki zararli ruxsatlar kombinatsiyasi topilmadi."
            }
        } else {
            reasons.joinToString(". ")
        }

        val recommendationUz = when (threatLevel) {
            ThreatLevel.CRITICAL -> "Bu faylni ASLO o'rnatmang! Darhol qurilmadan o'chirib tashlang va Telegram yuboruvchisini bloklang."
            ThreatLevel.SUSPICIOUS -> "O'rnatishdan oldin manbani tekshiring. Evristik va ruxsat kombinatsiyasi xavflari mavjud."
            ThreatLevel.SAFE -> "Lokal mezonlar bo'yicha xavfsiz ko'rinadi, ammo faqat ishonchli manbalardan o'rnatish tavsiya etiladi."
        }

        return ApkScanReport(
            fileName = fileName,
            filePathOrUri = filePathOrUri,
            packageName = packageName,
            threatLevel = threatLevel,
            deceptiveNameMatched = deceptiveMatch,
            suspiciousPermissions = suspiciousPermissions.map { perm ->
                val short = perm.substringAfterLast('.')
                val desc = highRiskPermissions[perm]
                if (desc != null) "$short — $desc" else short
            },
            reasonUz = reasonUz,
            recommendationUz = recommendationUz,
            metadata = metadata
        )
    }

    fun detectDeceptiveFilename(
        rawName: String,
        isInstalledPackageLabel: Boolean = false
    ): String? {
        val baseName = rawName.replace(Regex("\\.apk$", RegexOption.IGNORE_CASE), "")
        val normalized = normalizeUzbekLatin(baseName).trim()
        if (normalized.isEmpty()) return null
        val words = normalized.split(Regex("\\s+")).filter { it.isNotEmpty() }.toSet()

        val allPatterns = if (isInstalledPackageLabel) {
            (externalDeceptivePatterns + deceptiveNamePatterns).filterNot { (pattern, _) ->
                pattern in apkOnlyAmbiguousKeywords
            }
        } else {
            externalDeceptivePatterns + deceptiveNamePatterns
        }

        return allPatterns.firstOrNull { (pattern, _) ->
            matchesWordBoundary(normalized, words, pattern)
        }?.second
    }

    private fun matchesWordBoundary(
        normalizedText: String,
        words: Set<String>,
        pattern: String
    ): Boolean {
        val cleanPattern = pattern.trim()
        if (cleanPattern.isEmpty()) return false
        if (words.contains(cleanPattern)) return true
        val escaped = Regex.escape(cleanPattern)
        val regex = if (cleanPattern.contains(' ')) {
            Regex("(^|\\s)$escaped(\\s|$)")
        } else {
            Regex("(^|\\s)$escaped(lar|im|ing|ng|ngiz|ga|da|ni|dan|i|si)?(\\s|$)")
        }
        return regex.containsMatchIn(normalizedText)
    }

    private fun detectDoubleExtension(rawName: String): Boolean {
        val lower = rawName.lowercase()
        val disguisedExtensions = listOf(".jpg.apk", ".jpeg.apk", ".png.apk", ".mp4.apk", ".pdf.apk", ".docx.apk")
        return disguisedExtensions.any { lower.endsWith(it) }
    }

    private fun normalizeUzbekLatin(input: String): String {
        return input.lowercase()
            .replace("o‘", "o")
            .replace("o'", "o")
            .replace("oʻ", "o")
            .replace("o’", "o")
            .replace("g‘", "g")
            .replace("g'", "g")
            .replace("gʻ", "g")
            .replace("g’", "g")
            .replace("'", "")
            .replace("’", "")
            .replace("_", " ")
            .replace("-", " ")
            .replace(".", " ")
            .replace("(", " ")
            .replace(")", " ")
    }

    private fun getArchiveInfo(context: Context, filePath: String): PackageInfo? {
        return try {
            val pm = context.packageManager
            val flags = PackageManager.GET_PERMISSIONS or
                PackageManager.GET_ACTIVITIES or
                PackageManager.GET_SERVICES or
                PackageManager.GET_RECEIVERS or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    PackageManager.GET_SIGNING_CERTIFICATES
                } else {
                    @Suppress("DEPRECATION")
                    PackageManager.GET_SIGNATURES
                }

            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    filePath,
                    PackageManager.PackageInfoFlags.of(flags.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(filePath, flags)
            }
            info?.applicationInfo?.apply {
                sourceDir = filePath
                publicSourceDir = filePath
            }
            info
        } catch (_: Exception) {
            null
        }
    }

    private fun extractArchiveMetadata(
        context: Context,
        file: File,
        packageInfo: PackageInfo?
    ): ApkHeuristicMetadata {
        if (!file.exists() || file.length() == 0L) {
            return ApkHeuristicMetadata()
        }
        val sha256 = computeSha256(file)
        var hasManifest = false
        var dexCount = 0
        val nativeAbis = linkedSetOf<String>()
        val suspiciousAssets = mutableListOf<String>()

        runCatching {
            ZipFile(file).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val name = entries.nextElement().name
                    when {
                        name == "AndroidManifest.xml" -> hasManifest = true
                        name.startsWith("classes") && name.endsWith(".dex") -> dexCount++
                        name.startsWith("lib/") && name.endsWith(".so") -> {
                            val abi = name.removePrefix("lib/").substringBefore('/')
                            if (abi.isNotBlank()) nativeAbis.add(abi)
                        }
                        (name.startsWith("assets/") || name.startsWith("res/raw/")) &&
                            suspiciousPayloadExtensions.any { ext -> name.endsWith(ext, ignoreCase = true) } -> {
                            if (suspiciousAssets.size < 8) {
                                suspiciousAssets.add(name.substringAfterLast('/'))
                            }
                        }
                    }
                }
            }
        }

        val pm = context.packageManager
        val appLabel = runCatching {
            packageInfo?.applicationInfo?.loadLabel(pm)?.toString()
        }.getOrNull()

        val versionCode = packageInfo?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) it.longVersionCode
            else @Suppress("DEPRECATION") it.versionCode.toLong()
        }

        val minSdk = packageInfo?.applicationInfo?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) it.minSdkVersion else null
        }

        val sigCount = packageInfo?.let { info ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners?.size ?: 0
            } else {
                @Suppress("DEPRECATION")
                info.signatures?.size ?: 0
            }
        } ?: 0

        val services = packageInfo?.services
            ?.mapNotNull { it.name?.substringAfterLast('.') }
            ?.distinct()
            ?.take(12)
            .orEmpty()

        val receivers = packageInfo?.receivers
            ?.mapNotNull { it.name?.substringAfterLast('.') }
            ?.distinct()
            ?.take(12)
            .orEmpty()

        val activityCount = packageInfo?.activities?.size ?: 0
        val requestedPerms = packageInfo?.requestedPermissions?.toList().orEmpty()
        val hasHiddenLauncherIcon = packageInfo != null &&
            hasManifest &&
            activityCount == 0 &&
            (services.isNotEmpty() || receivers.isNotEmpty() || requestedPerms.isNotEmpty())

        return ApkHeuristicMetadata(
            appLabel = appLabel,
            versionName = packageInfo?.versionName,
            versionCode = versionCode,
            minSdk = minSdk,
            targetSdk = packageInfo?.applicationInfo?.targetSdkVersion,
            fileSizeBytes = file.length(),
            sha256 = sha256,
            hasValidApkStructure = hasManifest,
            dexFileCount = dexCount,
            nativeLibs = nativeAbis.toList(),
            suspiciousAssets = suspiciousAssets,
            declaredServices = services,
            declaredReceivers = receivers,
            allRequestedPermissions = requestedPerms,
            signatureCount = sigCount,
            signatureChecked = packageInfo != null,
            activityCount = activityCount,
            hasHiddenLauncherIcon = hasHiddenLauncherIcon
        )
    }

    private fun computeSha256(file: File): String? {
        return runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(8192)
                var read = input.read(buffer)
                while (read > 0) {
                    digest.update(buffer, 0, read)
                    read = input.read(buffer)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        }.getOrNull()
    }

    fun resolveDisplayName(context: Context, uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIdx >= 0 && cursor.moveToFirst()) {
                    val name = cursor.getString(nameIdx)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
        return uri.lastPathSegment
            ?.substringAfterLast(':')
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
            ?: "noma'lum.apk"
    }

    private val suspiciousPayloadExtensions = listOf(
        ".apk", ".dex", ".jar", ".so", ".bin", ".payload"
    )
}
