package com.example

import com.example.data.AiSensitivity
import com.example.data.KeywordRuleEntity
import com.example.data.QalqonRepository
import com.example.data.ThreatLevel
import com.example.data.WhitelistEntryEntity
import com.example.data.WhitelistType
import com.example.security.ApkThreatAnalyzer
import com.example.security.ContentSafetyClassifier
import com.example.security.InteractionButtonType
import com.example.security.NodeDescriptor
import com.example.security.SocialNodeInspector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QalqonSecurityUnitTest {

    @Test
    fun `detects deceptive Uzbek wedding invitation APK with SMS permissions as CRITICAL`() {
        val report = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "To'yga taklifnoma.apk",
            packageName = "com.malicious.invite",
            requestedPermissions = listOf(
                "android.permission.READ_SMS",
                "android.permission.BIND_ACCESSIBILITY_SERVICE"
            )
        )
        assertEquals(ThreatLevel.CRITICAL, report.threatLevel)
        assertNotNull(report.deceptiveNameMatched)
        assertEquals(2, report.suspiciousPermissions.size)
    }

    @Test
    fun `detects Russian disguised photo album APK as CRITICAL`() {
        val report = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "Фотоальбом_2026.apk",
            packageName = "com.fake.album",
            requestedPermissions = emptyList()
        )
        assertEquals(ThreatLevel.CRITICAL, report.threatLevel)
        assertNotNull(report.deceptiveNameMatched)
    }

    @Test
    fun `safe APK without deceptive name or risky permissions is SAFE`() {
        val report = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "Hisoblagich_v2.apk",
            packageName = "com.legit.calculator",
            requestedPermissions = listOf("android.permission.INTERNET")
        )
        assertEquals(ThreatLevel.SAFE, report.threatLevel)
        assertTrue(report.suspiciousPermissions.isEmpty())
    }

    @Test
    fun `normal apps with camera mic contacts boot or word substrings are SAFE without false positives`() {
        val normalMessenger = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "Rasmiy_Messenger_v3.apk",
            packageName = "uz.legit.messenger",
            requestedPermissions = listOf(
                "android.permission.INTERNET",
                "android.permission.CAMERA",
                "android.permission.RECORD_AUDIO",
                "android.permission.READ_CONTACTS",
                "android.permission.RECEIVE_BOOT_COMPLETED"
            )
        )
        assertEquals(ThreatLevel.SAFE, normalMessenger.threatLevel)

        val toyotaApp = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "Toyota_Service.apk",
            packageName = "com.toyota.service",
            requestedPermissions = listOf("android.permission.INTERNET", "android.permission.CAMERA")
        )
        assertEquals(ThreatLevel.SAFE, toyotaApp.threatLevel)
    }

    @Test
    fun `flags deceptive lure filenames hidden launcher icons and dangerous unsigned combos as malicious`() {
        val lureFiles = listOf(
            "To'y.apk",
            "Taklifnoma_2026.apk",
            "Albom.apk",
            "Video.apk",
            "Rasm.apk",
            "Karta.apk",
            "Mukofot.apk"
        )
        lureFiles.forEach { name ->
            val r = ApkThreatAnalyzer.analyzeNameAndPermissions(
                fileName = name,
                packageName = "com.unknown.lure",
                requestedPermissions = emptyList()
            )
            assertEquals("Expected CRITICAL for $name", ThreatLevel.CRITICAL, r.threatLevel)
        }

        val smsInternetCombo = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "ServiceUpdate.apk",
            packageName = "com.unknown.smsbot",
            requestedPermissions = listOf(
                "android.permission.RECEIVE_SMS",
                "android.permission.INTERNET"
            ),
            isUnsigned = true
        )
        assertEquals(ThreatLevel.CRITICAL, smsInternetCombo.threatLevel)

        val accessibilityOverlayCombo = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "HelperTool.apk",
            packageName = "com.unknown.overlay",
            requestedPermissions = listOf(
                "android.permission.BIND_ACCESSIBILITY_SERVICE",
                "android.permission.SYSTEM_ALERT_WINDOW"
            ),
            isUnsigned = true
        )
        assertEquals(ThreatLevel.CRITICAL, accessibilityOverlayCombo.threatLevel)

        val hiddenIconReport = ApkThreatAnalyzer.analyzeNameAndPermissions(
            fileName = "SystemPlug.apk",
            packageName = "com.unknown.hidden",
            requestedPermissions = listOf(
                "android.permission.INTERNET",
                "android.permission.RECORD_AUDIO"
            ),
            hasHiddenLauncherIcon = true
        )
        assertEquals(ThreatLevel.SUSPICIOUS, hiddenIconReport.threatLevel)
    }

    @Test
    fun `official trusted app packages are never reported as malicious`() {
        listOf(
            "org.telegram.messenger",
            "com.whatsapp",
            "com.instagram.android",
            "com.google.android.gms",
            "com.facebook.katana",
            "com.openai.chat",
            "com.microsoft.office",
            "com.android.vending",
            "com.xiaomi.mipicks",
            "com.miui.securitycenter"
        ).forEach { pkg ->
            assertTrue("Expected $pkg to be recognized as official", ApkThreatAnalyzer.isOfficialAppPackage(pkg))
            val report = ApkThreatAnalyzer.analyzeNameAndPermissions(
                fileName = "To'yga taklifnoma.apk",
                packageName = pkg,
                requestedPermissions = listOf(
                    "android.permission.READ_SMS",
                    "android.permission.BIND_ACCESSIBILITY_SERVICE"
                )
            )
            assertEquals("Expected $pkg to stay SAFE", ThreatLevel.SAFE, report.threatLevel)
        }
    }

    @Test
    fun `classifies extremist Uzbek text as harmful CRITICAL`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 1,
                keyword = "jihodga da'vat",
                language = "UZ",
                category = "EKSTREMIZM",
                isEnabled = true
            )
        )
        val result = ContentSafetyClassifier.classifyText(
            text = "Yashirin kanalimizga qo'shiling, jihodga da'vat boshlandi!",
            rules = rules,
            sensitivity = AiSensitivity.MEDIUM
        )
        assertTrue(result.isHarmful)
        assertEquals(ThreatLevel.CRITICAL, result.threatLevel)
        assertTrue(result.matchedKeywords.contains("jihodga da'vat"))
    }

    @Test
    fun `safe Uzbek greeting is classified as SAFE`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 1,
                keyword = "jihodga da'vat",
                language = "UZ",
                category = "EKSTREMIZM",
                isEnabled = true
            )
        )
        val result = ContentSafetyClassifier.classifyText(
            text = "Assalomu alaykum! Bugun ob-havo juda yaxshi.",
            rules = rules,
            sensitivity = AiSensitivity.HIGH
        )
        assertFalse(result.isHarmful)
        assertEquals(ThreatLevel.SAFE, result.threatLevel)
    }

    @Test
    fun `whitelist matches trusted APK file and package name`() {
        val entries = listOf(
            WhitelistEntryEntity(id = 1, value = "uz.gov.my", entryType = WhitelistType.PACKAGE_NAME.name),
            WhitelistEntryEntity(id = 2, value = "Korporativ_Hujjat.apk", entryType = WhitelistType.APK_FILE.name)
        )
        assertTrue(QalqonRepository.matchesApkWhitelist("MyGov.apk", "uz.gov.my", entries))
        assertTrue(QalqonRepository.matchesApkWhitelist("korporativ_hujjat.apk", null, entries))
        assertFalse(QalqonRepository.matchesApkWhitelist("To'yga taklifnoma.apk", "com.evil.app", entries))
    }

    @Test
    fun `whitelist matches trusted social channel handle`() {
        val entries = listOf(
            WhitelistEntryEntity(id = 1, value = "@rasmiy_yangiliklar", entryType = WhitelistType.SOCIAL_CHANNEL.name)
        )
        assertTrue(QalqonRepository.matchesContentWhitelist("Post from @rasmiy_yangiliklar channel", entries))
        assertFalse(QalqonRepository.matchesContentWhitelist("Post from @unknown_channel", entries))
    }

    @Test
    fun `identifies Instagram Like Comment Share nodes by viewId and contentDescription`() {
        val likeNode = NodeDescriptor(
            text = null,
            contentDescription = "Like",
            viewIdResourceName = "com.instagram.android:id/row_feed_button_like",
            className = "android.widget.ImageView",
            isClickable = true
        )
        val commentNode = NodeDescriptor(
            text = "Izoh qoldirish",
            contentDescription = null,
            viewIdResourceName = "com.instagram.android:id/row_feed_button_comment",
            className = "android.widget.Button",
            isClickable = true
        )
        val shareNode = NodeDescriptor(
            text = null,
            contentDescription = "Поделиться",
            viewIdResourceName = "com.google.android.youtube:id/share_button",
            className = "android.widget.ImageView",
            isClickable = true
        )

        assertEquals(InteractionButtonType.LIKE, SocialNodeInspector.classifyInteractionNode(likeNode))
        assertEquals(InteractionButtonType.COMMENT, SocialNodeInspector.classifyInteractionNode(commentNode))
        assertEquals(InteractionButtonType.SHARE, SocialNodeInspector.classifyInteractionNode(shareNode))
    }
}
