package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.DailyScanStatPoint
import com.example.data.OverviewRange
import com.example.data.SecurityOverviewSummary
import com.example.ui.components.CyberMetricCard
import com.example.ui.components.DailyScanTrendChart
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber

@Composable
fun SecurityOverviewScreen(
    summary: SecurityOverviewSummary,
    onSelectRange: (OverviewRange) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val activeDaysDesc = remember(summary.points) {
        summary.points.filter { it.totalEventsCount > 0 }.asReversed()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Analytics,
                                    contentDescription = "Xavfsizlik Ko'rinishi",
                                    tint = CyberCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = "Kunlik Skanerlash Statistikasi",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            StatusBadgePill(
                                text = "Himoya: ${summary.safetyRatePercent}%",
                                accentColor = if (summary.totalBlockedThreats == 0) ShieldEmerald else CyberCyan,
                                containerColor = if (summary.totalBlockedThreats == 0) ShieldEmeraldContainer else CyberCyanContainer
                            )
                        }

                        Text(
                            text = "Tanlangan davr bo'yicha har kuni tekshirilgan toza fayllar va bloklangan tahdidlar (zararli APK hamda ijtimoiy tarmoq tahdidlari) dinamikasi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OverviewRange.entries.forEach { range ->
                                FilterChip(
                                    selected = summary.range == range,
                                    onClick = { onSelectRange(range) },
                                    label = { Text(range.labelUz) },
                                    modifier = Modifier.testTag("overview_range_${range.days}"),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyanContainer,
                                        selectedLabelColor = CyberCyan,
                                        labelColor = CyberTextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CyberMetricCard(
                            label = "Toza fayllar",
                            value = summary.totalCleanFiles.toString(),
                            icon = Icons.Filled.GppGood,
                            accentColor = ShieldEmerald,
                            modifier = Modifier.weight(1f)
                        )
                        CyberMetricCard(
                            label = "Bloklangan tahdidlar",
                            value = summary.totalBlockedThreats.toString(),
                            icon = Icons.Filled.GppBad,
                            accentColor = ThreatCrimson,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CyberMetricCard(
                            label = "Zararli APK fayllar",
                            value = summary.totalBlockedMaliciousApks.toString(),
                            icon = Icons.Filled.FolderZip,
                            accentColor = WarningAmber,
                            modifier = Modifier.weight(1f)
                        )
                        CyberMetricCard(
                            label = "Ijtimoiy tahdidlar",
                            value = summary.totalBlockedSocialThreats.toString(),
                            icon = Icons.Filled.Public,
                            accentColor = CyberCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Trend chizig'i (${summary.range.labelUz})",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            summary.peakDay?.let { peak ->
                                StatusBadgePill(
                                    text = "Eng faol: ${peak.shortDateLabel} (${peak.totalEventsCount})",
                                    accentColor = CyberCyan,
                                    containerColor = CyberCyanContainer
                                )
                            }
                        }

                        DailyScanTrendChart(
                            summary = summary,
                            chartHeight = 240.dp
                        )
                    }
                }
            }

            item {
                Text(
                    text = "Kunlik tafsilotlar (${activeDaysDesc.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            }

            if (activeDaysDesc.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = CyberSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CyberOutline)
                    ) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.BugReport,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(30.dp)
                            )
                            Text(
                                text = "Tanlangan davrda skanerlash hodisalari yo'q",
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary
                            )
                            Text(
                                text = "Fayl Tekshiruvi yoki Ijtimoiy Tarmoqlar bo'limidan tekshiruv o'tkazing — natijalar kunlar kesimida shu yerda aks etadi.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(activeDaysDesc, key = { it.dayStartMillis }) { point ->
                    DailyStatBreakdownCard(point = point)
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun DailyStatBreakdownCard(point: DailyScanStatPoint) {
    val total = point.totalEventsCount.coerceAtLeast(1)
    val cleanRatio = point.cleanFilesCount.toFloat() / total.toFloat()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("overview_day_card_${point.shortDateLabel}"),
        color = CyberSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            1.dp,
            if (point.totalBlockedThreatsCount > 0) ThreatCrimson.copy(alpha = 0.45f) else CyberOutline
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CalendarToday,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = point.fullDateLabel,
                        style = MaterialTheme.typography.titleSmall,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "Jami: ${point.totalEventsCount} ta",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyberTextSecondary
                )
            }

            LinearProgressIndicator(
                progress = { cleanRatio },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = ShieldEmerald,
                trackColor = if (point.totalBlockedThreatsCount > 0) ThreatCrimson else CyberSurfaceElevated
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusBadgePill(
                    text = "Toza fayllar: ${point.cleanFilesCount}",
                    accentColor = ShieldEmerald,
                    containerColor = ShieldEmeraldContainer
                )
                StatusBadgePill(
                    text = "Bloklangan tahdidlar: ${point.totalBlockedThreatsCount}",
                    accentColor = if (point.totalBlockedThreatsCount > 0) ThreatCrimson else CyberTextSecondary,
                    containerColor = if (point.totalBlockedThreatsCount > 0) ThreatCrimsonContainer else CyberSurfaceElevated
                )
            }
        }
    }
}
