package com.example.security

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.data.LogSourceType
import com.example.data.QalqonRepository
import com.example.data.SocialPlatform
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("AccessibilityPolicy")
class ContentGuardAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var repository: QalqonRepository
    private val geminiAnalyzer by lazy { GeminiThreatAnalyzer(applicationContext) }

    private var activeHarmfulReason: String? = null
    private var activeHarmfulPlatform: SocialPlatform? = null
    private var detectedInteractionButtons: List<DetectedInteractionNode> = emptyList()
    private var lastAnalyzedHash: Int = 0
    private var lastOverlayShownAt: Long = 0L
    private var analyzeJob: Job? = null
    private var overlayView: View? = null
    private val buttonBlockerOverlays = mutableListOf<View>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        repository = QalqonRepository(applicationContext)
        ContentSafetyClassifier.ensureInitialized(applicationContext)
        ApkThreatAnalyzer.ensureInitialized(applicationContext)
        Log.d(TAG, "ContentGuardAccessibilityService connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val safeEvent = event ?: return
        val pkgName = safeEvent.packageName?.toString() ?: return
        val platform = resolvePlatform(pkgName) ?: run {
            clearShieldsIfOutsideSocialApps()
            return
        }

        if (safeEvent.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            handleClickEvent(safeEvent, platform)
            return
        }

        val root = rootInActiveWindow ?: return
        val scanResult = SocialNodeInspector.scanAccessibilityTree(root)
        detectedInteractionButtons = scanResult.interactionButtons

        val extractedText = scanResult.visibleText
        if (extractedText.length < 15) return

        val hash = extractedText.hashCode()
        if (hash == lastAnalyzedHash) {
            if (activeHarmfulReason != null) {
                attachButtonBlockers(detectedInteractionButtons, platform, activeHarmfulReason!!)
            }
            return
        }
        lastAnalyzedHash = hash

        analyzeJob?.cancel()
        analyzeJob = serviceScope.launch {
            val settings = withContext(Dispatchers.IO) { repository.settings.first() }
            if (!settings.isMasterShieldEnabled || !settings.isSocialGuardEnabled) {
                clearActiveHarmState()
                return@launch
            }

            val accounts = withContext(Dispatchers.IO) { repository.protectedAccounts.first() }
            val accountActive = accounts.firstOrNull { it.platform == platform.name }?.protectionActive ?: true
            if (!accountActive) {
                clearActiveHarmState()
                return@launch
            }

            val whitelisted = withContext(Dispatchers.IO) {
                repository.isContentWhitelisted(extractedText)
            }
            if (whitelisted) {
                clearActiveHarmState()
                return@launch
            }

            val rules = withContext(Dispatchers.IO) { repository.getEnabledKeywords() }
            val localResult = withContext(Dispatchers.Default) {
                ContentSafetyClassifier.classifyText(extractedText, rules, settings.aiSensitivity)
            }

            if (localResult.isHarmful) {
                triggerContentBlock(
                    platform = platform,
                    snippet = extractedText.take(180),
                    reason = localResult.summaryUz,
                    indicators = localResult.matchedKeywords.joinToString(" • "),
                    aiExplanation = "Lokal kalit so'z filtri xavfli kontentni aniqladi."
                )
            } else if (settings.isGeminiAnalysisEnabled &&
                localResult.threatLevel == ThreatLevel.SUSPICIOUS &&
                extractedText.length >= 25
            ) {
                val aiResult = withContext(Dispatchers.IO) {
                    geminiAnalyzer.analyzeSocialContent(
                        text = extractedText.take(600),
                        platformName = platform.displayName,
                        sensitivity = settings.aiSensitivity
                    )
                }
                aiResult.getOrNull()?.let { result ->
                    if (result.isHarmful) {
                        triggerContentBlock(
                            platform = platform,
                            snippet = extractedText.take(180),
                            reason = "${result.category}: ${result.explanationUz}",
                            indicators = "Gemini AI Tahlili",
                            aiExplanation = result.recommendedActionUz
                        )
                    } else {
                        clearActiveHarmState()
                    }
                }
            } else {
                clearActiveHarmState()
            }
        }
    }

    private fun handleClickEvent(event: AccessibilityEvent, platform: SocialPlatform) {
        val reason = activeHarmfulReason ?: return

        val identifiedFromNode = SocialNodeInspector.identifyButtonFromNode(event.source)
        val clickedText = buildString {
            event.text.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it) }
        }
        val identifiedFromEvent = SocialNodeInspector.classifyInteractionNode(
            NodeDescriptor(
                text = clickedText,
                contentDescription = event.contentDescription?.toString(),
                viewIdResourceName = null,
                className = event.className?.toString(),
                isClickable = true
            )
        )

        val blockedType = identifiedFromNode ?: identifiedFromEvent
        if (blockedType != null) {
            Log.w(TAG, "Blocked ${blockedType.name} interaction on ${platform.displayName}")
            performGlobalAction(GLOBAL_ACTION_BACK)
            showProtectionOverlay(
                platform = activeHarmfulPlatform ?: platform,
                reason = "${blockedType.labelUz} tugmasi bloklandi. $reason"
            )
        }
    }

    private suspend fun triggerContentBlock(
        platform: SocialPlatform,
        snippet: String,
        reason: String,
        indicators: String,
        aiExplanation: String
    ) {
        activeHarmfulReason = reason
        activeHarmfulPlatform = platform

        val blockedButtonsSummary = detectedInteractionButtons
            .map { it.type.labelUz }
            .distinct()
            .joinToString(", ")

        attachButtonBlockers(detectedInteractionButtons, platform, reason)

        withContext(Dispatchers.IO) {
            repository.incrementAccountBlocked(platform)
            repository.logThreat(
                ThreatLogEntity(
                    sourceType = LogSourceType.SOCIAL_GUARD.name,
                    title = "Bu kontent xavfsiz emas va bloklandi",
                    targetName = "${platform.displayName}: $snippet",
                    packageNameOrPath = platform.packageNames.first(),
                    threatLevel = ThreatLevel.CRITICAL.name,
                    reasonUz = reason,
                    detectedIndicators = listOfNotNull(
                        indicators.takeIf { it.isNotBlank() },
                        blockedButtonsSummary.takeIf { it.isNotBlank() }?.let { "Bloklangan tugmalar: $it" }
                    ).joinToString(" | "),
                    aiExplanation = aiExplanation,
                    actionTaken = "BLOKLANDI"
                )
            )
            SecurityNotificationService.notifySocialThreat(
                context = applicationContext,
                platformName = platform.displayName,
                summaryUz = reason,
                threatLevel = ThreatLevel.CRITICAL
            )
        }

        val now = System.currentTimeMillis()
        if (now - lastOverlayShownAt > 4000L) {
            lastOverlayShownAt = now
            showProtectionOverlay(platform, reason)
        }
    }

    private fun attachButtonBlockers(
        buttons: List<DetectedInteractionNode>,
        platform: SocialPlatform,
        reason: String
    ) {
        clearButtonBlockers()
        val wm = getSystemService(WINDOW_SERVICE) as? WindowManager ?: return

        buttons.filter { !it.bounds.isEmpty && it.bounds.width() > 16 && it.bounds.height() > 16 }
            .take(8)
            .forEach { btn ->
                val shieldChip = View(this).apply {
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#88FF2A55"))
                        cornerRadius = 16f
                        setStroke(2, Color.parseColor("#FFFF2A55"))
                    }
                    contentDescription = "${btn.type.labelUz} bloklandi"
                    setOnClickListener {
                        showProtectionOverlay(
                            platform = platform,
                            reason = "${btn.type.labelUz} tugmasi xavfsizlik uchun yopildi. $reason"
                        )
                    }
                }

                val params = WindowManager.LayoutParams(
                    btn.bounds.width(),
                    btn.bounds.height(),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = btn.bounds.left
                    y = btn.bounds.top
                }

                try {
                    wm.addView(shieldChip, params)
                    buttonBlockerOverlays.add(shieldChip)
                } catch (_: Exception) {
                }
            }
    }

    private fun showProtectionOverlay(platform: SocialPlatform, reason: String) {
        if (overlayView != null) return
        val wm = getSystemService(WINDOW_SERVICE) as? WindowManager ?: return

        val detectedNames = detectedInteractionButtons
            .map { it.type.labelUz }
            .distinct()
            .joinToString(", ")

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 96, 64, 96)
            setBackgroundColor(Color.parseColor("#EE1A050B"))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 56, 56, 56)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FF140910"))
                cornerRadius = 40f
                setStroke(4, Color.parseColor("#FFFF2A55"))
            }
        }

        val badge = TextView(this).apply {
            text = "QALQON AI • ${platform.displayName.uppercase()} HIMOYASI"
            setTextColor(Color.parseColor("#FFFF2A55"))
            textSize = 12f
        }

        val title = TextView(this).apply {
            text = "Bu kontent xavfsiz emas va bloklandi"
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, 20, 0, 16)
        }

        val blockedButtonsText = if (detectedNames.isNotBlank()) {
            "\nBloklangan harakatlar: $detectedNames"
        } else {
            "\nLike, Ulashish, Saqlash va Izoh yozish cheklandi."
        }

        val body = TextView(this).apply {
            text = "$reason$blockedButtonsText"
            setTextColor(Color.parseColor("#FFE2E8F0"))
            textSize = 15f
            setPadding(0, 0, 0, 36)
        }

        val safeBackBtn = Button(this).apply {
            text = "Xavfsiz joyga qaytish"
            setBackgroundColor(Color.parseColor("#FFFF2A55"))
            setTextColor(Color.WHITE)
            setOnClickListener {
                removeOverlay()
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }

        val dismissBtn = Button(this).apply {
            text = "Tushundim, yopish"
            setBackgroundColor(Color.parseColor("#FF1E293B"))
            setTextColor(Color.parseColor("#FF00E5FF"))
            setOnClickListener {
                removeOverlay()
            }
        }

        card.addView(badge)
        card.addView(title)
        card.addView(body)
        card.addView(safeBackBtn)
        card.addView(dismissBtn)
        container.addView(card)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(container, params)
            overlayView = container
        } catch (e: Exception) {
            Log.e(TAG, "Unable to attach accessibility overlay", e)
        }
    }

    private fun clearActiveHarmState() {
        activeHarmfulReason = null
        activeHarmfulPlatform = null
        clearButtonBlockers()
    }

    private fun clearShieldsIfOutsideSocialApps() {
        clearActiveHarmState()
        removeOverlay()
    }

    private fun clearButtonBlockers() {
        if (buttonBlockerOverlays.isEmpty()) return
        val wm = getSystemService(WINDOW_SERVICE) as? WindowManager
        buttonBlockerOverlays.forEach { view ->
            runCatching { wm?.removeViewImmediate(view) }
        }
        buttonBlockerOverlays.clear()
    }

    private fun removeOverlay() {
        val view = overlayView ?: return
        val wm = getSystemService(WINDOW_SERVICE) as? WindowManager
        try {
            wm?.removeViewImmediate(view)
        } catch (_: Exception) {
        } finally {
            overlayView = null
        }
    }

    private fun resolvePlatform(packageName: String): SocialPlatform? {
        return SocialPlatform.entries.firstOrNull { platform ->
            platform != SocialPlatform.TELEGRAM && platform.packageNames.contains(packageName)
        }
    }

    override fun onInterrupt() {
        clearShieldsIfOutsideSocialApps()
    }

    override fun onDestroy() {
        clearShieldsIfOutsideSocialApps()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ContentGuardA11y"
    }
}
