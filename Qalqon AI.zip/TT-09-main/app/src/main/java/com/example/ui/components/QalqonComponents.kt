package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ProtectedAccountEntity
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatusBadgePill(
    text: String,
    accentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = containerColor,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(accentColor, CircleShape)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
fun PulsingShieldEmblem(
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "shield_radar")
    val ringScale by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring_scale"
    )
    val mainColor = if (isActive) CyberCyan else ThreatCrimson

    Box(
        modifier = modifier.size(72.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .scale(if (isActive) ringScale else 1f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(mainColor.copy(alpha = 0.28f), Color.Transparent)
                    ),
                    CircleShape
                )
        )
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(CyberNavyBg.copy(alpha = 0.85f), CircleShape)
                .border(1.5.dp, mainColor.copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isActive) Icons.Filled.VerifiedUser else Icons.Filled.GppBad,
                contentDescription = if (isActive) "Qalqon faol" else "Qalqon o'chirilgan",
                tint = mainColor,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun CyberMetricCard(
    label: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = CyberSurfaceElevated,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.28f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineSmall,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ProtectedAccountCard(
    account: ProtectedAccountEntity,
    onToggleProtection: () -> Unit,
    onToggleSafeSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accentColor = if (account.protectionActive) CyberCyan else WarningAmber
    val containerColor = if (account.protectionActive) CyberCyanContainer else WarningAmberContainer

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (account.protectionActive) CyberOutline else WarningAmber.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = account.platform,
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        StatusBadgePill(
                            text = if (account.protectionActive) "Bot Himoyasi Faol" else "Nofaol",
                            accentColor = if (account.protectionActive) ShieldEmerald else WarningAmber,
                            containerColor = if (account.protectionActive) ShieldEmeraldContainer else WarningAmberContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = account.handleOrLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                }

                Switch(
                    checked = account.protectionActive,
                    onCheckedChange = { onToggleProtection() },
                    modifier = Modifier.testTag("account_switch_${account.platform.lowercase()}"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberNavyBg,
                        checkedTrackColor = CyberCyan,
                        uncheckedThumbColor = CyberTextSecondary,
                        uncheckedTrackColor = CyberSurfaceElevated
                    )
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = account.sessionMonitorMethod,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "Bloklangan: ${account.blockedCount}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (account.blockedCount > 0) ThreatCrimson else CyberCyan
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LinearProgressIndicator(
                    progress = { account.securityScore / 100f },
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(999.dp)),
                    color = accentColor,
                    trackColor = CyberSurfaceElevated
                )
                Text(
                    text = "${account.securityScore}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = accentColor
                )
            }

            Surface(
                onClick = onToggleSafeSession,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("account_oauth_btn_${account.platform.lowercase()}"),
                color = containerColor.copy(alpha = 0.55f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Security,
                            contentDescription = "Sessiya holati",
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (account.oauthConnected) {
                                "Xavfsiz OAuth / Sessiya ulangan (Parolsiz)"
                            } else {
                                "Xavfsiz sessiya nazoratini ulash"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextPrimary
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = if (account.oauthConnected) ShieldEmerald else CyberTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ThreatLogCard(
    log: ThreatLogEntity,
    modifier: Modifier = Modifier,
    onAddToWhitelist: (() -> Unit)? = null,
    onDeleteLog: (() -> Unit)? = null
) {
    val level = runCatching { ThreatLevel.valueOf(log.threatLevel) }.getOrDefault(ThreatLevel.SUSPICIOUS)
    val (accent, container, icon) = when (level) {
        ThreatLevel.SAFE -> Triple(ShieldEmerald, ShieldEmeraldContainer, Icons.Filled.GppGood)
        ThreatLevel.SUSPICIOUS -> Triple(WarningAmber, WarningAmberContainer, Icons.Filled.Warning)
        ThreatLevel.CRITICAL -> Triple(ThreatCrimson, ThreatCrimsonContainer, Icons.Filled.GppBad)
    }

    val formattedTime = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(log.timestamp))

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = CyberSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = level.labelUz,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = log.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                StatusBadgePill(
                    text = log.actionTaken,
                    accentColor = accent,
                    containerColor = container
                )
            }

            Text(
                text = log.targetName,
                style = MaterialTheme.typography.labelMedium,
                color = CyberCyan,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = log.reasonUz,
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary
            )

            if (log.detectedIndicators.isNotBlank()) {
                Text(
                    text = "Belgilar: ${log.detectedIndicators}",
                    style = MaterialTheme.typography.labelSmall,
                    color = accent
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = log.sourceType,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted
                )
                Text(
                    text = formattedTime,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted
                )
            }

            if ((onAddToWhitelist != null && log.actionTaken != "OQ RO'YXAT") || onDeleteLog != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onAddToWhitelist != null && log.actionTaken != "OQ RO'YXAT") {
                        Surface(
                            onClick = onAddToWhitelist,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("log_whitelist_btn_${log.id}"),
                            color = ShieldEmeraldContainer.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, ShieldEmerald.copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.VerifiedUser,
                                    contentDescription = "Oq ro'yxatga qo'shish",
                                    tint = ShieldEmerald,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Oq ro'yxatga qo'shish",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ShieldEmerald
                                )
                            }
                        }
                    }

                    if (onDeleteLog != null) {
                        Surface(
                            onClick = onDeleteLog,
                            modifier = Modifier.testTag("log_delete_btn_${log.id}"),
                            color = ThreatCrimsonContainer.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Yozuvni o'chirish",
                                    tint = ThreatCrimson,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "O'chirish",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ThreatCrimson
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
