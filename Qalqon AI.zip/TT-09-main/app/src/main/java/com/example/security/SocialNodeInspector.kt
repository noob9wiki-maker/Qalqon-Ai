package com.example.security

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

enum class InteractionButtonType(val labelUz: String) {
    LIKE("Like (Yoqdi)"),
    COMMENT("Izoh (Comment)"),
    SHARE("Ulashish (Share)"),
    SAVE("Saqlash (Save)")
}

data class NodeDescriptor(
    val text: String?,
    val contentDescription: String?,
    val viewIdResourceName: String?,
    val className: String?,
    val isClickable: Boolean,
    val bounds: Rect = Rect()
)

data class DetectedInteractionNode(
    val type: InteractionButtonType,
    val label: String,
    val viewId: String?,
    val bounds: Rect
)

data class ScreenNodeScanResult(
    val visibleText: String,
    val interactionButtons: List<DetectedInteractionNode>
)

object SocialNodeInspector {

    private val likeViewIds = listOf(
        "row_feed_button_like",
        "like_button",
        "like_icon",
        "reel_like_button",
        "ufi_like",
        "feedback_like",
        "likes_button"
    )

    private val commentViewIds = listOf(
        "row_feed_button_comment",
        "comment_button",
        "comments_button",
        "reel_comment_button",
        "ufi_comment",
        "feedback_comment",
        "comment_composer",
        "add_comment"
    )

    private val shareViewIds = listOf(
        "row_feed_button_share",
        "share_button",
        "reel_share_button",
        "ufi_share",
        "feedback_share",
        "send_button",
        "direct_share"
    )

    private val saveViewIds = listOf(
        "row_feed_button_save",
        "save_button",
        "bookmark_button"
    )

    private val likeKeywords = listOf("like", "yoqdi", "layk", "нравится", "лайк", "me gusta")
    private val commentKeywords = listOf("comment", "izoh", "sharh", "комментар", "ответить")
    private val shareKeywords = listOf("share", "ulashish", "yuborish", "поделиться", "отправить", "repost")
    private val saveKeywords = listOf("save", "saqlash", "сохранить", "bookmark")

    fun scanAccessibilityTree(root: AccessibilityNodeInfo?): ScreenNodeScanResult {
        if (root == null) return ScreenNodeScanResult("", emptyList())

        val textBuilder = StringBuilder()
        val buttons = mutableListOf<DetectedInteractionNode>()
        val seenBounds = mutableSetOf<String>()

        traverseNode(root, depth = 0, textBuilder = textBuilder, buttons = buttons, seenBounds = seenBounds)

        return ScreenNodeScanResult(
            visibleText = textBuilder.toString().trim(),
            interactionButtons = buttons
        )
    }

    fun identifyButtonFromNode(node: AccessibilityNodeInfo?): InteractionButtonType? {
        var current = node
        var hops = 0
        while (current != null && hops < 4) {
            val descriptor = toDescriptor(current)
            val match = classifyInteractionNode(descriptor)
            if (match != null) return match
            current = current.parent
            hops++
        }
        return null
    }

    fun classifyInteractionNode(descriptor: NodeDescriptor): InteractionButtonType? {
        val viewId = descriptor.viewIdResourceName?.lowercase().orEmpty()
        if (viewId.isNotEmpty()) {
            when {
                likeViewIds.any { viewId.contains(it) } -> return InteractionButtonType.LIKE
                commentViewIds.any { viewId.contains(it) } -> return InteractionButtonType.COMMENT
                shareViewIds.any { viewId.contains(it) } -> return InteractionButtonType.SHARE
                saveViewIds.any { viewId.contains(it) } -> return InteractionButtonType.SAVE
            }
        }

        val combinedText = buildString {
            descriptor.contentDescription?.let { append(it).append(' ') }
            descriptor.text?.let { append(it) }
        }.lowercase().trim()

        if (combinedText.isEmpty() || combinedText.length > 60) return null

        // Avoid false positives on full post captions that happen to mention a word
        val isButtonLike = descriptor.isClickable ||
            descriptor.className?.contains("Button", ignoreCase = true) == true ||
            descriptor.className?.contains("ImageView", ignoreCase = true) == true ||
            combinedText.length <= 28

        if (!isButtonLike) return null

        return when {
            likeKeywords.any { combinedText.contains(it) } -> InteractionButtonType.LIKE
            commentKeywords.any { combinedText.contains(it) } -> InteractionButtonType.COMMENT
            shareKeywords.any { combinedText.contains(it) } -> InteractionButtonType.SHARE
            saveKeywords.any { combinedText.contains(it) } -> InteractionButtonType.SAVE
            else -> null
        }
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo?,
        depth: Int,
        textBuilder: StringBuilder,
        buttons: MutableList<DetectedInteractionNode>,
        seenBounds: MutableSet<String>
    ) {
        if (node == null || depth > 16 || textBuilder.length > 1600) return

        val descriptor = toDescriptor(node)
        descriptor.text?.let {
            if (it.isNotBlank()) textBuilder.append(it).append(' ')
        }
        descriptor.contentDescription?.let {
            if (it.isNotBlank()) textBuilder.append(it).append(' ')
        }

        classifyInteractionNode(descriptor)?.let { type ->
            val key = "${type.name}:${descriptor.bounds.toShortString()}"
            if (seenBounds.add(key)) {
                buttons.add(
                    DetectedInteractionNode(
                        type = type,
                        label = descriptor.contentDescription ?: descriptor.text ?: type.labelUz,
                        viewId = descriptor.viewIdResourceName,
                        bounds = descriptor.bounds
                    )
                )
            }
        }

        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), depth + 1, textBuilder, buttons, seenBounds)
        }
    }

    private fun toDescriptor(node: AccessibilityNodeInfo): NodeDescriptor {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return NodeDescriptor(
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            viewIdResourceName = node.viewIdResourceName,
            className = node.className?.toString(),
            isClickable = node.isClickable,
            bounds = rect
        )
    }
}
