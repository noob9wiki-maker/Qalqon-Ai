package com.example.ui.components

import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.security.BiometricAuthManager
import com.example.security.BiometricAvailabilityStatus
import com.example.security.SensitiveArea
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

@Composable
fun BiometricLockGate(
    area: SensitiveArea,
    availability: BiometricAvailabilityStatus,
    onUnlockSuccess: () -> Unit,
    onRefreshAvailability: () -> Unit,
    onNavigateHome: () -> Unit
) {
    BackHandler { onNavigateHome() }

    val context = LocalContext.current
    val activity = remember(context) { context.findFragmentActivity() }
    var errorMessage by remember(area) { mutableStateOf<String?>(null) }
    var autoPrompted by remember(area) { mutableStateOf(false) }

    val launchPrompt: () -> Unit = {
        val hostActivity = activity
        if (hostActivity == null) {
            errorMessage = "Biometrik oynani ko'rsatish uchun faol oyna topilmadi."
        } else {
            errorMessage = null
            BiometricAuthManager.authenticate(
                activity = hostActivity,
                area = area,
                onSuccess = {
                    errorMessage = null
                    onUnlockSuccess()
                },
                onFailureOrCancel = { message ->
                    errorMessage = message
                    onRefreshAvailability()
                }
            )
        }
    }

    LaunchedEffect(area, availability) {
        if (!autoPrompted && availability == BiometricAvailabilityStatus.READY && activity != null) {
            autoPrompted = true
            launchPrompt()
        }
    }

    val statusColor = when (availability) {
        BiometricAvailabilityStatus.READY -> ShieldEmerald
        BiometricAvailabilityStatus.NONE_ENROLLED -> WarningAmber
        BiometricAvailabilityStatus.NO_HARDWARE,
        BiometricAvailabilityStatus.UNAVAILABLE -> ThreatCrimson
    }
    val statusContainer = when (availability) {
        BiometricAvailabilityStatus.READY -> ShieldEmeraldContainer
        BiometricAvailabilityStatus.NONE_ENROLLED -> WarningAmberContainer
        BiometricAvailabilityStatus.NO_HARDWARE,
        BiometricAvailabilityStatus.UNAVAILABLE -> ThreatCrimsonContainer
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .testTag("biometric_lock_gate_${area.name.lowercase()}"),
            color = CyberSurface,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(CyberCyan.copy(alpha = 0.25f), CyberNavyBg)
                            ),
                            CircleShape
                        )
                        .border(1.5.dp, CyberCyan.copy(alpha = 0.65f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Fingerprint,
                        contentDescription = "Biometrik himoya",
                        tint = CyberCyan,
                        modifier = Modifier.size(44.dp)
                    )
                }

                StatusBadgePill(
                    text = availability.badgeUz,
                    accentColor = statusColor,
                    containerColor = statusContainer
                )

                Text(
                    text = "${area.titleUz} qulflangan",
                    style = MaterialTheme.typography.headlineSmall,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = area.subtitleUz,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextSecondary,
                    textAlign = TextAlign.Center
                )

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Biometrik holat",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberCyan
                        )
                        Text(
                            text = availability.detailUz,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }

                if (errorMessage != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("biometric_error_banner"),
                        color = ThreatCrimsonContainer.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextPrimary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                if (availability == BiometricAvailabilityStatus.READY) {
                    Button(
                        onClick = launchPrompt,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("biometric_unlock_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = CyberNavyBg
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "Yuz / Barmoq izi bilan ochish",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                } else {
                    Button(
                        onClick = {
                            runCatching {
                                context.startActivity(BiometricAuthManager.createEnrollIntent(context))
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("biometric_enroll_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = CyberNavyBg
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Security,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "Biometrik himoyani sozlash",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            onRefreshAvailability()
                            if (BiometricAuthManager.checkAvailability(context) == BiometricAvailabilityStatus.READY) {
                                launchPrompt()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("biometric_recheck_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("Holatni qayta tekshirish", color = CyberCyan)
                    }
                }

                OutlinedButton(
                    onClick = onNavigateHome,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("biometric_back_home_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Text(
                        text = "Bosh sahifaga qaytish",
                        color = CyberTextSecondary,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

private tailrec fun Context.findFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findFragmentActivity()
    else -> null
}
