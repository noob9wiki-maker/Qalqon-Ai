package com.example.security

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.ApkScanReport
import com.example.data.NotificationPreferences
import com.example.data.QalqonPreferencesRepository
import com.example.data.ThreatLevel
import com.example.data.ThreatNotificationCategory
import com.example.ui.ThreatAlertActivity
import java.util.Calendar

enum class NotificationThreatSource {
    MALICIOUS_FILE,
    NEWLY_INSTALLED_APP,
    SOCIAL_CONTENT
}

/**
 * System Notification Service that pushes local high-priority security alerts
 * immediately whenever a file, newly installed app, or social post is flagged,
 * respecting the user's customized NotificationPreferences.
 */
object SecurityNotificationService {

    const val CHANNEL_THREAT_SILENT = "qalqon_threat_silent_channel"
    private const val FILE_ALERT_BASE_ID = 5100
    private const val APP_ALERT_BASE_ID = 6100
    private const val SOCIAL_ALERT_BASE_ID = 7100

    fun ensureThreatNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            if (nm.getNotificationChannel(DownloadGuardService.CHANNEL_THREAT) == null) {
                val threatChannel = NotificationChannel(
                    DownloadGuardService.CHANNEL_THREAT,
                    context.getString(R.string.notification_channel_threat_name),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = context.getString(R.string.notification_channel_threat_desc)
                    enableVibration(true)
                    enableLights(true)
                }
                nm.createNotificationChannel(threatChannel)
            }
            if (nm.getNotificationChannel(CHANNEL_THREAT_SILENT) == null) {
                val silentChannel = NotificationChannel(
                    CHANNEL_THREAT_SILENT,
                    context.getString(R.string.notification_channel_threat_silent_name),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.notification_channel_threat_silent_desc)
                    setSound(null, null)
                    enableVibration(false)
                }
                nm.createNotificationChannel(silentChannel)
            }
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun classifyApkThreatCategories(report: ApkScanReport): Set<ThreatNotificationCategory> {
        if (report.threatLevel == ThreatLevel.SAFE) return emptySet()

        val categories = linkedSetOf<ThreatNotificationCategory>()
        val combinedText = buildString {
            append(report.fileName).append(' ')
            append(report.reasonUz).append(' ')
            append(report.aiHeuristicResult?.category.orEmpty()).append(' ')
            append(report.deceptiveNameMatched.orEmpty())
        }.lowercase()

        val hasDoubleExt = listOf(".jpg.apk", ".jpeg.apk", ".png.apk", ".mp4.apk", ".pdf.apk", ".docx.apk")
            .any { report.fileName.lowercase().endsWith(it) }

        val isPhishing = report.deceptiveNameMatched != null ||
            hasDoubleExt ||
            listOf("phishing", "firibgar", "taklifnoma", "aldamchi", "niqob", "karta", "muhandislik", "soxta")
                .any { combinedText.contains(it) }
        if (isPhishing) {
            categories.add(ThreatNotificationCategory.PHISHING)
        }

        val permsJoined = report.suspiciousPermissions.joinToString(" ").uppercase()
        val hasCoreMalwarePerms = listOf(
            "READ_SMS",
            "RECEIVE_SMS",
            "SEND_SMS",
            "BIND_ACCESSIBILITY_SERVICE",
            "REQUEST_INSTALL_PACKAGES",
            "READ_CALL_LOG"
        ).any { permsJoined.contains(it) }

        val isMalware = hasCoreMalwarePerms ||
            report.metadata.suspiciousAssets.isNotEmpty() ||
            listOf("malware", "troyan", "trojan", "spyware", "dropper", "zararli")
                .any { combinedText.contains(it) } ||
            (report.threatLevel == ThreatLevel.CRITICAL && !isPhishing)
        if (isMalware) {
            categories.add(ThreatNotificationCategory.MALWARE)
        }

        val isSuspiciousBehavior = report.threatLevel == ThreatLevel.SUSPICIOUS ||
            (report.metadata.targetSdk != null && report.metadata.targetSdk in 1..28) ||
            (report.metadata.signatureChecked && report.metadata.signatureCount == 0) ||
            (report.suspiciousPermissions.isNotEmpty() && !hasCoreMalwarePerms)
        if (isSuspiciousBehavior || categories.isEmpty()) {
            categories.add(ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR)
        }

        return categories
    }

    fun classifySocialThreatCategories(
        summaryUz: String,
        threatLevel: ThreatLevel
    ): Set<ThreatNotificationCategory> {
        if (threatLevel == ThreatLevel.SAFE) return emptySet()
        val categories = linkedSetOf(ThreatNotificationCategory.SOCIAL_THREATS)
        val lower = summaryUz.lowercase()
        if (listOf("phishing", "firibgar", "karta", "parol", "sms kod", "cvv", "pul").any { lower.contains(it) }) {
            categories.add(ThreatNotificationCategory.PHISHING)
        }
        if (threatLevel == ThreatLevel.SUSPICIOUS) {
            categories.add(ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR)
        }
        return categories
    }

    fun shouldDeliverNotification(
        prefs: NotificationPreferences,
        categories: Set<ThreatNotificationCategory>,
        threatLevel: ThreatLevel,
        currentHourOfDay: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    ): Boolean {
        if (threatLevel == ThreatLevel.SAFE) return false
        if (!prefs.generalAlertsEnabled) return false
        if (categories.none { prefs.isCategoryEnabled(it) }) return false

        if (prefs.quietHoursEnabled) {
            val inQuietWindow = currentHourOfDay >= 23 || currentHourOfDay < 7
            if (inQuietWindow && !(threatLevel == ThreatLevel.CRITICAL && prefs.criticalBypassQuietHours)) {
                return false
            }
        }
        return true
    }

    fun notifyMaliciousFile(
        context: Context,
        report: ApkScanReport,
        preferencesOverride: NotificationPreferences? = null,
        currentHourOverride: Int? = null
    ): Boolean {
        return pushThreatNotification(
            context = context,
            report = report,
            source = NotificationThreatSource.MALICIOUS_FILE,
            preferencesOverride = preferencesOverride,
            currentHourOverride = currentHourOverride
        )
    }

    fun notifyMaliciousInstalledApp(
        context: Context,
        report: ApkScanReport,
        preferencesOverride: NotificationPreferences? = null,
        currentHourOverride: Int? = null
    ): Boolean {
        return pushThreatNotification(
            context = context,
            report = report,
            source = NotificationThreatSource.NEWLY_INSTALLED_APP,
            preferencesOverride = preferencesOverride,
            currentHourOverride = currentHourOverride
        )
    }

    fun notifySocialThreat(
        context: Context,
        platformName: String,
        summaryUz: String,
        threatLevel: ThreatLevel,
        preferencesOverride: NotificationPreferences? = null,
        currentHourOverride: Int? = null
    ): Boolean {
        if (threatLevel == ThreatLevel.SAFE) return false

        val appContext = context.applicationContext
        ensureThreatNotificationChannel(appContext)
        if (!hasNotificationPermission(appContext)) return false

        val prefs = preferencesOverride ?: QalqonPreferencesRepository(appContext).getNotificationPreferencesBlocking()
        val categories = classifySocialThreatCategories(summaryUz, threatLevel)
        val hour = currentHourOverride ?: Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (!shouldDeliverNotification(prefs, categories, threatLevel, hour)) {
            return false
        }

        val notificationId = SOCIAL_ALERT_BASE_ID + (platformName.hashCode() and 0x0FFF)
        val alertIntent = ThreatAlertActivity.createSocialAlertIntent(
            context = appContext,
            platformName = platformName,
            reason = summaryUz
        )
        val pendingIntent = PendingIntent.getActivity(
            appContext,
            notificationId,
            alertIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val channelId = if (prefs.soundEnabled) DownloadGuardService.CHANNEL_THREAT else CHANNEL_THREAT_SILENT
        val categoryLabel = categories.joinToString(" • ") { it.shortBadgeUz }

        val builder = NotificationCompat.Builder(appContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("XAVF! $platformName kontenti bloklandi")
            .setContentText(summaryUz)
            .setSubText(categoryLabel)
            .setStyle(NotificationCompat.BigTextStyle().bigText("[$categoryLabel]\n$summaryUz"))
            .setPriority(if (prefs.soundEnabled) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSilent(!prefs.soundEnabled)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val nm = appContext.getSystemService(NotificationManager::class.java) ?: return false
        return runCatching {
            nm.notify(notificationId, builder.build())
            true
        }.getOrDefault(false)
    }

    fun pushThreatNotification(
        context: Context,
        report: ApkScanReport,
        source: NotificationThreatSource,
        preferencesOverride: NotificationPreferences? = null,
        currentHourOverride: Int? = null
    ): Boolean {
        if (report.threatLevel == ThreatLevel.SAFE) return false

        val appContext = context.applicationContext
        ensureThreatNotificationChannel(appContext)
        if (!hasNotificationPermission(appContext)) {
            return false
        }

        val prefs = preferencesOverride ?: QalqonPreferencesRepository(appContext).getNotificationPreferencesBlocking()
        val categories = classifyApkThreatCategories(report)
        val hour = currentHourOverride ?: Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (!shouldDeliverNotification(prefs, categories, report.threatLevel, hour)) {
            return false
        }

        val targetKey = report.packageName ?: report.filePathOrUri.ifBlank { report.fileName }
        val baseId = if (source == NotificationThreatSource.NEWLY_INSTALLED_APP) {
            APP_ALERT_BASE_ID
        } else {
            FILE_ALERT_BASE_ID
        }
        val notificationId = baseId + (targetKey.hashCode() and 0x0FFF)

        val alertIntent = ThreatAlertActivity.createApkAlertIntent(
            context = appContext,
            fileName = report.fileName,
            filePath = if (source == NotificationThreatSource.NEWLY_INSTALLED_APP) {
                report.packageName ?: report.filePathOrUri
            } else {
                report.filePathOrUri
            },
            reason = report.reasonUz,
            indicators = report.suspiciousPermissions.joinToString("\n"),
            recommendation = report.recommendationUz
        )

        val primaryPendingIntent = PendingIntent.getActivity(
            appContext,
            notificationId,
            alertIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val categoryTag = categories.joinToString(" • ") { it.shortBadgeUz }

        val title = when (source) {
            NotificationThreatSource.NEWLY_INSTALLED_APP ->
                "XAVF! Yangi zararli ilova: ${report.fileName}"
            NotificationThreatSource.MALICIOUS_FILE ->
                "XAVF! Zararli fayl aniqlandi: ${report.fileName}"
            NotificationThreatSource.SOCIAL_CONTENT ->
                "XAVF! Kontent tahdidi: ${report.fileName}"
        }

        val shortBody = when (source) {
            NotificationThreatSource.NEWLY_INSTALLED_APP ->
                "Yangi o'rnatilgan APK xavfli deb topildi: ${report.reasonUz}"
            NotificationThreatSource.MALICIOUS_FILE,
            NotificationThreatSource.SOCIAL_CONTENT ->
                report.reasonUz
        }

        val fullBody = buildString {
            append("Turkum: $categoryTag\n")
            when (source) {
                NotificationThreatSource.NEWLY_INSTALLED_APP ->
                    append("Yangi o'rnatilgan ilova xavfli deb belgilandi.\n")
                NotificationThreatSource.MALICIOUS_FILE ->
                    append("Skanerlangan fayl xavfli deb belgilandi.\n")
                NotificationThreatSource.SOCIAL_CONTENT ->
                    append("Xavfli kontent aniqlandi.\n")
            }
            report.packageName?.let { append("Paket: $it\n") }
            append("Sabab: ${report.reasonUz}\n")
            append("Tavsiya: ${report.recommendationUz}")
        }

        val channelId = if (prefs.soundEnabled) DownloadGuardService.CHANNEL_THREAT else CHANNEL_THREAT_SILENT

        val builder = NotificationCompat.Builder(appContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title)
            .setContentText(shortBody)
            .setSubText(categoryTag)
            .setStyle(NotificationCompat.BigTextStyle().bigText(fullBody))
            .setPriority(if (prefs.soundEnabled) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSilent(!prefs.soundEnabled)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(primaryPendingIntent)
            .addAction(
                android.R.drawable.ic_dialog_alert,
                "Batafsil",
                primaryPendingIntent
            )

        if (source == NotificationThreatSource.NEWLY_INSTALLED_APP && !report.packageName.isNullOrBlank()) {
            val uninstallDetailsIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", report.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val uninstallPendingIntent = PendingIntent.getActivity(
                appContext,
                notificationId + 10_000,
                uninstallDetailsIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(
                android.R.drawable.ic_menu_delete,
                "Ilovani o'chirish",
                uninstallPendingIntent
            )
        }

        val nm = appContext.getSystemService(NotificationManager::class.java) ?: return false
        return runCatching {
            nm.notify(notificationId, builder.build())
            true
        }.getOrDefault(false)
    }
}
