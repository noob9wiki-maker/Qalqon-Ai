package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ProtectedAccountEntity
import com.example.ui.components.CyberMetricCard
import com.example.ui.components.ProtectedAccountCard
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson

@Composable
fun ProtectedAccountsScreen(
    protectedAccounts: List<ProtectedAccountEntity>,
    isBiometricLockEnabled: Boolean,
    onToggleAccountProtection: (ProtectedAccountEntity) -> Unit,
    onToggleAccountSafeSession: (ProtectedAccountEntity) -> Unit,
    onLockNow: () -> Unit
) {
    val activeCount = protectedAccounts.count { it.protectionActive }
    val totalBlocked = protectedAccounts.sumOf { it.blockedCount }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CyberSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AdminPanelSettings,
                                    contentDescription = "Himoyalangan Akkauntlar",
                                    tint = CyberCyan
                                )
                                Text(
                                    text = "Himoyalangan Akkauntlar",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            StatusBadgePill(
                                text = "Parollar saqlanmaydi",
                                accentColor = ShieldEmerald,
                                containerColor = ShieldEmeraldContainer
                            )
                        }

                        Text(
                            text = "Telegram, Instagram, YouTube va Facebook profillaringiz OAuth / Accessibility sessiya nazorati orqali parolsiz himoyalanadi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        if (isBiometricLockEnabled) {
                            OutlinedButton(
                                onClick = onLockNow,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("accounts_lock_now_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text(
                                    text = "Bo'limni qayta qulflash",
                                    color = CyberCyan,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CyberMetricCard(
                        label = "Faol profillar",
                        value = "$activeCount/${protectedAccounts.size}",
                        icon = Icons.Filled.VerifiedUser,
                        accentColor = ShieldEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    CyberMetricCard(
                        label = "Bloklangan urinishlar",
                        value = totalBlocked.toString(),
                        icon = Icons.Filled.BugReport,
                        accentColor = if (totalBlocked > 0) ThreatCrimson else CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Text(
                    text = "Ijtimoiy va messenjer profillari",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            items(protectedAccounts, key = { it.platform }) { account ->
                ProtectedAccountCard(
                    account = account,
                    onToggleProtection = { onToggleAccountProtection(account) },
                    onToggleSafeSession = { onToggleAccountSafeSession(account) }
                )
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}
