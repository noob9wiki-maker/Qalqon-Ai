package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiSensitivity
import com.example.data.ApkScanReport
import com.example.data.LogSourceType
import com.example.data.PermissionStatusSnapshot
import com.example.data.ProtectedAccountEntity
import com.example.data.QalqonRepository
import com.example.data.QalqonSettingsState
import com.example.data.SocialPlatform
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import com.example.data.KeywordRuleEntity
import com.example.data.NotificationPreferences
import com.example.data.OverviewRange
import com.example.data.ScannedFileEntity
import com.example.data.SecurityOverviewAggregator
import com.example.data.SecurityOverviewSummary
import com.example.data.ThreatNotificationCategory
import com.example.data.WhitelistEntryEntity
import com.example.data.WhitelistType
import com.example.security.ApkThreatAnalyzer
import com.example.security.BiometricAuthManager
import com.example.security.BiometricAvailabilityStatus
import com.example.security.ContentSafetyClassifier
import com.example.security.DownloadGuardService
import com.example.security.GeminiThreatAnalyzer
import com.example.security.InstalledAppsAuditEngine
import com.example.security.InstalledAppsAuditScheduler
import com.example.security.PanicExecutionResult
import com.example.security.PanicModeManager
import com.example.security.PermissionHelper
import com.example.security.SecurityNotificationService
import com.example.security.SensitiveArea
import com.example.ui.ThreatAlertActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicLong

sealed interface AiAnalysisUiState {
    data object Idle : AiAnalysisUiState
    data object Loading : AiAnalysisUiState
    data class Success(
        val isHarmful: Boolean,
        val riskLevel: ThreatLevel,
        val category: String,
        val explanationUz: String,
        val recommendedActionUz: String,
        val localMatchedKeywords: List<String>,
        val autoFilteredKeywords: List<String> = emptyList(),
        val detectedLanguage: String? = null
    ) : AiAnalysisUiState
    data class Error(val message: String) : AiAnalysisUiState
}

data class AssistantChatMessage(
    val id: Long,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)

data class AiAssistantUiState(
    val messages: List<AssistantChatMessage> = emptyList(),
    val isResponding: Boolean = false
)

sealed interface ApiKeyTestUiState {
    data object Idle : ApiKeyTestUiState
    data object Testing : ApiKeyTestUiState
    data class Success(val message: String) : ApiKeyTestUiState
    data class Error(val message: String) : ApiKeyTestUiState
}

data class ApkScannerUiState(
    val isScanning: Boolean = false,
    val lastReport: ApkScanReport? = null,
    val statusMessage: String? = null
)

class QalqonViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val repository = QalqonRepository(appContext)
    private val geminiAnalyzer = GeminiThreatAnalyzer(appContext)

    private val _permissions = MutableStateFlow(PermissionHelper.getPermissionSnapshot(appContext))
    val permissions: StateFlow<PermissionStatusSnapshot> = _permissions.asStateFlow()

    private val _apkScannerState = MutableStateFlow(ApkScannerUiState())
    val apkScannerState: StateFlow<ApkScannerUiState> = _apkScannerState.asStateFlow()

    private val _aiAnalysisState = MutableStateFlow<AiAnalysisUiState>(AiAnalysisUiState.Idle)
    val aiAnalysisState: StateFlow<AiAnalysisUiState> = _aiAnalysisState.asStateFlow()

    private val assistantMessageId = AtomicLong(0L)
    private val _assistantState = MutableStateFlow(AiAssistantUiState())
    val assistantState: StateFlow<AiAssistantUiState> = _assistantState.asStateFlow()

    private val _biometricAvailability = MutableStateFlow(BiometricAuthManager.checkAvailability(appContext))
    val biometricAvailability: StateFlow<BiometricAvailabilityStatus> = _biometricAvailability.asStateFlow()

    private val _unlockedAreas = MutableStateFlow<Set<SensitiveArea>>(emptySet())
    val unlockedAreas: StateFlow<Set<SensitiveArea>> = _unlockedAreas.asStateFlow()

    private val _isRunningAppAudit = MutableStateFlow(false)
    val isRunningAppAudit: StateFlow<Boolean> = _isRunningAppAudit.asStateFlow()

    private val _isPanicExecuting = MutableStateFlow(false)
    val isPanicExecuting: StateFlow<Boolean> = _isPanicExecuting.asStateFlow()

    private val _panicResult = MutableStateFlow<PanicExecutionResult?>(null)
    val panicResult: StateFlow<PanicExecutionResult?> = _panicResult.asStateFlow()

    private val _apiKeyTestState = MutableStateFlow<ApiKeyTestUiState>(ApiKeyTestUiState.Idle)
    val apiKeyTestState: StateFlow<ApiKeyTestUiState> = _apiKeyTestState.asStateFlow()

    val settings: StateFlow<QalqonSettingsState> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), QalqonSettingsState())

    val threatLogs: StateFlow<List<ThreatLogEntity>> = repository.threatLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blockedThreatsCount: StateFlow<Int> = repository.blockedThreatsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val blockedApkCount: StateFlow<Int> = repository.blockedApkCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val blockedSocialCount: StateFlow<Int> = repository.blockedSocialCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val keywordRules: StateFlow<List<KeywordRuleEntity>> = repository.keywordRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val protectedAccounts: StateFlow<List<ProtectedAccountEntity>> = repository.protectedAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val whitelistEntries: StateFlow<List<WhitelistEntryEntity>> = repository.whitelistEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scannedFiles: StateFlow<List<ScannedFileEntity>> = repository.scannedFiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _overviewRange = MutableStateFlow(OverviewRange.DAYS_7)
    val overviewRange: StateFlow<OverviewRange> = _overviewRange.asStateFlow()

    val securityOverview: StateFlow<SecurityOverviewSummary> = combine(
        scannedFiles,
        threatLogs,
        overviewRange
    ) { files, logs, range ->
        SecurityOverviewAggregator.buildOverview(
            scannedFiles = files,
            threatLogs = logs,
            range = range
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SecurityOverviewAggregator.empty(OverviewRange.DAYS_7)
    )

    val activeShieldsCount: StateFlow<Int> = combine(
        settings,
        permissions,
        protectedAccounts
    ) { s, p, accounts ->
        if (!s.isMasterShieldEnabled) 0
        else {
            var count = 0
            if (s.isApkAutoScanEnabled) count++
            if (s.isSocialGuardEnabled && p.hasAccessibilityService) count++
            if (s.isGeminiAnalysisEnabled) count++
            count += accounts.count { it.protectionActive }
            count
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 5)

    init {
        _assistantState.value = AiAssistantUiState(
            messages = listOf(
                AssistantChatMessage(
                    id = assistantMessageId.incrementAndGet(),
                    isUser = false,
                    text = "Assalomu alaykum! Men Qalqon AI kiberxavfsizlik yordamchisiman. " +
                        "Zararli APK o'rnatgan bo'lsangiz, akkauntingiz buzilgan deb gumon qilsangiz yoki shubhali havola/xabar ko'rgan bo'lsangiz — vaziyatni yozing, birgalikda tekshiramiz."
                )
            )
        )
        viewModelScope.launch(Dispatchers.IO) {
            repository.ensureInitialDataSeeded()
            val currentSettings = repository.settings.first()
            if (currentSettings.isMasterShieldEnabled && currentSettings.isApkAutoScanEnabled) {
                withContext(Dispatchers.Main) {
                    runCatching { DownloadGuardService.start(appContext) }
                }
            }
            if (currentSettings.isMasterShieldEnabled && currentSettings.isPeriodicAppAuditEnabled) {
                InstalledAppsAuditScheduler.schedulePeriodicAudit(appContext)
            }
        }
    }

    fun refreshPermissions() {
        _permissions.value = PermissionHelper.getPermissionSnapshot(appContext)
        _biometricAvailability.value = BiometricAuthManager.checkAvailability(appContext)
    }

    fun refreshBiometricAvailability() {
        _biometricAvailability.value = BiometricAuthManager.checkAvailability(appContext)
    }

    fun unlockSensitiveArea(area: SensitiveArea) {
        _unlockedAreas.value = _unlockedAreas.value + area
    }

    fun lockSensitiveArea(area: SensitiveArea) {
        _unlockedAreas.value = _unlockedAreas.value - area
    }

    fun lockAllSensitiveAreas() {
        if (_unlockedAreas.value.isNotEmpty()) {
            _unlockedAreas.value = emptySet()
        }
    }

    fun setBiometricLockEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setBiometricLockEnabled(enabled) }
    }

    fun setOverviewRange(range: OverviewRange) {
        _overviewRange.value = range
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            repository.setOnboardingCompleted(true)
            val s = settings.value
            if (s.isMasterShieldEnabled && s.isApkAutoScanEnabled) {
                runCatching { DownloadGuardService.start(appContext) }
            }
        }
    }

    fun reopenOnboarding() {
        viewModelScope.launch {
            repository.setOnboardingCompleted(false)
        }
    }

    fun setMasterShieldEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setMasterShieldEnabled(enabled)
            if (enabled && settings.value.isApkAutoScanEnabled) {
                runCatching { DownloadGuardService.start(appContext) }
            } else {
                runCatching { DownloadGuardService.stop(appContext) }
            }
            if (enabled && settings.value.isPeriodicAppAuditEnabled) {
                InstalledAppsAuditScheduler.schedulePeriodicAudit(appContext)
            } else if (!enabled) {
                InstalledAppsAuditScheduler.cancelPeriodicAudit(appContext)
            }
        }
    }

    fun setPeriodicAppAuditEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setPeriodicAppAuditEnabled(enabled)
            if (enabled && settings.value.isMasterShieldEnabled) {
                InstalledAppsAuditScheduler.schedulePeriodicAudit(appContext)
            } else {
                InstalledAppsAuditScheduler.cancelPeriodicAudit(appContext)
            }
        }
    }

    fun runInstalledAppsAuditNow() {
        if (_isRunningAppAudit.value) return
        viewModelScope.launch {
            _isRunningAppAudit.value = true
            try {
                InstalledAppsAuditScheduler.enqueueImmediateAudit(appContext)
                withContext(Dispatchers.IO) {
                    InstalledAppsAuditEngine.runLightweightAudit(appContext, forceAudit = true)
                }
            } finally {
                _isRunningAppAudit.value = false
            }
        }
    }

    fun setApkAutoScanEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setApkAutoScanEnabled(enabled)
            if (enabled && settings.value.isMasterShieldEnabled) {
                runCatching { DownloadGuardService.start(appContext) }
            } else {
                runCatching { DownloadGuardService.stop(appContext) }
            }
        }
    }

    fun setSocialGuardEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setSocialGuardEnabled(enabled) }
    }

    fun setGeminiAnalysisEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setGeminiAnalysisEnabled(enabled) }
    }

    fun setAiSensitivity(sensitivity: AiSensitivity) {
        viewModelScope.launch { repository.setAiSensitivity(sensitivity) }
    }

    fun saveGeminiApiKey(apiKey: String) {
        viewModelScope.launch {
            repository.setGeminiApiKey(apiKey)
            _apiKeyTestState.value = ApiKeyTestUiState.Success("API kalit xavfsiz saqlandi.")
        }
    }

    fun testGeminiApiKey(apiKey: String) {
        if (_apiKeyTestState.value is ApiKeyTestUiState.Testing) return
        viewModelScope.launch {
            _apiKeyTestState.value = ApiKeyTestUiState.Testing
            val cleaned = apiKey.trim()
            if (cleaned.isNotEmpty()) {
                repository.setGeminiApiKey(cleaned)
            }
            val result = geminiAnalyzer.testApiKey(cleaned.ifEmpty { null })
            _apiKeyTestState.value = result.fold(
                onSuccess = { msg -> ApiKeyTestUiState.Success(msg) },
                onFailure = { err ->
                    ApiKeyTestUiState.Error(err.message ?: "API kalitni tekshirishda xatolik yuz berdi.")
                }
            )
        }
    }

    fun resetApiKeyTestState() {
        _apiKeyTestState.value = ApiKeyTestUiState.Idle
    }

    fun setGeneralAlertsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setGeneralAlertsEnabled(enabled) }
    }

    fun setThreatCategoryNotification(
        category: ThreatNotificationCategory,
        enabled: Boolean
    ) {
        viewModelScope.launch { repository.setCategoryNotificationEnabled(category, enabled) }
    }

    fun setNotificationSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setNotificationSoundEnabled(enabled) }
    }

    fun setQuietHoursEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setQuietHoursEnabled(enabled) }
    }

    fun setCriticalBypassQuietHours(enabled: Boolean) {
        viewModelScope.launch { repository.setCriticalBypassQuietHours(enabled) }
    }

    fun applyNotificationPreset(preset: NotificationPreferences) {
        viewModelScope.launch { repository.applyNotificationPreset(preset) }
    }

    fun sendTestThreatNotification(category: ThreatNotificationCategory): String {
        val prefs = settings.value.notificationPreferences
        val sent = when (category) {
            ThreatNotificationCategory.PHISHING -> SecurityNotificationService.notifyMaliciousFile(
                context = appContext,
                report = ApkThreatAnalyzer.analyzeNameAndPermissions(
                    fileName = "Sinov_To'yga_taklifnoma.apk",
                    packageName = "com.example.test.phishing",
                    requestedPermissions = listOf("android.permission.INTERNET"),
                    filePathOrUri = "Sinov tekshiruvi: Phishing niqobi"
                ),
                preferencesOverride = prefs
            )
            ThreatNotificationCategory.MALWARE -> SecurityNotificationService.notifyMaliciousFile(
                context = appContext,
                report = ApkThreatAnalyzer.analyzeNameAndPermissions(
                    fileName = "Sinov_Troyan_Malware.apk",
                    packageName = "com.example.test.malware",
                    requestedPermissions = listOf(
                        "android.permission.READ_SMS",
                        "android.permission.BIND_ACCESSIBILITY_SERVICE"
                    ),
                    filePathOrUri = "Sinov tekshiruvi: Zararli troyan"
                ),
                preferencesOverride = prefs
            )
            ThreatNotificationCategory.SUSPICIOUS_BEHAVIOR -> SecurityNotificationService.notifyMaliciousFile(
                context = appContext,
                report = ApkThreatAnalyzer.analyzeNameAndPermissions(
                    fileName = "Sinov_Nostandart_Ilova.apk",
                    packageName = "com.example.test.suspicious",
                    requestedPermissions = listOf(
                        "android.permission.INTERNET",
                        "android.permission.RECORD_AUDIO"
                    ),
                    filePathOrUri = "Sinov tekshiruvi: Shubhali xatti-harakat",
                    hasHiddenLauncherIcon = true
                ),
                preferencesOverride = prefs
            )
            ThreatNotificationCategory.SOCIAL_THREATS -> SecurityNotificationService.notifySocialThreat(
                context = appContext,
                platformName = "Telegram",
                summaryUz = "Sinov xabari: Zararli va shubhali kontent bloklandi.",
                threatLevel = ThreatLevel.CRITICAL,
                preferencesOverride = prefs
            )
        }
        return when {
            sent -> "\"${category.shortBadgeUz}\" bo'yicha sinov bildirishnomasi yuborildi."
            !SecurityNotificationService.hasNotificationPermission(appContext) ->
                "Bildirishnoma yuborilmadi: Android tizim ruxsati berilmagan."
            !prefs.generalAlertsEnabled ->
                "Bildirishnoma filtrlandi: umumiy tahdid bildirishnomalari o'chirilgan."
            !prefs.isCategoryEnabled(category) ->
                "Bildirishnoma filtrlandi: \"${category.shortBadgeUz}\" turi o'chirilgan."
            else ->
                "Bildirishnoma tungi sokin rejim (23:00–07:00) sababli vaqtincha to'xtatildi."
        }
    }

    fun setScannerStatusMessage(message: String) {
        _apkScannerState.value = _apkScannerState.value.copy(
            isScanning = false,
            statusMessage = message
        )
    }

    fun scanPickedApk(uri: Uri) {
        viewModelScope.launch {
            _apkScannerState.value = ApkScannerUiState(
                isScanning = true,
                lastReport = _apkScannerState.value.lastReport,
                statusMessage = "APK fayl keshga nusxalanib, manifest va ruxsatlar o'qilmoqda..."
            )
            val reportResult = withContext(Dispatchers.IO) {
                runCatching {
                    ApkThreatAnalyzer.analyzeUriSafely(appContext, uri)
                }.getOrElse { Result.failure(it) }
            }
            reportResult.fold(
                onSuccess = { report ->
                    processApkScanReport(
                        report = report,
                        isTelegramHint = false,
                        forceGeminiHeuristic = true,
                        scanSource = "Qurilmadan tanlangan"
                    )
                },
                onFailure = { err ->
                    Log.w(TAG, "Failed scanning picked APK URI: $uri", err)
                    _apkScannerState.value = ApkScannerUiState(
                        isScanning = false,
                        lastReport = _apkScannerState.value.lastReport,
                        statusMessage = err.message ?: "Tanlangan faylni tekshirib bo'lmadi."
                    )
                }
            )
        }
    }

    fun scanPickedFolder(treeUri: Uri) {
        viewModelScope.launch {
            _apkScannerState.value = ApkScannerUiState(
                isScanning = true,
                lastReport = _apkScannerState.value.lastReport,
                statusMessage = "Tanlangan papka DocumentFile orqali tekshirilmoqda..."
            )

            val traversalOutcome = withContext(Dispatchers.IO) {
                runCatching {
                    runCatching {
                        appContext.contentResolver.takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    val rootDoc = DocumentFile.fromTreeUri(appContext, treeUri)
                        ?: throw IllegalStateException("Tanlangan papkaga kirish imkoni bo'lmadi.")
                    val folderLabel = rootDoc.name?.takeIf { it.isNotBlank() } ?: "Tanlangan papka"
                    val apkDocs = collectApkDocuments(rootDoc)
                    val reports = apkDocs.mapNotNull { doc ->
                        ApkThreatAnalyzer.analyzeUriSafely(appContext, doc.uri).getOrNull()
                    }
                    folderLabel to reports
                }
            }

            traversalOutcome.fold(
                onSuccess = { (folderLabel, foundReports) ->
                    if (foundReports.isEmpty()) {
                        repository.incrementScannedFilesCount(1)
                        _apkScannerState.value = ApkScannerUiState(
                            isScanning = false,
                            lastReport = _apkScannerState.value.lastReport,
                            statusMessage = "\"$folderLabel\" papkasida .apk fayllar topilmadi."
                        )
                    } else {
                        val runGeminiForAll = foundReports.size <= 3
                        var maliciousCount = 0
                        var lastProcessed: ApkScanReport? = null
                        foundReports.forEach { report ->
                            val isFlagged = report.threatLevel != ThreatLevel.SAFE
                            processApkScanReport(
                                report = report,
                                isTelegramHint = report.filePathOrUri.contains("telegram", ignoreCase = true) ||
                                    folderLabel.contains("telegram", ignoreCase = true),
                                forceGeminiHeuristic = runGeminiForAll || isFlagged,
                                scanSource = "Papka ($folderLabel)"
                            )
                            val updated = _apkScannerState.value.lastReport ?: report
                            lastProcessed = updated
                            if (updated.threatLevel != ThreatLevel.SAFE) {
                                maliciousCount++
                            }
                        }
                        val safeCount = (foundReports.size - maliciousCount).coerceAtLeast(0)
                        _apkScannerState.value = ApkScannerUiState(
                            isScanning = false,
                            lastReport = lastProcessed,
                            statusMessage = "\"$folderLabel\" papkasi tekshirildi: ${foundReports.size} ta APK ($maliciousCount ta zararli, $safeCount ta xavfsiz)."
                        )
                    }
                },
                onFailure = { err ->
                    Log.w(TAG, "Failed scanning DocumentTree folder URI: $treeUri", err)
                    _apkScannerState.value = ApkScannerUiState(
                        isScanning = false,
                        lastReport = _apkScannerState.value.lastReport,
                        statusMessage = err.message ?: "Tanlangan papkani tekshirishda xatolik yuz berdi."
                    )
                }
            )
        }
    }

    private fun collectApkDocuments(
        root: DocumentFile,
        maxDepth: Int = 4,
        maxVisited: Int = 400
    ): List<DocumentFile> {
        val result = mutableListOf<DocumentFile>()
        val queue = ArrayDeque<Pair<DocumentFile, Int>>()
        queue.add(root to 0)
        var visited = 0

        while (queue.isNotEmpty() && visited < maxVisited) {
            val (current, depth) = queue.removeFirst()
            val children = runCatching { current.listFiles() }.getOrDefault(emptyArray())
            for (child in children) {
                if (visited >= maxVisited) break
                visited++
                val isDir = runCatching { child.isDirectory }.getOrDefault(false)
                val isFile = runCatching { child.isFile }.getOrDefault(false)
                val name = runCatching { child.name }.getOrNull().orEmpty()
                if (isDir && depth < maxDepth) {
                    queue.add(child to (depth + 1))
                } else if (isFile && name.endsWith(".apk", ignoreCase = true)) {
                    result.add(child)
                }
            }
        }
        return result
    }

    fun analyzeLastReportWithGemini() {
        val current = _apkScannerState.value.lastReport ?: return
        viewModelScope.launch {
            _apkScannerState.value = _apkScannerState.value.copy(
                isScanning = true,
                statusMessage = "Gemini AI evristik xavfsizlik tahlili bajarilmoqda..."
            )
            val aiResult = withContext(Dispatchers.IO) {
                geminiAnalyzer.analyzeApkHeuristic(
                    fileName = current.fileName,
                    packageName = current.packageName,
                    suspiciousPermissions = current.suspiciousPermissions,
                    deceptiveMatch = current.deceptiveNameMatched,
                    metadata = current.metadata,
                    sensitivity = settings.value.aiSensitivity
                )
            }
            val updated = applyGeminiHeuristicResult(current, aiResult)
            if (aiResult.isSuccess) {
                withContext(Dispatchers.IO) {
                    persistScannedFile(updated, scanSource = "Gemini AI tahlili")
                }
            }
            if (updated.threatLevel != ThreatLevel.SAFE && current.threatLevel == ThreatLevel.SAFE) {
                SecurityNotificationService.notifyMaliciousFile(appContext, updated)
                launchAlertForReport(updated)
            }
            _apkScannerState.value = ApkScannerUiState(
                isScanning = false,
                lastReport = updated,
                statusMessage = if (updated.aiErrorMessage != null) {
                    updated.aiErrorMessage
                } else if (updated.threatLevel == ThreatLevel.SAFE) {
                    "\"${updated.fileName}\" Gemini AI evristik tahlili bo'yicha xavfsiz."
                } else {
                    "\"${updated.fileName}\" Gemini AI tomonidan xavfli deb topildi!"
                }
            )
        }
    }

    fun launchAlertForReport(report: ApkScanReport) {
        ThreatAlertActivity.launchApkAlert(
            context = appContext,
            fileName = report.fileName,
            filePath = report.filePathOrUri,
            reason = report.reasonUz,
            indicators = (report.suspiciousPermissions + (report.aiHeuristicResult?.heuristicFindingsUz ?: emptyList()))
                .distinct()
                .joinToString("\n"),
            recommendation = report.recommendationUz
        )
    }

    fun scanMonitoredFoldersNow() {
        viewModelScope.launch {
            _apkScannerState.value = ApkScannerUiState(
                isScanning = true,
                statusMessage = "Telegram va Yuklanmalar papkalari tekshirilmoqda..."
            )

            val foundReports = withContext(Dispatchers.IO) {
                runCatching {
                    val dirs = DownloadGuardService.getMonitoredDirectories()
                    val apkFiles = dirs.flatMap { dir ->
                        if (dir.exists() && dir.isDirectory) {
                            dir.listFiles()?.filter { it.isFile && it.name.endsWith(".apk", ignoreCase = true) }
                                ?: emptyList()
                        } else {
                            emptyList()
                        }
                    }
                    apkFiles.mapNotNull { file ->
                        runCatching { ApkThreatAnalyzer.analyzeFile(appContext, file) }.getOrNull()
                    }
                }.getOrDefault(emptyList())
            }

            if (foundReports.isEmpty()) {
                repository.incrementScannedFilesCount(1)
                _apkScannerState.value = ApkScannerUiState(
                    isScanning = false,
                    lastReport = null,
                    statusMessage = if (_permissions.value.hasAllFilesAccess) {
                        "Yuklanmalar va Telegram papkalarida shubhali .apk fayl topilmadi."
                    } else {
                        "Papkalarni to'liq tekshirish uchun \"Barcha fayllarga ruxsat\" bering yoki yuqoridan APK fayl tanlang."
                    }
                )
            } else {
                val runGeminiForAll = foundReports.size <= 3
                foundReports.forEach { report ->
                    processApkScanReport(
                        report = report,
                        isTelegramHint = report.filePathOrUri.contains("telegram", ignoreCase = true),
                        forceGeminiHeuristic = runGeminiForAll || report.threatLevel != ThreatLevel.SAFE,
                        scanSource = "Papka skaneri"
                    )
                }
            }
        }
    }

    fun checkSuspiciousFileName(fileNameInput: String) {
        val cleanName = fileNameInput.trim()
        if (cleanName.isEmpty()) return

        viewModelScope.launch {
            _apkScannerState.value = ApkScannerUiState(isScanning = true)
            val simulatedPerms = if (ApkThreatAnalyzer.detectDeceptiveFilename(cleanName) != null) {
                listOf(
                    "android.permission.READ_SMS",
                    "android.permission.BIND_ACCESSIBILITY_SERVICE"
                )
            } else {
                emptyList()
            }
            val report = ApkThreatAnalyzer.analyzeNameAndPermissions(
                fileName = cleanName,
                packageName = null,
                requestedPermissions = simulatedPerms,
                filePathOrUri = "Qo'lda tekshiruv: $cleanName"
            )
            processApkScanReport(
                report = report,
                isTelegramHint = true,
                forceGeminiHeuristic = true,
                scanSource = "Qo'lda tekshiruv"
            )
        }
    }

    fun triggerSampleMaliciousApkDemo() {
        viewModelScope.launch {
            val sampleReport = ApkThreatAnalyzer.analyzeNameAndPermissions(
                fileName = "To'yga taklifnoma.apk",
                packageName = "com.fake.taklifnoma.trojan",
                requestedPermissions = listOf(
                    "android.permission.READ_SMS",
                    "android.permission.RECEIVE_SMS",
                    "android.permission.BIND_ACCESSIBILITY_SERVICE",
                    "android.permission.READ_CONTACTS"
                ),
                filePathOrUri = "/storage/emulated/0/Download/Telegram/To'yga taklifnoma.apk"
            )
            processApkScanReport(
                report = sampleReport,
                isTelegramHint = true,
                forceGeminiHeuristic = false,
                scanSource = "Namuna sinovi"
            )
        }
    }

    private suspend fun processApkScanReport(
        report: ApkScanReport,
        isTelegramHint: Boolean,
        forceGeminiHeuristic: Boolean = false,
        scanSource: String = "APK Skaner"
    ) {
        repository.incrementScannedFilesCount(1)

        if (repository.isApkWhitelisted(report.fileName, report.packageName)) {
            val safeReport = report.copy(
                threatLevel = ThreatLevel.SAFE,
                reasonUz = "Ushbu fayl yoki paket Oq ro'yxatga kiritilgan.",
                recommendationUz = "Oq ro'yxatdagi ishonchli manba sifatida o'tkazib yuborildi."
            )
            repository.logThreat(
                ThreatLogEntity(
                    sourceType = LogSourceType.APK_SCAN.name,
                    title = "Oq ro'yxatdagi ishonchli fayl",
                    targetName = safeReport.fileName,
                    packageNameOrPath = safeReport.filePathOrUri,
                    threatLevel = ThreatLevel.SAFE.name,
                    reasonUz = safeReport.reasonUz,
                    detectedIndicators = safeReport.packageName.orEmpty(),
                    aiExplanation = safeReport.recommendationUz,
                    actionTaken = "OQ RO'YXAT"
                )
            )
            persistScannedFile(safeReport, scanSource = "$scanSource (Oq ro'yxat)")
            _apkScannerState.value = ApkScannerUiState(
                isScanning = false,
                lastReport = safeReport,
                statusMessage = "\"${safeReport.fileName}\" Oq ro'yxatda — xavfsiz deb o'tkazildi."
            )
            return
        }

        val shouldRunGemini = settings.value.isGeminiAnalysisEnabled &&
            (forceGeminiHeuristic || report.threatLevel != ThreatLevel.SAFE)

        val finalReport = if (shouldRunGemini) {
            _apkScannerState.value = _apkScannerState.value.copy(
                isScanning = true,
                lastReport = report,
                statusMessage = "Gemini AI evristik xavfsizlik tahlili bajarilmoqda..."
            )
            val aiResult = withContext(Dispatchers.IO) {
                geminiAnalyzer.analyzeApkHeuristic(
                    fileName = report.fileName,
                    packageName = report.packageName,
                    suspiciousPermissions = report.suspiciousPermissions,
                    deceptiveMatch = report.deceptiveNameMatched,
                    metadata = report.metadata,
                    sensitivity = settings.value.aiSensitivity
                )
            }
            applyGeminiHeuristicResult(report, aiResult)
        } else {
            report
        }

        val aiNote = finalReport.aiHeuristicResult?.let { ai ->
            "${ai.explanationUz} ${ai.recommendedActionUz}"
        } ?: finalReport.recommendationUz

        val combinedIndicators = buildList {
            addAll(finalReport.suspiciousPermissions)
            finalReport.aiHeuristicResult?.let { ai ->
                add("Gemini AI: ${ai.category} (${ai.confidencePercent}%)")
            }
        }.joinToString(" • ")

        repository.logThreat(
            ThreatLogEntity(
                sourceType = LogSourceType.APK_SCAN.name,
                title = when (finalReport.threatLevel) {
                    ThreatLevel.SAFE -> "APK fayl xavfsiz"
                    ThreatLevel.SUSPICIOUS -> "SHUBHALI! Evristik xavf aniqlandi"
                    ThreatLevel.CRITICAL -> "XAVF! Zararli fayl aniqlandi!"
                },
                targetName = finalReport.fileName,
                packageNameOrPath = finalReport.filePathOrUri,
                threatLevel = finalReport.threatLevel.name,
                reasonUz = finalReport.reasonUz,
                detectedIndicators = combinedIndicators,
                aiExplanation = aiNote,
                actionTaken = if (finalReport.threatLevel == ThreatLevel.SAFE) "XAVFSIZ" else "BLOKLANDI"
            )
        )
        persistScannedFile(finalReport, scanSource = scanSource)

        if (finalReport.threatLevel != ThreatLevel.SAFE) {
            if (isTelegramHint) {
                repository.incrementAccountBlocked(SocialPlatform.TELEGRAM)
            }
            SecurityNotificationService.notifyMaliciousFile(appContext, finalReport)
            launchAlertForReport(finalReport)
        }

        _apkScannerState.value = ApkScannerUiState(
            isScanning = false,
            lastReport = finalReport,
            statusMessage = when {
                finalReport.threatLevel != ThreatLevel.SAFE ->
                    "\"${finalReport.fileName}\" zararli deb topildi va bloklandi!"
                finalReport.aiHeuristicResult != null ->
                    "\"${finalReport.fileName}\" Gemini AI evristik tahlili bo'yicha xavfsiz."
                else ->
                    "\"${finalReport.fileName}\" xavfsiz deb topildi."
            }
        )
    }

    private suspend fun persistScannedFile(report: ApkScanReport, scanSource: String) {
        val status = if (report.threatLevel == ThreatLevel.SAFE) "SAFE" else "MALICIOUS"
        val summary = report.aiHeuristicResult?.explanationUz?.takeIf { it.isNotBlank() }
            ?: report.reasonUz
        repository.recordScannedFile(
            ScannedFileEntity(
                fileName = report.fileName,
                packageName = report.packageName,
                filePathOrUri = report.filePathOrUri,
                fileSizeBytes = report.metadata.fileSizeBytes,
                sha256 = report.metadata.sha256,
                status = status,
                riskLevel = report.threatLevel.name,
                scanSource = scanSource,
                summaryUz = summary,
                aiCategory = report.aiHeuristicResult?.category,
                aiConfidencePercent = report.aiHeuristicResult?.confidencePercent
            )
        )
    }

    private fun applyGeminiHeuristicResult(
        report: ApkScanReport,
        result: Result<com.example.data.ApkHeuristicAiResult>
    ): ApkScanReport {
        if (ApkThreatAnalyzer.isOfficialAppPackage(report.packageName)) {
            return report.copy(
                threatLevel = ThreatLevel.SAFE,
                reasonUz = "Rasmiy taniqlangan ilova paketi ishonchli manba sifatida xavfsiz deb belgilandi.",
                recommendationUz = "Rasmiy ilova: qo'shimcha chora talab qilinmaydi.",
                aiErrorMessage = null
            )
        }
        return result.fold(
            onSuccess = { ai ->
                val combinedLevel = maxThreatLevel(report.threatLevel, ai.riskLevel)
                val updatedReason = if (report.threatLevel == ThreatLevel.SAFE && ai.riskLevel != ThreatLevel.SAFE) {
                    ai.explanationUz
                } else {
                    report.reasonUz
                }
                report.copy(
                    threatLevel = combinedLevel,
                    reasonUz = updatedReason,
                    recommendationUz = ai.recommendedActionUz,
                    aiHeuristicResult = ai,
                    aiErrorMessage = null
                )
            },
            onFailure = { err ->
                report.copy(
                    aiErrorMessage = err.localizedMessage ?: "Gemini AI evristik tahlili bajarilmadi."
                )
            }
        )
    }

    private fun maxThreatLevel(a: ThreatLevel, b: ThreatLevel): ThreatLevel {
        val rank = mapOf(
            ThreatLevel.SAFE to 0,
            ThreatLevel.SUSPICIOUS to 1,
            ThreatLevel.CRITICAL to 2
        )
        return if ((rank[a] ?: 0) >= (rank[b] ?: 0)) a else b
    }

    fun sendAssistantMessage(text: String) {
        val cleanText = text.trim()
        if (cleanText.isBlank() || _assistantState.value.isResponding) return

        val history = _assistantState.value.messages
            .filterNot { it.isError }
            .map { it.isUser to it.text }
        val userMessage = AssistantChatMessage(
            id = assistantMessageId.incrementAndGet(),
            isUser = true,
            text = cleanText
        )
        _assistantState.value = _assistantState.value.copy(
            messages = _assistantState.value.messages + userMessage,
            isResponding = true
        )

        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                geminiAnalyzer.chatWithAssistant(cleanText, history)
            }
            val reply = result.fold(
                onSuccess = { answer ->
                    AssistantChatMessage(
                        id = assistantMessageId.incrementAndGet(),
                        isUser = false,
                        text = answer
                    )
                },
                onFailure = { err ->
                    AssistantChatMessage(
                        id = assistantMessageId.incrementAndGet(),
                        isUser = false,
                        text = "Kechirasiz, Gemini AI bilan bog'lanib bo'lmadi: " +
                            "${err.localizedMessage ?: "noma'lum xatolik"}. " +
                            "Internet aloqasini tekshirib, savolni qayta yuboring.",
                        isError = true
                    )
                }
            )
            _assistantState.value = _assistantState.value.copy(
                messages = _assistantState.value.messages + reply,
                isResponding = false
            )
        }
    }

    fun clearAssistantChat() {
        _assistantState.value = AiAssistantUiState(
            messages = listOf(
                AssistantChatMessage(
                    id = assistantMessageId.incrementAndGet(),
                    isUser = false,
                    text = "Suhbat yangilandi. Kiberxavfsizlik bo'yicha savolingizni yozing — " +
                        "zararli APK, buzilgan akkaunt yoki shubhali havola bo'ladimi, yordam beraman."
                )
            )
        )
    }

    private suspend fun autoPersistDangerousKeywords(
        text: String,
        geminiKeywords: List<String>,
        localKeywords: List<String>,
        category: String
    ): List<String> {
        val filterCategory = when (category) {
            "EKSTREMIZM", "NAFRAT", "ZO'RAVONLIK", "FIRIBGARLIK" -> category
            else -> "FIRIBGARLIK"
        }
        val hashtags = Regex("#[^\\s#.,!?…]+")
            .findAll(text)
            .map { it.value.removePrefix("#").trim() }
            .toList()
        val candidates = (geminiKeywords + hashtags + localKeywords)
            .map { it.trim().trimStart('#').trim().trim('"', '\'', '«', '»') }
            .filter { it.length in 3..80 && !it.contains('\n') }
            .distinctBy { it.lowercase() }
            .take(12)

        val added = mutableListOf<String>()
        candidates.forEach { keyword ->
            val language = detectKeywordLanguage(keyword, text)
            if (repository.addAutoFilteredKeywordRule(keyword, language, filterCategory)) {
                added.add(keyword)
            }
        }
        return added
    }

    private fun detectKeywordLanguage(keyword: String, text: String): String {
        fun isCyrillic(value: String) = value.any { it.code in 0x0400..0x04FF }
        return when {
            isCyrillic(keyword) || isCyrillic(text) -> "RU"
            Regex("(?i)\\b(how|click|link|free|win|verify|account|password|urgent|join|attack)\\b")
                .containsMatchIn(keyword) -> "EN"
            else -> "UZ"
        }
    }

    fun analyzeSocialPost(platform: SocialPlatform, postText: String) {
        val cleanText = postText.trim()
        if (cleanText.isEmpty()) return

        viewModelScope.launch {
            _aiAnalysisState.value = AiAnalysisUiState.Loading
            if (withContext(Dispatchers.IO) { repository.isContentWhitelisted(cleanText) }) {
                _aiAnalysisState.value = AiAnalysisUiState.Success(
                    isHarmful = false,
                    riskLevel = ThreatLevel.SAFE,
                    category = "OQ RO'YXAT",
                    explanationUz = "Ushbu matnda Oq ro'yxatga kiritilgan ishonchli kanal yoki manba aniqlandi.",
                    recommendedActionUz = "Oq ro'yxat qoidasi bo'yicha bloklanmadi.",
                    localMatchedKeywords = emptyList()
                )
                return@launch
            }
            val currentSettings = settings.value
            val rules = withContext(Dispatchers.IO) { repository.getEnabledKeywords() }
            val localResult = withContext(Dispatchers.Default) {
                ContentSafetyClassifier.classifyText(cleanText, rules, currentSettings.aiSensitivity)
            }

            if (currentSettings.isGeminiAnalysisEnabled) {
                val aiResult = withContext(Dispatchers.IO) {
                    geminiAnalyzer.analyzeSocialContent(
                        text = cleanText,
                        platformName = platform.displayName,
                        sensitivity = currentSettings.aiSensitivity
                    )
                }

                aiResult.fold(
                    onSuccess = { gemini ->
                        val combinedHarmful = gemini.isHarmful || localResult.isHarmful
                        val finalRisk = if (localResult.threatLevel == ThreatLevel.CRITICAL) {
                            ThreatLevel.CRITICAL
                        } else {
                            gemini.riskLevel
                        }

                        // Gemini extracts the real dangerous keyword/hashtag from UZ/RU/EN
                        // captions; persist it in Room so the offline filter blocks it later.
                        val autoFiltered = if (combinedHarmful) {
                            withContext(Dispatchers.IO) {
                                autoPersistDangerousKeywords(
                                    text = cleanText,
                                    geminiKeywords = gemini.dangerousKeywords,
                                    localKeywords = localResult.matchedKeywords,
                                    category = gemini.category
                                )
                            }
                        } else {
                            emptyList()
                        }

                        if (combinedHarmful) {
                            logSocialThreat(
                                platform = platform,
                                text = cleanText,
                                riskLevel = finalRisk,
                                reason = "${gemini.category}: ${gemini.explanationUz}",
                                indicators = (localResult.matchedKeywords +
                                    gemini.dangerousKeywords + autoFiltered + "Gemini AI").distinct(),
                                recommendation = gemini.recommendedActionUz
                            )
                        }

                        _aiAnalysisState.value = AiAnalysisUiState.Success(
                            isHarmful = combinedHarmful,
                            riskLevel = finalRisk,
                            category = gemini.category,
                            explanationUz = gemini.explanationUz,
                            recommendedActionUz = gemini.recommendedActionUz,
                            localMatchedKeywords = (localResult.matchedKeywords + autoFiltered).distinct(),
                            autoFilteredKeywords = autoFiltered,
                            detectedLanguage = gemini.detectedLanguage
                        )
                    },
                    onFailure = { err ->
                        Log.w(TAG, "Gemini social analysis failed, falling back to offline engine", err)
                        val autoFiltered = if (localResult.isHarmful) {
                            withContext(Dispatchers.IO) {
                                autoPersistDangerousKeywords(
                                    text = cleanText,
                                    geminiKeywords = emptyList(),
                                    localKeywords = localResult.matchedKeywords,
                                    category = localResult.categories.firstOrNull() ?: "FIRIBGARLIK"
                                )
                            }
                        } else {
                            emptyList()
                        }
                        if (localResult.isHarmful) {
                            logSocialThreat(
                                platform = platform,
                                text = cleanText,
                                riskLevel = localResult.threatLevel,
                                reason = localResult.summaryUz,
                                indicators = (localResult.matchedKeywords + autoFiltered).distinct(),
                                recommendation = "Kontent lokal kalit so'z filtri orqali bloklandi."
                            )
                        }
                        _aiAnalysisState.value = AiAnalysisUiState.Success(
                            isHarmful = localResult.isHarmful,
                            riskLevel = localResult.threatLevel,
                            category = localResult.categories.firstOrNull()
                                ?: if (localResult.isHarmful) "XAVFLI KONTENT" else "XAVFSIZ",
                            explanationUz = "Oflayn dvigatel: ${localResult.summaryUz}",
                            recommendedActionUz = if (localResult.isHarmful) {
                                "Ushbu post bilan o'zaro aloqa qilmang (Like/Share/Izoh bloklandi)."
                            } else {
                                "Oflayn tahlil bo'yicha xavf aniqlanmadi."
                            },
                            localMatchedKeywords = (localResult.matchedKeywords + autoFiltered).distinct(),
                            autoFilteredKeywords = autoFiltered
                        )
                    }
                )
            } else {
                if (localResult.isHarmful) {
                    logSocialThreat(
                        platform = platform,
                        text = cleanText,
                        riskLevel = localResult.threatLevel,
                        reason = localResult.summaryUz,
                        indicators = localResult.matchedKeywords,
                        recommendation = "Kontent lokal filtr tomonidan bloklandi."
                    )
                }
                _aiAnalysisState.value = AiAnalysisUiState.Success(
                    isHarmful = localResult.isHarmful,
                    riskLevel = localResult.threatLevel,
                    category = localResult.categories.firstOrNull() ?: "XAVFSIZ",
                    explanationUz = localResult.summaryUz,
                    recommendedActionUz = if (localResult.isHarmful) {
                        "Xavfli kontent bloklandi. Like va ulashish cheklandi."
                    } else {
                        "Lokal tahlil bo'yicha xavf aniqlanmadi."
                    },
                    localMatchedKeywords = localResult.matchedKeywords
                )
            }
        }
    }

    fun previewSocialBlockOverlay(platform: SocialPlatform, reason: String) {
        ThreatAlertActivity.launchSocialAlert(
            context = appContext,
            platformName = platform.displayName,
            reason = reason
        )
    }

    private suspend fun logSocialThreat(
        platform: SocialPlatform,
        text: String,
        riskLevel: ThreatLevel,
        reason: String,
        indicators: List<String>,
        recommendation: String
    ) {
        repository.incrementAccountBlocked(platform)
        repository.logThreat(
            ThreatLogEntity(
                sourceType = LogSourceType.SOCIAL_GUARD.name,
                title = "Bu kontent xavfsiz emas va bloklandi",
                targetName = "${platform.displayName}: ${text.take(120)}",
                packageNameOrPath = platform.packageNames.first(),
                threatLevel = riskLevel.name,
                reasonUz = reason,
                detectedIndicators = indicators.joinToString(" • "),
                aiExplanation = recommendation,
                actionTaken = "BLOKLANDI"
            )
        )
        SecurityNotificationService.notifySocialThreat(
            context = appContext,
            platformName = platform.displayName,
            summaryUz = reason,
            threatLevel = riskLevel
        )
    }

    fun addKeywordRule(keyword: String, language: String, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addKeywordRule(keyword, language, category)
        }
    }

    fun toggleKeywordRule(rule: KeywordRuleEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleKeywordRule(rule)
        }
    }

    fun deleteKeywordRule(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteKeywordRule(id)
        }
    }

    fun addWhitelistEntry(value: String, type: WhitelistType, noteUz: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addWhitelistEntry(value, type, noteUz)
        }
    }

    fun deleteWhitelistEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteWhitelistEntry(id)
        }
    }

    fun toggleAccountProtection(account: ProtectedAccountEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleAccountProtection(account)
        }
    }

    fun toggleAccountSafeSession(account: ProtectedAccountEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleAccountSafeSession(account)
        }
    }

    fun deleteThreatLog(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteThreatLogById(id)
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearLogs()
        }
    }

    fun deleteScannedFile(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteScannedFileById(id)
        }
    }

    fun clearScannedFilesHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearScannedFiles()
        }
    }

    fun deleteDangerousFileIfPossible(path: String): Boolean {
        return runCatching {
            val file = File(path)
            if (file.exists() && file.isFile) file.delete() else false
        }.getOrDefault(false)
    }

    fun triggerPanicMode() {
        if (_isPanicExecuting.value) return
        _isPanicExecuting.value = true

        // Immediately wipe in-memory sensitive analysis state and re-lock biometric tabs
        _unlockedAreas.value = emptySet()
        _apkScannerState.value = ApkScannerUiState()
        _aiAnalysisState.value = AiAnalysisUiState.Idle

        viewModelScope.launch {
            try {
                val suspiciousPackages = buildSet {
                    threatLogs.value
                        .filter { it.threatLevel != ThreatLevel.SAFE.name }
                        .forEach { add(it.packageNameOrPath) }
                    scannedFiles.value
                        .filter { it.status == "MALICIOUS" }
                        .mapNotNull { it.packageName }
                        .forEach { add(it) }
                }

                val result = withContext(Dispatchers.IO) {
                    PanicModeManager.executePanicLockdown(
                        context = appContext,
                        flaggedSuspiciousPackages = suspiciousPackages
                    )
                }

                val kbCleared = (result.clearedCacheBytes / 1024L).coerceAtLeast(
                    if (result.clearedCacheFilesCount > 0) 1L else 0L
                )
                withContext(Dispatchers.IO) {
                    repository.logThreat(
                        ThreatLogEntity(
                            sourceType = LogSourceType.APK_SCAN.name,
                            title = "Favqulodda himoya (Panic Mode)",
                            targetName = "Tizim keshi va fon jarayonlari",
                            packageNameOrPath = result.targetedPackages.joinToString(", ").ifBlank { appContext.packageName },
                            threatLevel = ThreatLevel.SAFE.name,
                            reasonUz = "Foydalanuvchi favqulodda himoyani faollashtirdi: ${result.terminatedProcessesCount} ta shubhali jarayon, ${result.stoppedBackgroundTasksCount} ta fon vazifasi to'xtatildi va $kbCleared KB maxfiy kesh tozalandi.",
                            detectedIndicators = "${result.clearedCacheFilesCount} ta kesh fayli o'chirildi",
                            aiExplanation = "Maxfiy bo'limlar qulflandi va vaqtinchalik xotira tozalandi.",
                            actionTaken = "TOZALANDI"
                        )
                    )
                }

                _panicResult.value = result
            } finally {
                _isPanicExecuting.value = false
            }
        }
    }

    fun dismissPanicResult() {
        _panicResult.value = null
    }

    companion object {
        private const val TAG = "QalqonViewModel"
    }
}
