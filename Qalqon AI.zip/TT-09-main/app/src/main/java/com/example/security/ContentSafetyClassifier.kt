package com.example.security

import com.example.data.AiSensitivity
import com.example.data.KeywordRuleEntity
import com.example.data.ThreatLevel

data class LocalClassificationResult(
    val isHarmful: Boolean,
    val threatLevel: ThreatLevel,
    val matchedKeywords: List<String>,
    val categories: Set<String>,
    val summaryUz: String
)

object ContentSafetyClassifier {

    @Volatile
    private var externalCriticalSignals: List<String> = emptyList()

    @Volatile
    private var externalMediumSignals: List<String> = emptyList()

    // Fallback baseline signals (UZ / RU / EN) if JSON catalog hasn't been loaded in unit-test context
    private val defaultHighRiskSignals = listOf(
        "ekstremist", "terror", "bomba", "portlatish", "qirg'in", "shafqatsiz",
        "jihodga da'vat", "yashirin jamoat", "maxfiy bay'at", "tuzumni ag'darish",
        "o'z joniga qasd", "суицид", "взрывчатка", "терроризм", "экстремизм",
        "джихад призыв", "вербовка в отряд", "насилие", "karta paroli", "pin kod",
        "cvv", "sms kodni ayting", "join extremist cell", "violent attack guide"
    )

    private val defaultMediumRiskSignals = listOf(
        "yashirin guruh", "maxfiy kanal", "oila a'zolaridan yashir", "pul yuboring",
        "oson daromad", "100% kafolatli foyda", "перевод срочно", "секретный чат",
        "секта", "вербовка", "тайная секта", "радикальный призыв", "nafrat", "kamsitish"
    )

    fun ensureInitialized(context: android.content.Context) {
        if (externalCriticalSignals.isEmpty() && externalMediumSignals.isEmpty()) {
            loadFromCatalog(BlacklistResourceLoader.loadCatalog(context))
        }
    }

    fun loadFromCatalog(catalog: BlacklistCatalog) {
        externalCriticalSignals = catalog.contentRules
            .filter { it.severity.equals("CRITICAL", ignoreCase = true) }
            .map { it.keyword }
        externalMediumSignals = catalog.contentRules
            .filter { !it.severity.equals("CRITICAL", ignoreCase = true) }
            .map { it.keyword }
    }

    fun classifyText(
        text: String,
        rules: List<KeywordRuleEntity> = emptyList(),
        sensitivity: AiSensitivity = AiSensitivity.MEDIUM
    ): LocalClassificationResult {
        if (text.isBlank()) {
            return LocalClassificationResult(
                isHarmful = false,
                threatLevel = ThreatLevel.SAFE,
                matchedKeywords = emptyList(),
                categories = emptySet(),
                summaryUz = "Tahlil qilish uchun matn topilmadi."
            )
        }

        val highSignals = (defaultHighRiskSignals + externalCriticalSignals).distinct()
        val mediumSignals = (defaultMediumRiskSignals + externalMediumSignals).distinct()

        val normalized = normalizeText(text)
        val matchedRules = rules.filter { it.isEnabled && normalized.contains(normalizeText(it.keyword)) }
        val highMatches = highSignals.filter { normalized.contains(normalizeText(it)) }
        val mediumMatches = mediumSignals.filter { normalized.contains(normalizeText(it)) }

        val allIndicators = (matchedRules.map { it.keyword } + highMatches + mediumMatches).distinct()
        val categories = matchedRules.map { it.category }.toMutableSet()
        if (highMatches.isNotEmpty()) categories.add("EKSTREMIZM / XAVF")
        if (mediumMatches.isNotEmpty() && categories.isEmpty()) categories.add("SHUBHALI KONTENT")

        val threatLevel = when {
            highMatches.isNotEmpty() || matchedRules.any {
                it.category == "EKSTREMIZM" || it.category == "ZO'RAVONLIK"
            } -> ThreatLevel.CRITICAL

            matchedRules.isNotEmpty() -> when (sensitivity) {
                AiSensitivity.LOW -> ThreatLevel.SUSPICIOUS
                AiSensitivity.MEDIUM, AiSensitivity.HIGH -> ThreatLevel.CRITICAL
            }

            mediumMatches.isNotEmpty() -> when (sensitivity) {
                AiSensitivity.HIGH -> ThreatLevel.CRITICAL
                AiSensitivity.MEDIUM -> ThreatLevel.SUSPICIOUS
                AiSensitivity.LOW -> ThreatLevel.SAFE
            }

            else -> ThreatLevel.SAFE
        }

        val isHarmful = threatLevel == ThreatLevel.CRITICAL ||
            (sensitivity == AiSensitivity.HIGH && threatLevel == ThreatLevel.SUSPICIOUS)

        val summaryUz = when {
            isHarmful -> "Zararli/xavfli iboralar aniqlandi: ${allIndicators.take(3).joinToString(", ")}"
            threatLevel == ThreatLevel.SUSPICIOUS -> "Shubhali ohang aniqlandi: ${allIndicators.take(2).joinToString(", ")}"
            else -> "Lokal filtr bo'yicha xavfli kalit so'zlar topilmadi."
        }

        return LocalClassificationResult(
            isHarmful = isHarmful,
            threatLevel = threatLevel,
            matchedKeywords = allIndicators,
            categories = categories,
            summaryUz = summaryUz
        )
    }

    private fun normalizeText(value: String): String {
        return value.lowercase()
            .replace("o‘", "o'")
            .replace("oʻ", "o'")
            .replace("o’", "o'")
            .replace("g‘", "g'")
            .replace("gʻ", "g'")
            .replace("g’", "g'")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }
}
