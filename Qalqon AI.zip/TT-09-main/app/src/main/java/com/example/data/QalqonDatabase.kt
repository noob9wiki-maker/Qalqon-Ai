package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ThreatLogEntity::class,
        KeywordRuleEntity::class,
        ProtectedAccountEntity::class,
        WhitelistEntryEntity::class,
        ScannedFileEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class QalqonDatabase : RoomDatabase() {
    abstract fun qalqonDao(): QalqonDao

    companion object {
        @Volatile
        private var INSTANCE: QalqonDatabase? = null

        fun getInstance(context: Context): QalqonDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    QalqonDatabase::class.java,
                    "qalqon_ai_security.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
