package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.WhitelistType
import com.example.security.SensitiveArea
import com.example.security.configureAppCheck
import com.example.ui.QalqonViewModel
import com.example.ui.components.BiometricLockGate
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.FileScannerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotificationSettingsScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProtectedAccountsScreen
import com.example.ui.screens.SecurityLogsScreen
import com.example.ui.screens.SecurityOverviewScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SocialGuardScreen
import com.example.ui.screens.WhitelistScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.QalqonAITheme
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ThreatCrimson

private const val ROUTE_WHITELIST = "oq_royxat"
private const val ROUTE_SECURITY_LOGS = "xavfsizlik_jurnali"
private const val ROUTE_SECURITY_OVERVIEW = "xavfsizlik_korinishi"
private const val ROUTE_NOTIFICATION_SETTINGS = "bildirishnoma_sozlamalari"

private enum class QalqonTab(
    val route: String,
    val labelUz: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(
        route = "bosh_sahifa",
        labelUz = "Bosh sahifa",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    FILES(
        route = "fayl_tekshiruvi",
        labelUz = "Fayl Tekshiruvi",
        selectedIcon = Icons.Filled.DocumentScanner,
        unselectedIcon = Icons.Outlined.DocumentScanner
    ),
    SOCIAL(
        route = "ijtimoiy_tarmoqlar",
        labelUz = "Ijtimoiy Tarmoqlar",
        selectedIcon = Icons.Filled.Public,
        unselectedIcon = Icons.Outlined.Public
    ),
    ACCOUNTS(
        route = "himoyalangan_akkauntlar",
        labelUz = "Akkauntlar",
        selectedIcon = Icons.Filled.AdminPanelSettings,
        unselectedIcon = Icons.Outlined.AdminPanelSettings
    ),
    ASSISTANT(
        route = "ai_yordamchi",
        labelUz = "AI Yordamchi",
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Filled.AutoAwesome
    ),
    SETTINGS(
        route = "sozlamalar",
        labelUz = "Sozlamalar",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check before Compose UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            QalqonAITheme {
                QalqonAppRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QalqonAppRoot(
    viewModel: QalqonViewModel = viewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val blockedThreatsCount by viewModel.blockedThreatsCount.collectAsStateWithLifecycle()
    val blockedApkCount by viewModel.blockedApkCount.collectAsStateWithLifecycle()
    val blockedSocialCount by viewModel.blockedSocialCount.collectAsStateWithLifecycle()
    val activeShieldsCount by viewModel.activeShieldsCount.collectAsStateWithLifecycle()
    val protectedAccounts by viewModel.protectedAccounts.collectAsStateWithLifecycle()
    val threatLogs by viewModel.threatLogs.collectAsStateWithLifecycle()
    val apkScannerState by viewModel.apkScannerState.collectAsStateWithLifecycle()
    val aiAnalysisState by viewModel.aiAnalysisState.collectAsStateWithLifecycle()
    val assistantState by viewModel.assistantState.collectAsStateWithLifecycle()
    val keywordRules by viewModel.keywordRules.collectAsStateWithLifecycle()
    val whitelistEntries by viewModel.whitelistEntries.collectAsStateWithLifecycle()
    val scannedFiles by viewModel.scannedFiles.collectAsStateWithLifecycle()
    val securityOverview by viewModel.securityOverview.collectAsStateWithLifecycle()
    val isRunningAppAudit by viewModel.isRunningAppAudit.collectAsStateWithLifecycle()
    val isPanicExecuting by viewModel.isPanicExecuting.collectAsStateWithLifecycle()
    val panicResult by viewModel.panicResult.collectAsStateWithLifecycle()
    val biometricAvailability by viewModel.biometricAvailability.collectAsStateWithLifecycle()
    val unlockedAreas by viewModel.unlockedAreas.collectAsStateWithLifecycle()
    val apiKeyTestState by viewModel.apiKeyTestState.collectAsStateWithLifecycle()

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshPermissions()
    }

    if (!settings.isOnboardingCompleted) {
        OnboardingScreen(
            permissions = permissions,
            onRefreshPermissions = viewModel::refreshPermissions,
            onContinueToApp = viewModel::completeOnboarding
        )
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: QalqonTab.HOME.route
    val isWhitelistRoute = currentRoute == ROUTE_WHITELIST
    val isSecurityLogsRoute = currentRoute == ROUTE_SECURITY_LOGS
    val isSecurityOverviewRoute = currentRoute == ROUTE_SECURITY_OVERVIEW
    val isNotificationSettingsRoute = currentRoute == ROUTE_NOTIFICATION_SETTINGS
    val isSubRoute = isWhitelistRoute ||
        isSecurityLogsRoute ||
        isSecurityOverviewRoute ||
        isNotificationSettingsRoute

    var previousRoute by remember { mutableStateOf(QalqonTab.HOME.route) }
    LaunchedEffect(currentRoute) {
        if (previousRoute == QalqonTab.ACCOUNTS.route && currentRoute != QalqonTab.ACCOUNTS.route) {
            viewModel.lockSensitiveArea(SensitiveArea.ACCOUNTS)
        }
        val wasInSettingsFlow = previousRoute == QalqonTab.SETTINGS.route ||
            previousRoute == ROUTE_WHITELIST ||
            previousRoute == ROUTE_SECURITY_LOGS ||
            previousRoute == ROUTE_NOTIFICATION_SETTINGS
        val isInSettingsFlow = currentRoute == QalqonTab.SETTINGS.route ||
            currentRoute == ROUTE_WHITELIST ||
            currentRoute == ROUTE_SECURITY_LOGS ||
            currentRoute == ROUTE_NOTIFICATION_SETTINGS
        if (wasInSettingsFlow && !isInSettingsFlow) {
            viewModel.lockSensitiveArea(SensitiveArea.SETTINGS)
        }
        previousRoute = currentRoute
    }

    val navigateToTab: (QalqonTab) -> Unit = { tab ->
        navController.navigate(tab.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg)
    ) {
        val useNavRail = maxWidth >= 680.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = CyberNavyBg,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        if (isSubRoute) {
                            IconButton(
                                onClick = { navController.popBackStack() },
                                modifier = Modifier.testTag("subroute_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Orqaga",
                                    tint = CyberCyan
                                )
                            }
                        }
                    },
                    title = {
                        Row(
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = "Qalqon AI",
                                tint = CyberCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = when {
                                    isWhitelistRoute -> "Oq ro'yxat"
                                    isSecurityLogsRoute -> "Xavfsizlik Jurnali"
                                    isSecurityOverviewRoute -> "Xavfsizlik Ko'rinishi"
                                    isNotificationSettingsRoute -> "Bildirishnoma sozlamalari"
                                    currentRoute == QalqonTab.ACCOUNTS.route -> "Himoyalangan Akkauntlar"
                                    currentRoute == QalqonTab.ASSISTANT.route -> "AI Yordamchi"
                                    currentRoute == QalqonTab.SETTINGS.route -> "Sozlamalar"
                                    else -> "Qalqon AI"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    actions = {
                        val activeSensitiveArea = when (currentRoute) {
                            QalqonTab.ACCOUNTS.route -> SensitiveArea.ACCOUNTS
                            QalqonTab.SETTINGS.route -> SensitiveArea.SETTINGS
                            else -> null
                        }
                        if (activeSensitiveArea != null &&
                            settings.isBiometricLockEnabled &&
                            unlockedAreas.contains(activeSensitiveArea)
                        ) {
                            IconButton(
                                onClick = { viewModel.lockSensitiveArea(activeSensitiveArea) },
                                modifier = Modifier.testTag("topbar_lock_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = "Bo'limni qulflash",
                                    tint = CyberCyan
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = CyberSurface,
                        titleContentColor = CyberTextPrimary
                    )
                )
            },
            bottomBar = {
                if (!useNavRail && !isSubRoute) {
                    NavigationBar(
                        containerColor = CyberSurface,
                        contentColor = CyberTextPrimary
                    ) {
                        QalqonTab.entries.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab) },
                                modifier = Modifier.testTag("nav_tab_${tab.route}"),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = if (tab == QalqonTab.ACCOUNTS) "Himoyalangan Akkauntlar" else tab.labelUz
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.labelUz,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyanContainer,
                                    unselectedIconColor = CyberTextSecondary,
                                    unselectedTextColor = CyberTextSecondary
                                )
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                if (currentRoute == QalqonTab.HOME.route) {
                    ExtendedFloatingActionButton(
                        onClick = { viewModel.triggerPanicMode() },
                        modifier = Modifier.testTag("panic_button_fab"),
                        containerColor = ThreatCrimson,
                        contentColor = CyberTextPrimary,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                        icon = {
                            if (isPanicExecuting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = CyberTextPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.PowerSettingsNew,
                                    contentDescription = "Favqulodda himoya (Panic Button)"
                                )
                            }
                        },
                        text = {
                            Text(
                                text = if (isPanicExecuting) "Tozalanmoqda..." else "Favqulodda himoya",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail && !isSubRoute) {
                    NavigationRail(
                        containerColor = CyberSurface,
                        contentColor = CyberTextPrimary
                    ) {
                        QalqonTab.entries.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab) },
                                modifier = Modifier.testTag("nav_rail_${tab.route}"),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = if (tab == QalqonTab.ACCOUNTS) "Himoyalangan Akkauntlar" else tab.labelUz
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.labelUz,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyanContainer,
                                    unselectedIconColor = CyberTextSecondary,
                                    unselectedTextColor = CyberTextSecondary
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = QalqonTab.HOME.route
                    ) {
                        composable(QalqonTab.HOME.route) {
                            HomeScreen(
                                settings = settings,
                                permissions = permissions,
                                blockedThreatsCount = blockedThreatsCount,
                                activeShieldsCount = activeShieldsCount,
                                securityOverview = securityOverview,
                                protectedAccounts = protectedAccounts,
                                recentLogs = threatLogs,
                                onToggleMasterShield = viewModel::setMasterShieldEnabled,
                                onSelectOverviewRange = viewModel::setOverviewRange,
                                onOpenSecurityOverview = { navController.navigate(ROUTE_SECURITY_OVERVIEW) },
                                onOpenProtectedAccounts = { navigateToTab(QalqonTab.ACCOUNTS) },
                                onNavigateToPermissions = { navigateToTab(QalqonTab.SETTINGS) },
                                onOpenSecurityLogs = { navController.navigate(ROUTE_SECURITY_LOGS) }
                            )
                        }

                        composable(QalqonTab.FILES.route) {
                            FileScannerScreen(
                                scannerState = apkScannerState,
                                permissions = permissions,
                                scannedFiles = scannedFiles,
                                whitelistCount = whitelistEntries.size,
                                onScanPickedApk = viewModel::scanPickedApk,
                                onScanPickedFolder = viewModel::scanPickedFolder,
                                onPickerError = viewModel::setScannerStatusMessage,
                                onRetryGeminiHeuristic = viewModel::analyzeLastReportWithGemini,
                                onLaunchAlertForReport = viewModel::launchAlertForReport,
                                onScanFoldersNow = viewModel::scanMonitoredFoldersNow,
                                onCheckFileName = viewModel::checkSuspiciousFileName,
                                onTriggerSampleAlertDemo = viewModel::triggerSampleMaliciousApkDemo,
                                onOpenWhitelist = { navController.navigate(ROUTE_WHITELIST) },
                                onWhitelistFile = { fileName ->
                                    viewModel.addWhitelistEntry(
                                        value = fileName,
                                        type = WhitelistType.APK_FILE,
                                        noteUz = "Fayl skaneridan Oq ro'yxatga qo'shildi"
                                    )
                                },
                                onDeleteScannedFile = viewModel::deleteScannedFile,
                                onClearScannedFiles = viewModel::clearScannedFilesHistory
                            )
                        }

                        composable(QalqonTab.SOCIAL.route) {
                            SocialGuardScreen(
                                permissions = permissions,
                                protectedAccounts = protectedAccounts,
                                keywordRules = keywordRules,
                                aiAnalysisState = aiAnalysisState,
                                onToggleAccountProtection = viewModel::toggleAccountProtection,
                                onAnalyzePost = viewModel::analyzeSocialPost,
                                onPreviewSocialBlockOverlay = viewModel::previewSocialBlockOverlay,
                                onAddKeywordRule = viewModel::addKeywordRule,
                                onToggleKeywordRule = viewModel::toggleKeywordRule,
                                onDeleteKeywordRule = viewModel::deleteKeywordRule
                            )
                        }

                        composable(QalqonTab.ASSISTANT.route) {
                            AiAssistantScreen(
                                state = assistantState,
                                onSendMessage = viewModel::sendAssistantMessage,
                                onClearChat = viewModel::clearAssistantChat
                            )
                        }

                        composable(QalqonTab.ACCOUNTS.route) {
                            val isUnlocked = !settings.isBiometricLockEnabled ||
                                unlockedAreas.contains(SensitiveArea.ACCOUNTS)
                            if (isUnlocked) {
                                ProtectedAccountsScreen(
                                    protectedAccounts = protectedAccounts,
                                    isBiometricLockEnabled = settings.isBiometricLockEnabled,
                                    onToggleAccountProtection = viewModel::toggleAccountProtection,
                                    onToggleAccountSafeSession = viewModel::toggleAccountSafeSession,
                                    onLockNow = { viewModel.lockSensitiveArea(SensitiveArea.ACCOUNTS) }
                                )
                            } else {
                                BiometricLockGate(
                                    area = SensitiveArea.ACCOUNTS,
                                    availability = biometricAvailability,
                                    onUnlockSuccess = { viewModel.unlockSensitiveArea(SensitiveArea.ACCOUNTS) },
                                    onRefreshAvailability = viewModel::refreshBiometricAvailability,
                                    onNavigateHome = { navigateToTab(QalqonTab.HOME) }
                                )
                            }
                        }

                        composable(QalqonTab.SETTINGS.route) {
                            val isUnlocked = !settings.isBiometricLockEnabled ||
                                unlockedAreas.contains(SensitiveArea.SETTINGS)
                            if (isUnlocked) {
                                SettingsScreen(
                                    settings = settings,
                                    permissions = permissions,
                                    biometricAvailability = biometricAvailability,
                                    whitelistCount = whitelistEntries.size,
                                    totalLogsCount = threatLogs.size,
                                    isRunningAppAudit = isRunningAppAudit,
                                    apiKeyTestState = apiKeyTestState,
                                    onRefreshPermissions = viewModel::refreshPermissions,
                                    onToggleMasterShield = viewModel::setMasterShieldEnabled,
                                    onToggleApkAutoScan = viewModel::setApkAutoScanEnabled,
                                    onTogglePeriodicAppAudit = viewModel::setPeriodicAppAuditEnabled,
                                    onRunAppAuditNow = viewModel::runInstalledAppsAuditNow,
                                    onToggleSocialGuard = viewModel::setSocialGuardEnabled,
                                    onToggleGeminiAnalysis = viewModel::setGeminiAnalysisEnabled,
                                    onToggleBiometricLock = viewModel::setBiometricLockEnabled,
                                    onLockNow = { viewModel.lockSensitiveArea(SensitiveArea.SETTINGS) },
                                    onSelectSensitivity = viewModel::setAiSensitivity,
                                    onSaveGeminiApiKey = viewModel::saveGeminiApiKey,
                                    onTestGeminiApiKey = viewModel::testGeminiApiKey,
                                    onOpenNotificationSettings = { navController.navigate(ROUTE_NOTIFICATION_SETTINGS) },
                                    onOpenWhitelist = { navController.navigate(ROUTE_WHITELIST) },
                                    onOpenSecurityLogs = { navController.navigate(ROUTE_SECURITY_LOGS) },
                                    onReopenOnboarding = viewModel::reopenOnboarding,
                                    onClearLogs = viewModel::clearAllLogs
                                )
                            } else {
                                BiometricLockGate(
                                    area = SensitiveArea.SETTINGS,
                                    availability = biometricAvailability,
                                    onUnlockSuccess = { viewModel.unlockSensitiveArea(SensitiveArea.SETTINGS) },
                                    onRefreshAvailability = viewModel::refreshBiometricAvailability,
                                    onNavigateHome = { navigateToTab(QalqonTab.HOME) }
                                )
                            }
                        }

                        composable(ROUTE_WHITELIST) {
                            WhitelistScreen(
                                entries = whitelistEntries,
                                onAddEntry = viewModel::addWhitelistEntry,
                                onDeleteEntry = viewModel::deleteWhitelistEntry,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_SECURITY_LOGS) {
                            SecurityLogsScreen(
                                logs = threatLogs,
                                blockedApkCount = blockedApkCount,
                                blockedSocialCount = blockedSocialCount,
                                onDeleteLog = viewModel::deleteThreatLog,
                                onClearAllLogs = viewModel::clearAllLogs,
                                onAddToWhitelist = { target, type ->
                                    viewModel.addWhitelistEntry(
                                        value = target,
                                        type = type,
                                        noteUz = "Xavfsizlik jurnalidan Oq ro'yxatga qo'shildi"
                                    )
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_SECURITY_OVERVIEW) {
                            SecurityOverviewScreen(
                                summary = securityOverview,
                                onSelectRange = viewModel::setOverviewRange,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_NOTIFICATION_SETTINGS) {
                            NotificationSettingsScreen(
                                preferences = settings.notificationPreferences,
                                permissions = permissions,
                                onRefreshPermissions = viewModel::refreshPermissions,
                                onToggleGeneralAlerts = viewModel::setGeneralAlertsEnabled,
                                onToggleCategory = viewModel::setThreatCategoryNotification,
                                onToggleSound = viewModel::setNotificationSoundEnabled,
                                onToggleQuietHours = viewModel::setQuietHoursEnabled,
                                onToggleCriticalBypass = viewModel::setCriticalBypassQuietHours,
                                onApplyPreset = viewModel::applyNotificationPreset,
                                onSendTestNotification = viewModel::sendTestThreatNotification
                            )
                        }
                    }
                }
            }
        }

        panicResult?.let { result ->
            val kbCleared = (result.clearedCacheBytes / 1024L).coerceAtLeast(
                if (result.clearedCacheFilesCount > 0) 1L else 0L
            )
            AlertDialog(
                onDismissRequest = viewModel::dismissPanicResult,
                containerColor = CyberSurface,
                icon = {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = "Favqulodda himoya bajarildi",
                        tint = ShieldEmerald,
                        modifier = Modifier.size(32.dp)
                    )
                },
                title = {
                    Text(
                        text = "Favqulodda himoya bajarildi!",
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = buildString {
                            append("• Shubhali fon jarayonlari va vazifalar to'xtatildi: ")
                            append("${result.terminatedProcessesCount + result.stoppedBackgroundTasksCount} ta\n")
                            append("• Tozalangan maxfiy kesh: $kbCleared KB (${result.clearedCacheFilesCount} ta fayl)\n")
                            append("• Biometrik bo'limlar va tahlil xotirasi qulflandi.")
                        },
                        color = CyberTextSecondary
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = viewModel::dismissPanicResult,
                        modifier = Modifier.testTag("panic_result_dismiss_button")
                    ) {
                        Text("Tushunarli", color = CyberCyan)
                    }
                }
            )
        }
    }
}
