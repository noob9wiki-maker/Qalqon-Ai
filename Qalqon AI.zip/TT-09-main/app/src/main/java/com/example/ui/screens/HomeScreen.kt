package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.OverviewRange
import com.example.data.PermissionStatusSnapshot
import com.example.data.ProtectedAccountEntity
import com.example.data.QalqonSettingsState
import com.example.data.SecurityOverviewSummary
import com.example.data.ThreatLogEntity
import com.example.ui.components.CyberMetricCard
import com.example.ui.components.PulsingShieldEmblem
import com.example.ui.components.SecurityOverviewDashboardCard
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.ThreatLogCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer

@Composable
fun HomeScreen(
    settings: QalqonSettingsState,
    permissions: PermissionStatusSnapshot,
    blockedThreatsCount: Int,
    activeShieldsCount: Int,
    securityOverview: SecurityOverviewSummary,
    protectedAccounts: List<ProtectedAccountEntity>,
    recentLogs: List<ThreatLogEntity>,
    onToggleMasterShield: (Boolean) -> Unit,
    onSelectOverviewRange: (OverviewRange) -> Unit,
    onOpenSecurityOverview: () -> Unit,
    onOpenProtectedAccounts: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onOpenSecurityLogs: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                HeroSecurityBotCard(
                    isShieldActive = settings.isMasterShieldEnabled,
                    isGeminiEnabled = settings.isGeminiAnalysisEnabled,
                    sensitivityTitle = settings.aiSensitivity.titleUz,
                    onToggleMasterShield = onToggleMasterShield
                )
            }

            if (!permissions.allCoreGranted) {
                item {
                    Surface(
                        onClick = onNavigateToPermissions,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_missing_permissions_banner"),
                        color = ThreatCrimsonContainer.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, ThreatCrimson.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "Ruxsatlar talab qilinadi",
                                tint = ThreatCrimson,
                                modifier = Modifier.size(22.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Ba'zi tizim ruxsatlari yoqilmagan (${permissions.grantedCount}/4)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "To'liq fon himoyasi uchun Sozlamalar bo'limidan ruxsat bering.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CyberMetricCard(
                        label = "Bloklangan tahdidlar",
                        value = blockedThreatsCount.toString(),
                        icon = Icons.Filled.BugReport,
                        accentColor = if (blockedThreatsCount > 0) ThreatCrimson else CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    CyberMetricCard(
                        label = "Tekshirilgan fayllar",
                        value = settings.scannedFilesCount.toString(),
                        icon = Icons.Filled.FolderZip,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    CyberMetricCard(
                        label = "Faol qalqonlar",
                        value = activeShieldsCount.toString(),
                        icon = Icons.Filled.VerifiedUser,
                        accentColor = ShieldEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                SecurityOverviewDashboardCard(
                    summary = securityOverview,
                    onSelectRange = onSelectOverviewRange,
                    onOpenFullOverview = onOpenSecurityOverview
                )
            }

            item {
                val activeProfiles = protectedAccounts.count { it.protectionActive }
                Surface(
                    onClick = onOpenProtectedAccounts,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_protected_accounts_card"),
                    color = CyberSurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AdminPanelSettings,
                                    contentDescription = "Himoyalangan Akkauntlar",
                                    tint = CyberCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(
                                        text = "Himoyalangan Akkauntlar",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = CyberTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "$activeProfiles/${protectedAccounts.size} profil faol himoyada",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CyberTextSecondary
                                    )
                                }
                            }
                            StatusBadgePill(
                                text = if (settings.isBiometricLockEnabled) "Biometrik qulf" else "Bot Faol",
                                accentColor = if (settings.isBiometricLockEnabled) CyberCyan else ShieldEmerald,
                                containerColor = if (settings.isBiometricLockEnabled) CyberCyanContainer else ShieldEmeraldContainer
                            )
                        }

                        Surface(
                            color = CyberSurfaceElevated,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CyberOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (settings.isBiometricLockEnabled) Icons.Filled.Fingerprint else Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Telegram, Instagram, YouTube va Facebook sessiyalarini boshqarish biometrika bilan himoyalangan.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = onOpenProtectedAccounts,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("home_open_accounts_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyanContainer,
                                contentColor = CyberCyan
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Fingerprint,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(
                                text = if (settings.isBiometricLockEnabled) {
                                    "Yuz / Barmoq izi bilan ochish"
                                } else {
                                    "Akkauntlarni boshqarish"
                                },
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "So'nggi xavfsizlik hodisalari",
                        style = MaterialTheme.typography.titleLarge,
                        color = CyberTextPrimary
                    )
                    TextButton(
                        onClick = onOpenSecurityLogs,
                        modifier = Modifier.testTag("home_open_security_logs_button")
                    ) {
                        Text(
                            text = "Barchasi",
                            color = CyberCyan,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            if (recentLogs.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = CyberSurface,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, CyberOutline)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.GppGood,
                                contentDescription = "Tizim toza",
                                tint = CyberCyan,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "Hozircha tahdid aniqlanmadi",
                                style = MaterialTheme.typography.titleSmall,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Telegram, Yuklanmalar va ijtimoiy tarmoqlar real vaqtda kuzatilmoqda.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(recentLogs.take(5), key = { it.id }) { log ->
                    ThreatLogCard(log = log)
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun HeroSecurityBotCard(
    isShieldActive: Boolean,
    isGeminiEnabled: Boolean,
    sensitivityTitle: String,
    onToggleMasterShield: (Boolean) -> Unit
) {
    val borderAccent = if (isShieldActive) CyberCyan.copy(alpha = 0.55f) else ThreatCrimson.copy(alpha = 0.55f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(CyberSurface)
            .then(
                Modifier.background(
                    Brush.linearGradient(
                        colors = listOf(
                            if (isShieldActive) CyberCyanContainer.copy(alpha = 0.45f)
                            else ThreatCrimsonContainer.copy(alpha = 0.45f),
                            CyberSurface
                        )
                    )
                )
            )
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_shield_hero),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .matchParentSize()
                .alpha(0.22f)
        )

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberNavyBg.copy(alpha = 0.35f),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, borderAccent)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        PulsingShieldEmblem(isActive = isShieldActive)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            StatusBadgePill(
                                text = if (isShieldActive) "Bot Himoyasi Faol • 24/7" else "Himoya to'xtatilgan",
                                accentColor = if (isShieldActive) ShieldEmerald else ThreatCrimson,
                                containerColor = if (isShieldActive) ShieldEmeraldContainer else ThreatCrimsonContainer
                            )
                            Text(
                                text = if (isShieldActive) "Qalqon AI Faol" else "Qalqon AI O'chiq",
                                style = MaterialTheme.typography.headlineSmall,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Switch(
                        checked = isShieldActive,
                        onCheckedChange = onToggleMasterShield,
                        modifier = Modifier.testTag("home_master_shield_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberNavyBg,
                            checkedTrackColor = CyberCyan,
                            uncheckedThumbColor = CyberTextPrimary,
                            uncheckedTrackColor = ThreatCrimsonContainer
                        )
                    )
                }

                Text(
                    text = if (isShieldActive) {
                        "Zararli APK fayllar, soxta Telegram taklifnomalar va xavfli kontentlar avtomatik filtrlanmoqda."
                    } else {
                        "Qurilma va ijtimoiy tarmoqlarni himoyalash uchun asosiy qalqonni yoqing."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusBadgePill(
                        text = if (isGeminiEnabled) "Gemini AI: Yoqilgan" else "Gemini AI: Lokal",
                        accentColor = CyberCyan,
                        containerColor = CyberCyanContainer
                    )
                    StatusBadgePill(
                        text = "Sezgirlik: $sensitivityTitle",
                        accentColor = CyberTextPrimary,
                        containerColor = CyberSurface
                    )
                }
            }
        }
    }
}
