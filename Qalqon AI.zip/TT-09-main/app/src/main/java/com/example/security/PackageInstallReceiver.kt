package com.example.security

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.LogSourceType
import com.example.data.QalqonRepository
import com.example.data.ScannedFileEntity
import com.example.data.ThreatLevel
import com.example.data.ThreatLogEntity
import com.example.ui.ThreatAlertActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PackageInstallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_PACKAGE_ADDED && action != Intent.ACTION_PACKAGE_REPLACED) return

        val packageName = intent.data?.schemeSpecificPart ?: return
        if (packageName == context.packageName) return

        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(Dispatchers.IO).launch {
            try {
                handleInstalledPackageEvent(appContext, packageName)
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        internal suspend fun handleInstalledPackageEvent(
            appContext: Context,
            packageName: String
        ) {
            val repo = QalqonRepository(appContext)
            val report = ApkThreatAnalyzer.analyzeInstalledPackage(appContext, packageName) ?: return

            repo.incrementScannedFilesCount(1)
            if (repo.isApkWhitelisted(report.fileName, packageName)) {
                repo.recordScannedFile(
                    ScannedFileEntity(
                        fileName = report.fileName,
                        packageName = packageName,
                        filePathOrUri = packageName,
                        status = "SAFE",
                        riskLevel = ThreatLevel.SAFE.name,
                        scanSource = "Yangi o'rnatilgan ilova (Oq ro'yxat)",
                        summaryUz = "Ilova Oq ro'yxatda bo'lgani uchun xavfsiz deb o'tkazildi."
                    )
                )
                return
            }

            if (report.threatLevel != ThreatLevel.SAFE) {
                repo.logThreat(
                    ThreatLogEntity(
                        sourceType = LogSourceType.APK_SCAN.name,
                        title = "Yangi o'rnatilgan shubhali ilova",
                        targetName = report.fileName,
                        packageNameOrPath = packageName,
                        threatLevel = report.threatLevel.name,
                        reasonUz = report.reasonUz,
                        detectedIndicators = report.suspiciousPermissions.joinToString(" • "),
                        aiExplanation = report.recommendationUz,
                        actionTaken = "OGOHLANTIRILDI"
                    )
                )
                repo.recordScannedFile(
                    ScannedFileEntity(
                        fileName = report.fileName,
                        packageName = packageName,
                        filePathOrUri = packageName,
                        status = "MALICIOUS",
                        riskLevel = report.threatLevel.name,
                        scanSource = "Yangi o'rnatilgan ilova",
                        summaryUz = report.reasonUz
                    )
                )
                SecurityNotificationService.notifyMaliciousInstalledApp(
                    context = appContext,
                    report = report
                )
                ThreatAlertActivity.launchApkAlert(
                    context = appContext,
                    fileName = report.fileName,
                    filePath = packageName,
                    reason = report.reasonUz,
                    indicators = report.suspiciousPermissions.joinToString("\n"),
                    recommendation = report.recommendationUz
                )
            } else {
                repo.recordScannedFile(
                    ScannedFileEntity(
                        fileName = report.fileName,
                        packageName = packageName,
                        filePathOrUri = packageName,
                        status = "SAFE",
                        riskLevel = ThreatLevel.SAFE.name,
                        scanSource = "Yangi o'rnatilgan ilova",
                        summaryUz = report.reasonUz
                    )
                )
            }
        }
    }
}
