package com.example.security

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.R

enum class SensitiveArea(
    val titleUz: String,
    val subtitleUz: String
) {
    ACCOUNTS(
        titleUz = "Himoyalangan Akkauntlar",
        subtitleUz = "Himoyalangan profillar va xavfsiz sessiya nazoratini ochish uchun yuz yoki barmoq izini tasdiqlang."
    ),
    SETTINGS(
        titleUz = "Sozlamalar",
        subtitleUz = "Tizim ruxsatlari, himoya modullari va AI sezgirligini boshqarish uchun biometrik tasdiqlashdan o'ting."
    )
}

enum class BiometricAvailabilityStatus(
    val badgeUz: String,
    val detailUz: String
) {
    READY(
        badgeUz = "Biometrika tayyor",
        detailUz = "Yuzni tanish, barmoq izi yoki qurilma paroli orqali tasdiqlash mumkin."
    ),
    NONE_ENROLLED(
        badgeUz = "Ro'yxatdan o'tmagan",
        detailUz = "Qurilma sozlamalarida barmoq izi, yuzni tanish yoki ekran qulfini yoqing."
    ),
    NO_HARDWARE(
        badgeUz = "Sensor topilmadi",
        detailUz = "Ushbu qurilmada biometrik autentifikatsiya apparati mavjud emas."
    ),
    UNAVAILABLE(
        badgeUz = "Vaqtincha mavjud emas",
        detailUz = "Biometrik sensor hozir band yoki tizim yangilanishi talab qilinadi."
    )
}

object BiometricAuthManager {

    fun allowedAuthenticators(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK
        }
    }

    fun checkAvailability(context: Context): BiometricAvailabilityStatus {
        val biometricManager = BiometricManager.from(context)
        return when (biometricManager.canAuthenticate(allowedAuthenticators())) {
            BiometricManager.BIOMETRIC_SUCCESS -> BiometricAvailabilityStatus.READY
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricAvailabilityStatus.NONE_ENROLLED
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricAvailabilityStatus.NO_HARDWARE
            else -> BiometricAvailabilityStatus.UNAVAILABLE
        }
    }

    fun createEnrollIntent(context: Context): Intent {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL).apply {
                putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, allowedAuthenticators())
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (enrollIntent.resolveActivity(context.packageManager) != null) {
                return enrollIntent
            }
        }
        return Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun authenticate(
        activity: FragmentActivity,
        area: SensitiveArea,
        onSuccess: () -> Unit,
        onFailureOrCancel: (String) -> Unit
    ) {
        val status = checkAvailability(activity)
        if (status != BiometricAvailabilityStatus.READY) {
            onFailureOrCancel(status.detailUz)
            return
        }

        val executor = ContextCompat.getMainExecutor(activity)
        val biometricPrompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    val message = when (errorCode) {
                        BiometricPrompt.ERROR_USER_CANCELED,
                        BiometricPrompt.ERROR_NEGATIVE_BUTTON,
                        BiometricPrompt.ERROR_CANCELED ->
                            "Biometrik tasdiqlash bekor qilindi. Davom etish uchun qayta tasdiqlang."
                        BiometricPrompt.ERROR_LOCKOUT,
                        BiometricPrompt.ERROR_LOCKOUT_PERMANENT ->
                            "Noto'g'ri urinishlar ko'payib ketdi. Birozdan so'ng qayta urinib ko'ring."
                        BiometricPrompt.ERROR_NO_BIOMETRICS ->
                            "Qurilmada yuz yoki barmoq izi ro'yxatdan o'tkazilmagan."
                        else -> "Tasdiqlash xatoligi: $errString"
                    }
                    onFailureOrCancel(message)
                }
            }
        )

        val promptBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(activity.getString(R.string.biometric_prompt_title))
            .setSubtitle(
                when (area) {
                    SensitiveArea.SETTINGS -> activity.getString(R.string.biometric_prompt_subtitle_settings)
                    SensitiveArea.ACCOUNTS -> activity.getString(R.string.biometric_prompt_subtitle_accounts)
                }
            )
            .setConfirmationRequired(false)
            .setAllowedAuthenticators(allowedAuthenticators())

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            promptBuilder.setNegativeButtonText(activity.getString(R.string.biometric_prompt_negative))
        }

        runCatching {
            biometricPrompt.authenticate(promptBuilder.build())
        }.onFailure { err ->
            onFailureOrCancel(err.localizedMessage ?: "Biometrik oynani ochishda xatolik yuz berdi.")
        }
    }
}
