package com.example.security

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.AiSensitivity
import com.example.data.ApkHeuristicAiResult
import com.example.data.ApkHeuristicMetadata
import com.example.data.GeminiAnalysisResult
import com.example.data.QalqonPreferencesRepository
import com.example.data.ThreatLevel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class GeminiThreatAnalyzer(private val context: Context? = null) {

    private fun resolveApiKey(overrideKey: String? = null): String {
        val candidate = overrideKey?.trim()
        if (!candidate.isNullOrBlank()) return candidate
        val ctx = context ?: return QalqonPreferencesRepository.DEFAULT_GEMINI_API_KEY
        return QalqonPreferencesRepository(ctx).getGeminiApiKeySync()
    }

    private fun isNetworkAvailable(): Boolean {
        val ctx = context ?: return true
        return runCatching {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return true
            val network = cm.activeNetwork ?: return false
            val capabilities = cm.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }.getOrDefault(true)
    }

    suspend fun testApiKey(apiKeyOverride: String? = null): Result<String> {
        val apiKey = resolveApiKey(apiKeyOverride)
        if (apiKey.isBlank()) {
            return Result.failure(IllegalArgumentException("API kalit bo'sh bo'lishi mumkin emas."))
        }
        if (!isNetworkAvailable()) {
            return Result.failure(
                IllegalStateException("Internet aloqasi yo'q. Tarmoqqa ulaning (hozircha oflayn dvigatel faol).")
            )
        }

        val startTime = System.currentTimeMillis()
        val testSchema = JSONObject().apply {
            put("type", "OBJECT")
            put("properties", JSONObject().apply {
                put("status", JSONObject().apply { put("type", "STRING") })
            })
            put("required", JSONArray().put("status"))
        }

        return postToGeminiApi(
            apiKey = apiKey,
            prompt = "Respond with JSON {\"status\": \"ok\"} to verify connectivity.",
            temperature = 0.0,
            responseSchema = testSchema
        ).fold(
            onSuccess = {
                val elapsedMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
                Result.success("Gemini AI REST API muvaffaqiyatli ulandi! ($elapsedMs ms)")
            },
            onFailure = { err ->
                Result.failure(err)
            }
        )
    }

    suspend fun analyzeSocialContent(
        text: String,
        platformName: String,
        sensitivity: AiSensitivity
    ): Result<GeminiAnalysisResult> {
        if (!isNetworkAvailable()) {
            return Result.success(offlineSocialFallback(text, sensitivity))
        }

        val prompt = """
            You are Qalqon AI, an expert semantic-intent analyst for social media safety in Uzbekistan.
            Analyze this $platformName post, comment, caption or Reels text. It may be in Uzbek (Latin or Cyrillic), Russian, English, or a mix of them.
            Sensitivity setting: ${sensitivity.name}.

            Judge the TRUE SEMANTIC INTENT, not just literal bad words. Slang, coded wording, emojis and hashtags (#...) count as content:
            1) Extremist / radical recruitment, terrorism glorification, covert radicalization, calls to violent action.
            2) Hate speech, ethnic or religious hostility, incitement to violence.
            3) Scams and social engineering: fake transfers, card/SMS OTP theft, malicious APK lures, fake giveaways, phishing links.
            4) Harmless jokes, news reporting, education, quotes and satire must stay SAFE — do not flag them merely for mentioning a sensitive topic.

            Detect the language as UZ, RU, EN or MIXED. In dangerousKeywords return the exact dangerous word, phrase or hashtag(s) (without the # sign) that carry the harmful meaning, in their original language, max 8 items. Return an empty array when the content is safe.

            Respond strictly in JSON matching the schema. All explanations and advice must be in Uzbek Latin script.

            Content to analyze:
            "$text"
        """.trimIndent()

        val result = runStructuredAnalysis(prompt, buildSocialAnalysisSchemaJson())
        return result.fold(
            onSuccess = { Result.success(it) },
            onFailure = { err ->
                Log.w(TAG, "Gemini REST social analysis failed, using offline fallback: ${err.message}")
                Result.success(offlineSocialFallback(text, sensitivity))
            }
        )
    }

    suspend fun analyzeApkHeuristic(
        fileName: String,
        packageName: String?,
        suspiciousPermissions: List<String>,
        deceptiveMatch: String?,
        metadata: ApkHeuristicMetadata,
        sensitivity: AiSensitivity = AiSensitivity.MEDIUM
    ): Result<ApkHeuristicAiResult> {
        if (ApkThreatAnalyzer.isOfficialAppPackage(packageName)) {
            return Result.success(
                ApkHeuristicAiResult(
                    isMalicious = false,
                    riskLevel = ThreatLevel.SAFE,
                    category = "XAVFSIZ",
                    confidencePercent = 99,
                    heuristicFindingsUz = emptyList(),
                    explanationUz = "Rasmiy taniqlangan ilova paketi ($packageName) ishonchli deb belgilandi.",
                    recommendedActionUz = "Rasmiy ilova: qo'shimcha chora talab qilinmaydi."
                )
            )
        }
        if (!isNetworkAvailable()) {
            return Result.success(
                offlineApkHeuristicFallback(
                    fileName = fileName,
                    suspiciousPermissions = suspiciousPermissions,
                    deceptiveMatch = deceptiveMatch,
                    metadata = metadata
                )
            )
        }

        val prompt = """
            You are Qalqon AI, an expert Android malware reverse-engineer and heuristic security analyzer.
            Perform a deep heuristic security analysis on this APK file selected from a user's Android device to determine whether the app is MALICIOUS, SUSPICIOUS, or SAFE.
            AI Sensitivity: ${sensitivity.name}

            APK Forensic Profile:
            - File Name: "$fileName"
            - App Label: "${metadata.appLabel ?: "noma'lum"}"
            - Package Name: "${packageName ?: "noma'lum"}"
            - Version: "${metadata.versionName ?: "noma'lum"} (${metadata.versionCode ?: 0})"
            - Valid APK ZIP & AndroidManifest.xml: ${metadata.hasValidApkStructure}
            - File Size (bytes): ${metadata.fileSizeBytes}
            - SHA-256: ${metadata.sha256 ?: "noma'lum"}
            - minSdk / targetSdk: ${metadata.minSdk ?: "?"} / ${metadata.targetSdk ?: "?"}
            - Hidden Launcher Icon Detected: ${metadata.hasHiddenLauncherIcon} (activities: ${metadata.activityCount})
            - Signing Certificates Count: ${metadata.signatureCount}
            - DEX Files Count: ${metadata.dexFileCount}
            - Native ABIs: ${metadata.nativeLibs.joinToString(", ").ifEmpty { "yo'q" }}
            - Suspicious Hidden Assets (payload/dropper candidates): ${metadata.suspiciousAssets.joinToString(", ").ifEmpty { "yo'q" }}
            - Deceptive Filename/Social Engineering Match: "${deceptiveMatch ?: "yo'q"}"
            - High-Risk Permissions Flagged Locally: ${suspiciousPermissions.joinToString("; ").ifEmpty { "yo'q" }}
            - All Requested Permissions (${metadata.allRequestedPermissions.size}): ${metadata.allRequestedPermissions.take(40).joinToString(", ").ifEmpty { "yo'q" }}
            - Declared Services: ${metadata.declaredServices.joinToString(", ").ifEmpty { "yo'q" }}
            - Declared BroadcastReceivers: ${metadata.declaredReceivers.joinToString(", ").ifEmpty { "yo'q" }}

            Heuristic Rules to Evaluate:
            1) Banking Trojans / OTP Stealers: READ_SMS/RECEIVE_SMS + INTERNET or deceptive Uzbek/Russian filenames ("To'y", "Taklifnoma", "Albom", "Video", "Rasm", "Karta", "Mukofot").
            2) Accessibility Spyware / Overlay Phishing: BIND_ACCESSIBILITY_SERVICE + SYSTEM_ALERT_WINDOW (especially in unsigned/unknown APKs).
            3) Hidden Launcher / Droppers: Hidden launcher icon (0 activities with background services/permissions) or hidden .apk/.dex/.bin/.jar payloads in assets/.
            4) Do NOT flag normal everyday apps as MALICIOUS/SUSPICIOUS merely for requesting CAMERA, RECORD_AUDIO, RECEIVE_BOOT_COMPLETED, INTERNET, or older targetSdk unless combined with high-confidence malware indicators above.
            5) Safe Apps: legitimate utilities, messengers, readers, or normal tools without deceptive filenames, hidden launcher icons, or dangerous permission combinations.
            6) Always answer SAFE / isMalicious=false for official trusted packages: org.telegram.*, com.whatsapp*, com.instagram.*, com.google.*, com.facebook.*, com.openai.*, com.microsoft.*, com.android.*, com.xiaomi.*, com.miui.*. Never flag these as malicious.

            Respond strictly in JSON matching the schema, with all human-readable findings and advice written clearly in Uzbek (Latin script).
        """.trimIndent()

        val apiKey = resolveApiKey()
        val apiResponse = postToGeminiApi(
            apiKey = apiKey,
            prompt = prompt,
            temperature = 0.15,
            responseSchema = buildApkHeuristicSchemaJson()
        )

        return apiResponse.fold(
            onSuccess = { rawJson ->
                runCatching {
                    val cleanJson = stripMarkdownFences(rawJson)
                    val json = JSONObject(cleanJson)
                    val isOfficialPackage = ApkThreatAnalyzer.isOfficialAppPackage(packageName)
                    val riskLevel = if (isOfficialPackage) {
                        ThreatLevel.SAFE
                    } else {
                        runCatching {
                            ThreatLevel.valueOf(json.optString("riskLevel", "SAFE"))
                        }.getOrDefault(ThreatLevel.SAFE)
                    }

                    val findingsArray = json.optJSONArray("heuristicFindingsUz")
                    val findings = buildList {
                        if (!isOfficialPackage && findingsArray != null) {
                            for (i in 0 until findingsArray.length()) {
                                val item = findingsArray.optString(i).trim()
                                if (item.isNotEmpty()) add(item)
                            }
                        }
                    }

                    ApkHeuristicAiResult(
                        isMalicious = !isOfficialPackage && json.optBoolean("isMalicious", riskLevel != ThreatLevel.SAFE),
                        riskLevel = riskLevel,
                        category = if (isOfficialPackage) {
                            "XAVFSIZ"
                        } else {
                            json.optString(
                                "category",
                                if (riskLevel == ThreatLevel.SAFE) "XAVFSIZ" else "ZARARLI_APK"
                            )
                        },
                        confidencePercent = json.optInt("confidencePercent", 85).coerceIn(0, 100),
                        heuristicFindingsUz = findings,
                        explanationUz = if (isOfficialPackage) {
                            "Rasmiy taniqlangan ilova paketi ($packageName) ishonchli deb belgilandi."
                        } else {
                            json.optString("explanationUz", "Gemini AI evristik tahlili yakunlandi.")
                        },
                        recommendedActionUz = if (isOfficialPackage) {
                            "Rasmiy ilova: qo'shimcha chora talab qilinmaydi."
                        } else {
                            json.optString(
                                "recommendedActionUz",
                                if (riskLevel == ThreatLevel.SAFE) {
                                    "Fayl xavfsiz ko'rinadi, ammo faqat ishonchli manbadan o'rnating."
                                } else {
                                    "Ushbu ilovani o'rnatmang va qurilmadan darhol o'chiring."
                                }
                            )
                        }
                    )
                }.fold(
                    onSuccess = { Result.success(it) },
                    onFailure = { parseErr ->
                        Log.w(TAG, "Failed to parse Gemini APK heuristic JSON, using offline fallback", parseErr)
                        Result.success(
                            offlineApkHeuristicFallback(fileName, suspiciousPermissions, deceptiveMatch, metadata)
                        )
                    }
                )
            },
            onFailure = { err ->
                Log.w(TAG, "Gemini REST APK heuristic failed, using offline fallback: ${err.message}")
                Result.success(
                    offlineApkHeuristicFallback(fileName, suspiciousPermissions, deceptiveMatch, metadata)
                )
            }
        )
    }

    suspend fun analyzeApkRisk(
        fileName: String,
        packageName: String?,
        suspiciousPermissions: List<String>,
        deceptiveMatch: String?
    ): Result<GeminiAnalysisResult> {
        if (!isNetworkAvailable()) {
            val isRisky = deceptiveMatch != null || suspiciousPermissions.isNotEmpty()
            return Result.success(
                GeminiAnalysisResult(
                    isHarmful = isRisky,
                    riskLevel = if (deceptiveMatch != null || suspiciousPermissions.size >= 2) ThreatLevel.CRITICAL else if (isRisky) ThreatLevel.SUSPICIOUS else ThreatLevel.SAFE,
                    category = if (isRisky) "ZARARLI_APK" else "XAVFSIZ",
                    explanationUz = "Oflayn dvigatel tahlili: ${deceptiveMatch ?: if (isRisky) "${suspiciousPermissions.size} ta xavfli ruxsat aniqlandi." else "lokal xavfli alomat topilmadi."}",
                    recommendedActionUz = if (isRisky) "Ushbu APK faylni o'rnatmang va qurilmadan o'chiring." else "Faqat ishonchli manbadan o'rnating."
                )
            )
        }

        return runStructuredAnalysis(
            """
            You are Qalqon AI, an Android malware & Telegram phishing APK analyzer.
            Assess this APK file detected on a user's Android device.
            File name: "$fileName"
            Package name: "${packageName ?: "noma'lum"}"
            Social engineering lure match: "${deceptiveMatch ?: "yo'q"}"
            Requested dangerous permissions: "${suspiciousPermissions.joinToString(", ").ifEmpty { "yo'q" }}"
            Explain in Uzbek Latin script whether this is a disguised spyware/banking trojan (e.g., To'yga taklifnoma, Foto albom, Karta pul o'tkazmasi traps) and what the user should do.
            """.trimIndent()
        )
    }

    /**
     * Free-form cybersecurity assistant used by the "AI Yordamchi" chat tab.
     * Gemini receives recent conversation turns plus a Uzbek expert system prompt.
     */
    suspend fun chatWithAssistant(
        message: String,
        history: List<Pair<String, String>> = emptyList()
    ): Result<String> {
        val cleanMessage = message.trim()
        if (cleanMessage.isBlank()) {
            return Result.failure(IllegalArgumentException("Xabar bo'sh bo'lishi mumkin emas."))
        }
        if (!isNetworkAvailable()) {
            return Result.success(offlineAssistantReply(cleanMessage))
        }

        val contents = JSONArray()
        history.takeLast(8).forEach { (role, text) ->
            if (text.isBlank()) return@forEach
            val geminiRole = if (role.equals("user", ignoreCase = true)) "user" else "model"
            contents.put(
                JSONObject()
                    .put("role", geminiRole)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", cleanMessage)))
        )

        return postChatToGeminiApi(
            apiKey = resolveApiKey(),
            contents = contents,
            temperature = 0.4
        ).fold(
            onSuccess = { reply -> Result.success(reply) },
            onFailure = { err ->
                Log.w(TAG, "Gemini assistant chat failed: ${err.message}")
                Result.failure(err)
            }
        )
    }

    private suspend fun postChatToGeminiApi(
        apiKey: String,
        contents: JSONArray,
        temperature: Double
    ): Result<String> {
        return try {
            withTimeout(45_000L) {
                withContext(Dispatchers.IO) {
                    val requestBody = JSONObject().apply {
                        put("contents", contents)
                        put(
                            "systemInstruction",
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", ASSISTANT_SYSTEM_PROMPT))
                            )
                        )
                        put(
                            "generationConfig",
                            JSONObject().apply {
                                put("temperature", temperature)
                                put("maxOutputTokens", 1024)
                            }
                        )
                    }.toString()

                    var lastFailure: Exception? = null
                    for (modelName in SUPPORTED_MODELS) {
                        val endpoint = "$GEMINI_BASE_URL/v1beta/models/$modelName:generateContent"
                        var connection: HttpURLConnection? = null
                        try {
                            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                                requestMethod = "POST"
                                connectTimeout = 15_000
                                readTimeout = 35_000
                                doInput = true
                                doOutput = true
                                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                                setRequestProperty("x-goog-api-key", apiKey)
                            }

                            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                                writer.write(requestBody)
                                writer.flush()
                            }

                            val statusCode = connection.responseCode
                            val stream = if (statusCode in 200..299) {
                                connection.inputStream
                            } else {
                                connection.errorStream ?: connection.inputStream
                            }
                            val responseText = stream?.use { input ->
                                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                            }.orEmpty()

                            if (statusCode in 200..299) {
                                val text = extractTextFromGeminiResponse(responseText)
                                if (!text.isNullOrBlank()) {
                                    return@withContext Result.success(text.trim())
                                }
                                lastFailure = IllegalStateException("Gemini AI bo'sh javob qaytardi.")
                            } else {
                                lastFailure = IllegalStateException(
                                    parseGeminiErrorMessage(responseText, statusCode)
                                )
                                if (statusCode != 404) break
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            lastFailure = e
                            break
                        } finally {
                            connection?.disconnect()
                        }
                    }
                    Result.failure(
                        lastFailure ?: IllegalStateException("Gemini AI so'rovini bajarib bo'lmadi.")
                    )
                }
            }
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("AI javob vaqti tugadi (45 soniya). Internet aloqasini tekshiring."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini assistant request failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Gemini AI ulanishida xatolik yuz berdi."))
        }
    }

    private fun offlineAssistantReply(message: String): String {
        val lower = message.lowercase()
        val guidance = when {
            lower.contains("apk") || lower.contains("taklifnoma") ||
                lower.contains("albom") || lower.contains("приглашение") -> """
                Agar siz "To'yga taklifnoma.apk" yoki shunga o'xshash faylni o'rnatgan bo'lsangiz:
                1) Qurilmani darhol Wi-Fi/Fly rejimiga o'tkazing.
                2) Ilovani Sozlamalar → Ilovalar orqali o'chiring; yashirin belgisi bo'lsa, qurilmani xavfsiz rejimda tekshiring.
                3) Qalqon AI → Fayl Tekshiruvi bo'limida faylni qayta skanerlang va ogohlantirishni saqlang.
                4) Bank ilovalari parollarini, Telegram/WhatsApp hisoblarini boshqa qurilmadan o'zgartiring, SMS/OTP kodlarini hech kimga aytmang.
                5) Yuborgan odamni bloklang va kerak bo'lsa rasmiy idoraga murojaat qiling.
            """.trimIndent()

            lower.contains("parol") || lower.contains("akkaunt") || lower.contains("account") ||
                lower.contains("аккаунт") || lower.contains("telegram") -> """
                Akkaunt buzilgan deb gumon qilsangiz:
                1) Parolni va ikki bosqichli tasdiqlash (2FA) kodlarini boshqa qurilmadan yangilang.
                2) Faol sessiyalarni va bog'langan qurilmalarni tekshirib, notanishlarini o'chiring.
                3) SMS/OTP kod so'ragan xabarlarga javob bermang — bank va messenjlar ularni hech qachon so'ramaydi.
                4) Qalqon AI jurnalidagi bloklangan xabarlarni tekshiring va shubhali havolalarni ochmang.
            """.trimIndent()

            lower.contains("http") || lower.contains("havola") || lower.contains("link") ||
                lower.contains("ссылка") || lower.contains("xabar") -> """
                Shubhali havola yoki xabarni tekshirish:
                1) Havolani ochishdan oldin domenni diqqat bilan o'qing (bank nomidagi qo'shimcha harflar, notanish .tk/.xyz kabi domenlar xavfli).
                2) "Darhol pul o'tkazing", "karta kodingizni yuboring", "OTP ayting" kabi talablar — firibgarlik.
                3) Havoladan o'rnatish so'ralgan APK faylni yuklamang; uni Qalqon AI skaneriga soling.
                4) Shubhali xabarni ijtimoiy tarmoq ichida ham Qalqon AI bilan tekshiring.
            """.trimIndent()

            else -> """
                Men Qalqon AI kiberxavfsizlik yordamchisiman. Men bilan quyidagilarni muhokama qilishingiz mumkin:
                • tasodifan o'rnatilgan shubhali APK (masalan, "To'yga taklifnoma.apk");
                • buzilgan yoki o'g'irlangan akkaunt va SMS/OTP kodlari;
                • shubhali havola, to'lov xabari yoki ijtimoiy tarmoq posti.
                Aniq maslahat olish uchun vaziyatni qisqacha yozib bering.
            """.trimIndent()
        }
        return "$guidance\n\n(Eslatma: bu oflayn javob. To'liq Gemini tahlili uchun internet ulanishi kerak.)"
    }

    private suspend fun runStructuredAnalysis(
        prompt: String,
        responseSchema: JSONObject = buildThreatSchemaJson()
    ): Result<GeminiAnalysisResult> {
        val apiKey = resolveApiKey()
        val apiResponse = postToGeminiApi(
            apiKey = apiKey,
            prompt = prompt,
            temperature = 0.2,
            responseSchema = responseSchema
        )

        return apiResponse.mapCatching { rawJson ->
            val cleanJson = stripMarkdownFences(rawJson)
            val json = JSONObject(cleanJson)
            val riskLevel = runCatching {
                ThreatLevel.valueOf(json.optString("riskLevel", "SAFE"))
            }.getOrDefault(ThreatLevel.SAFE)

            val dangerousKeywords = json.optJSONArray("dangerousKeywords")?.let { array ->
                buildList {
                    for (i in 0 until array.length()) {
                        val keyword = array.optString(i).trim().trimStart('#').trim()
                        if (keyword.isNotEmpty() && keyword.length <= 120) add(keyword)
                    }
                }.distinctBy { it.lowercase() }.take(8)
            }.orEmpty()

            GeminiAnalysisResult(
                isHarmful = json.optBoolean("isHarmful", riskLevel != ThreatLevel.SAFE),
                riskLevel = riskLevel,
                category = json.optString("category", "XAVFSIZ"),
                explanationUz = json.optString("explanationUz", "Tahlil yakunlandi."),
                recommendedActionUz = json.optString(
                    "recommendedActionUz",
                    "Shubhali havola va fayllardan ehtiyot bo'ling."
                ),
                dangerousKeywords = dangerousKeywords,
                detectedLanguage = json.optString("detectedLanguage").takeIf { it.isNotBlank() }
            )
        }
    }

    private suspend fun postToGeminiApi(
        apiKey: String,
        prompt: String,
        temperature: Double,
        responseSchema: JSONObject
    ): Result<String> {
        return try {
            withTimeout(45_000L) {
                withContext(Dispatchers.IO) {
                    val requestBody = JSONObject().apply {
                        put(
                            "contents",
                            JSONArray().put(
                                JSONObject().put(
                                    "parts",
                                    JSONArray().put(JSONObject().put("text", prompt))
                                )
                            )
                        )
                        put(
                            "generationConfig",
                            JSONObject().apply {
                                put("temperature", temperature)
                                put("responseMimeType", "application/json")
                                put("responseSchema", responseSchema)
                            }
                        )
                    }.toString()

                    var lastFailure: Exception? = null
                    for (modelName in SUPPORTED_MODELS) {
                        val endpoint = "$GEMINI_BASE_URL/v1beta/models/$modelName:generateContent"
                        var connection: HttpURLConnection? = null
                        try {
                            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                                requestMethod = "POST"
                                connectTimeout = 15_000
                                readTimeout = 35_000
                                doInput = true
                                doOutput = true
                                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                                setRequestProperty("x-goog-api-key", apiKey)
                            }

                            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                                writer.write(requestBody)
                                writer.flush()
                            }

                            val statusCode = connection.responseCode
                            val stream = if (statusCode in 200..299) {
                                connection.inputStream
                            } else {
                                connection.errorStream ?: connection.inputStream
                            }
                            val responseText = stream?.use { input ->
                                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                            }.orEmpty()

                            if (statusCode in 200..299) {
                                val text = extractTextFromGeminiResponse(responseText)
                                if (!text.isNullOrBlank()) {
                                    return@withContext Result.success(text)
                                }
                                lastFailure = IllegalStateException("Gemini API bo'sh javob qaytardi.")
                            } else {
                                val errorDetail = parseGeminiErrorMessage(responseText, statusCode)
                                lastFailure = IllegalStateException(errorDetail)
                                // Only retry alternate model if 404 model-not-found
                                if (statusCode != 404) {
                                    break
                                }
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            lastFailure = e
                            break
                        } finally {
                            connection?.disconnect()
                        }
                    }
                    Result.failure(
                        lastFailure ?: IllegalStateException("Gemini API so'rovini bajarib bo'lmadi.")
                    )
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini REST API request timed out", e)
            Result.failure(Exception("AI tahlil vaqti tugadi (45 soniya). Internet aloqasini tekshiring."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini REST API call failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Gemini AI ulanishida xatolik yuz berdi."))
        }
    }

    private fun extractTextFromGeminiResponse(rawResponse: String): String? {
        val root = JSONObject(rawResponse)
        val candidates = root.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        for (i in 0 until parts.length()) {
            val text = parts.optJSONObject(i)?.optString("text")
            if (!text.isNullOrBlank()) return text
        }
        return null
    }

    private fun parseGeminiErrorMessage(rawError: String, statusCode: Int): String {
        val apiMessage = runCatching {
            JSONObject(rawError).optJSONObject("error")?.optString("message")
        }.getOrNull()?.takeIf { it.isNotBlank() }

        return when (statusCode) {
            400, 401, 403 -> "API kalit noto'g'ri yoki ruxsat rad etildi (HTTP $statusCode)${apiMessage?.let { ": $it" } ?: ""}"
            429 -> "So'rovlar limiti tugadi (HTTP 429). Birozdan keyin urinib ko'ring."
            else -> "Gemini API xatoligi (HTTP $statusCode)${apiMessage?.let { ": $it" } ?: ""}"
        }
    }

    private fun stripMarkdownFences(raw: String): String {
        val trimmed = raw.trim()
        if (!trimmed.startsWith("```")) return trimmed
        return trimmed
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
    }

    private fun offlineSocialFallback(
        text: String,
        sensitivity: AiSensitivity
    ): GeminiAnalysisResult {
        context?.let { ContentSafetyClassifier.ensureInitialized(it) }
        val local = ContentSafetyClassifier.classifyText(
            text = text,
            sensitivity = sensitivity
        )
        return GeminiAnalysisResult(
            isHarmful = local.isHarmful,
            riskLevel = local.threatLevel,
            category = local.categories.firstOrNull() ?: if (local.isHarmful) "XAVFLI_KONTENT" else "XAVFSIZ",
            explanationUz = "Oflayn Qalqon dvigateli: ${local.summaryUz}",
            recommendedActionUz = if (local.isHarmful) {
                "Ushbu xavfli kontent bilan aloqa qilmang (Like/Share/Izoh bloklandi)."
            } else {
                "Oflayn tahlil bo'yicha xavfli iboralar aniqlanmadi."
            }
        )
    }

    private fun offlineApkHeuristicFallback(
        fileName: String,
        suspiciousPermissions: List<String>,
        deceptiveMatch: String?,
        metadata: ApkHeuristicMetadata
    ): ApkHeuristicAiResult {
        val allPerms = metadata.allRequestedPermissions.toSet()
        val hasInternet = allPerms.contains("android.permission.INTERNET")
        val hasSms = allPerms.contains("android.permission.READ_SMS") ||
            allPerms.contains("android.permission.RECEIVE_SMS") ||
            allPerms.contains("android.permission.SEND_SMS")
        val hasAccessibility = allPerms.contains("android.permission.BIND_ACCESSIBILITY_SERVICE")
        val hasOverlay = allPerms.contains("android.permission.SYSTEM_ALERT_WINDOW")
        val hasInstallPackages = allPerms.contains("android.permission.REQUEST_INSTALL_PACKAGES")
        val isUnsigned = metadata.signatureChecked && metadata.signatureCount == 0

        val hasSmsInternetCombo = hasSms && (hasInternet || hasOverlay || isUnsigned)
        val hasAccessibilityOverlayCombo = hasAccessibility && (hasOverlay || hasInternet || isUnsigned)
        val hasOverlayInstallerCombo = hasOverlay && hasInstallPackages && (hasInternet || isUnsigned)

        val findings = buildList {
            if (deceptiveMatch != null) add("Aldamchi ijtimoiy muhandislik niqobi: $deceptiveMatch")
            if (metadata.hasHiddenLauncherIcon) add("Yashirin launcher belgisi (0 ta asosiy ekran faoliyati)")
            if (hasSmsInternetCombo) add("Xavfli ruxsatlar kombinatsiyasi: SMS + INTERNET/Overlay")
            if (hasAccessibilityOverlayCombo) add("Xavfli ruxsatlar kombinatsiyasi: Accessibility + SYSTEM_ALERT_WINDOW")
            if (hasOverlayInstallerCombo) add("Xavfli ruxsatlar kombinatsiyasi: Overlay + REQUEST_INSTALL_PACKAGES")
            if (metadata.suspiciousAssets.isNotEmpty()) {
                add("Arxiv ichida yashirin payload fayllari: ${metadata.suspiciousAssets.joinToString(", ")}")
            }
            if (isEmpty()) {
                add("Oflayn evristik tekshiruvda aldamchi nom, yashirin belgi yoki zararli kombinatsiya topilmadi")
            }
        }

        val isCritical = deceptiveMatch != null ||
            hasSmsInternetCombo ||
            hasAccessibilityOverlayCombo ||
            (metadata.hasHiddenLauncherIcon && (hasSms || hasAccessibility || hasInstallPackages)) ||
            (metadata.suspiciousAssets.isNotEmpty() && (hasSms || hasAccessibility || hasInstallPackages || isUnsigned))
        val isSuspicious = !isCritical && (
            metadata.suspiciousAssets.isNotEmpty() ||
                metadata.hasHiddenLauncherIcon ||
                hasOverlayInstallerCombo ||
                hasSms ||
                hasAccessibility
            )
        val riskLevel = when {
            isCritical -> ThreatLevel.CRITICAL
            isSuspicious -> ThreatLevel.SUSPICIOUS
            else -> ThreatLevel.SAFE
        }
        val category = when {
            deceptiveMatch != null -> "FISHING_NIQOBI"
            metadata.suspiciousAssets.isNotEmpty() -> "DROPPER"
            hasSmsInternetCombo -> "BANK_TROYANI"
            hasAccessibilityOverlayCombo || metadata.hasHiddenLauncherIcon -> "JOSUS_DASTUR"
            riskLevel == ThreatLevel.SUSPICIOUS -> "SHUBHALI_RUXSAT"
            else -> "XAVFSIZ"
        }

        return ApkHeuristicAiResult(
            isMalicious = riskLevel != ThreatLevel.SAFE,
            riskLevel = riskLevel,
            category = category,
            confidencePercent = if (riskLevel == ThreatLevel.CRITICAL) 92 else if (riskLevel == ThreatLevel.SUSPICIOUS) 78 else 86,
            heuristicFindingsUz = findings,
            explanationUz = "Oflayn evristik dvigatel ($fileName): internet ulanmagani sababli lokal ruxsat kombinatsiyalari va manifest signallari asosida baholandi.",
            recommendedActionUz = if (riskLevel == ThreatLevel.SAFE) {
                "Lokal tahlil bo'yicha xavfsiz ko'rinadi, ammo faqat ishonchli manbadan o'rnating."
            } else {
                "Ushbu ilovani o'rnatmang va qurilmadan darhol o'chiring."
            }
        )
    }

    private fun buildThreatSchemaJson(): JSONObject = JSONObject().apply {
        put("type", "OBJECT")
        put(
            "properties",
            JSONObject().apply {
                put("isHarmful", JSONObject().apply { put("type", "BOOLEAN") })
                put(
                    "riskLevel",
                    JSONObject().apply {
                        put("type", "STRING")
                        put("enum", JSONArray(listOf("SAFE", "SUSPICIOUS", "CRITICAL")))
                    }
                )
                put(
                    "category",
                    JSONObject().apply {
                        put("type", "STRING")
                        put(
                            "enum",
                            JSONArray(
                                listOf(
                                    "XAVFSIZ",
                                    "EKSTREMIZM",
                                    "NAFRAT",
                                    "ZO'RAVONLIK",
                                    "FIRIBGARLIK",
                                    "ZARARLI_APK"
                                )
                            )
                        )
                    }
                )
                put("explanationUz", JSONObject().apply { put("type", "STRING") })
                put("recommendedActionUz", JSONObject().apply { put("type", "STRING") })
            }
        )
        put(
            "required",
            JSONArray(
                listOf("isHarmful", "riskLevel", "category", "explanationUz", "recommendedActionUz")
            )
        )
    }

    private fun buildSocialAnalysisSchemaJson(): JSONObject = JSONObject().apply {
        put("type", "OBJECT")
        put(
            "properties",
            JSONObject().apply {
                put("isHarmful", JSONObject().apply { put("type", "BOOLEAN") })
                put(
                    "riskLevel",
                    JSONObject().apply {
                        put("type", "STRING")
                        put("enum", JSONArray(listOf("SAFE", "SUSPICIOUS", "CRITICAL")))
                    }
                )
                put(
                    "category",
                    JSONObject().apply {
                        put("type", "STRING")
                        put(
                            "enum",
                            JSONArray(
                                listOf(
                                    "XAVFSIZ",
                                    "EKSTREMIZM",
                                    "NAFRAT",
                                    "ZO'RAVONLIK",
                                    "FIRIBGARLIK",
                                    "ZARARLI_APK"
                                )
                            )
                        )
                    }
                )
                put(
                    "dangerousKeywords",
                    JSONObject().apply {
                        put("type", "ARRAY")
                        put("items", JSONObject().apply { put("type", "STRING") })
                    }
                )
                put(
                    "detectedLanguage",
                    JSONObject().apply {
                        put("type", "STRING")
                        put("enum", JSONArray(listOf("UZ", "RU", "EN", "MIXED")))
                    }
                )
                put("explanationUz", JSONObject().apply { put("type", "STRING") })
                put("recommendedActionUz", JSONObject().apply { put("type", "STRING") })
            }
        )
        put(
            "required",
            JSONArray(
                listOf(
                    "isHarmful",
                    "riskLevel",
                    "category",
                    "dangerousKeywords",
                    "explanationUz",
                    "recommendedActionUz"
                )
            )
        )
    }

    private fun buildApkHeuristicSchemaJson(): JSONObject = JSONObject().apply {
        put("type", "OBJECT")
        put(
            "properties",
            JSONObject().apply {
                put("isMalicious", JSONObject().apply { put("type", "BOOLEAN") })
                put(
                    "riskLevel",
                    JSONObject().apply {
                        put("type", "STRING")
                        put("enum", JSONArray(listOf("SAFE", "SUSPICIOUS", "CRITICAL")))
                    }
                )
                put(
                    "category",
                    JSONObject().apply {
                        put("type", "STRING")
                        put(
                            "enum",
                            JSONArray(
                                listOf(
                                    "XAVFSIZ",
                                    "BANK_TROYANI",
                                    "JOSUS_DASTUR",
                                    "DROPPER",
                                    "FISHING_NIQOBI",
                                    "SHUBHALI_RUXSAT"
                                )
                            )
                        )
                    }
                )
                put("confidencePercent", JSONObject().apply { put("type", "INTEGER") })
                put(
                    "heuristicFindingsUz",
                    JSONObject().apply {
                        put("type", "ARRAY")
                        put("items", JSONObject().apply { put("type", "STRING") })
                    }
                )
                put("explanationUz", JSONObject().apply { put("type", "STRING") })
                put("recommendedActionUz", JSONObject().apply { put("type", "STRING") })
            }
        )
        put(
            "required",
            JSONArray(
                listOf(
                    "isMalicious",
                    "riskLevel",
                    "category",
                    "confidencePercent",
                    "heuristicFindingsUz",
                    "explanationUz",
                    "recommendedActionUz"
                )
            )
        )
    }

    companion object {
        private const val TAG = "GeminiThreatAnalyzer"
        private const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com"
        private val SUPPORTED_MODELS = listOf("gemini-2.5-flash", "gemini-2.0-flash")

        private val ASSISTANT_SYSTEM_PROMPT = """
            Sen Qalqon AI ilovasining kiberxavfsizlik bo'yicha o'zbek tili mutaxassis yordamchisisan.
            Foydalanuvchiga do'stona, aniq va amaliy maslahat ber. Har bir javob O'zbek tilida (Lotin yozuvida) bo'lsin.
            Quyidagi vaziyatlarga alohida e'tibor ber:
            1) Tasodifan zararli APK o'rnatilgan bo'lsa (masalan, "To'yga taklifnoma.apk", "Foto albom.apk", "Karta pul o'tkazmasi.apk"): darhol tarmoqdan uzish, ilovani o'chirish, Qalqon AI bilan qayta skanerlash, OTP/SMS kodlarini hech kimga bermaslik, bank va messenjer parollarini boshqa qurilmadan almashtirish, faol sessiyalarni tugatish bosqichlarini tushuntir.
            2) Akkaunt buzilgan yoki parol o'g'irlangan bo'lsa: 2FA, parol almashtirish, notanish qurilmalarni chiqarish, tiklash kodlarini saqlash bo'yicha yo'l-yo'riq ber.
            3) Shubhali havola, SMS yoki ijtimoiy tarmoq xabari bo'lsa: domenni tekshirish, firibgarlik belgilari (pul o'tkazmasi, karta/SMS kodi talabi), havoladagi APK ni yuklamaslik va Qalqon AI filtriga qo'shishni maslahat ber.
            Hech qachon foydalanuvchidan parol, OTP yoki karta ma'lumotlarini so'rama. Huquqiy yoki tibbiy maslahat o'rniga rasmiy muassasalarga murojaat qilishni tavsiya et. Javoblarni qisqa, bosqichma-bosqich va xavfsizlikka yo'naltirilgan qilib yoz.
        """.trimIndent()
    }
}
