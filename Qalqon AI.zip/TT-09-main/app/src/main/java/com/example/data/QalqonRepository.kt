package com.example.data

import android.content.Context
import com.example.security.ApkThreatAnalyzer
import com.example.security.BlacklistResourceLoader
import com.example.security.ContentSafetyClassifier
import kotlinx.coroutines.flow.Flow

class QalqonRepository(context: Context) {
    private val appContext = context.applicationContext
    private val database = QalqonDatabase.getInstance(appContext)
    private val dao = database.qalqonDao()
    private val prefs = QalqonPreferencesRepository(appContext)

    val threatLogs: Flow<List<ThreatLogEntity>> = dao.observeThreatLogs()
    val blockedThreatsCount: Flow<Int> = dao.observeBlockedThreatsCount()
    val blockedApkCount: Flow<Int> = dao.observeBlockedApkCount()
    val blockedSocialCount: Flow<Int> = dao.observeBlockedSocialCount()
    val keywordRules: Flow<List<KeywordRuleEntity>> = dao.observeKeywordRules()
    val protectedAccounts: Flow<List<ProtectedAccountEntity>> = dao.observeProtectedAccounts()
    val whitelistEntries: Flow<List<WhitelistEntryEntity>> = dao.observeWhitelistEntries()
    val scannedFiles: Flow<List<ScannedFileEntity>> = dao.observeScannedFiles()
    val settings: Flow<QalqonSettingsState> = prefs.settingsFlow

    suspend fun ensureInitialDataSeeded() {
        if (dao.getAccountsCount() == 0) {
            val now = System.currentTimeMillis()
            dao.insertProtectedAccounts(
                listOf(
                    ProtectedAccountEntity(
                        platform = SocialPlatform.TELEGRAM.name,
                        handleOrLabel = "Telegram (Yuklanmalar va APK qalqoni)",
                        protectionActive = true,
                        sessionMonitorMethod = SocialPlatform.TELEGRAM.defaultMonitorMethod,
                        oauthConnected = true,
                        blockedCount = 0,
                        lastCheckedAt = now,
                        securityScore = 96
                    ),
                    ProtectedAccountEntity(
                        platform = SocialPlatform.INSTAGRAM.name,
                        handleOrLabel = "Instagram (Reels & Direct himoyasi)",
                        protectionActive = true,
                        sessionMonitorMethod = SocialPlatform.INSTAGRAM.defaultMonitorMethod,
                        oauthConnected = false,
                        blockedCount = 0,
                        lastCheckedAt = now,
                        securityScore = 88
                    ),
                    ProtectedAccountEntity(
                        platform = SocialPlatform.YOUTUBE.name,
                        handleOrLabel = "YouTube (Video & Izoh filtri)",
                        protectionActive = true,
                        sessionMonitorMethod = SocialPlatform.YOUTUBE.defaultMonitorMethod,
                        oauthConnected = false,
                        blockedCount = 0,
                        lastCheckedAt = now,
                        securityScore = 90
                    ),
                    ProtectedAccountEntity(
                        platform = SocialPlatform.FACEBOOK.name,
                        handleOrLabel = "Facebook (Lenta & Havola himoyasi)",
                        protectionActive = true,
                        sessionMonitorMethod = SocialPlatform.FACEBOOK.defaultMonitorMethod,
                        oauthConnected = false,
                        blockedCount = 0,
                        lastCheckedAt = now,
                        securityScore = 85
                    )
                )
            )
        }

        val catalog = BlacklistResourceLoader.loadCatalog(appContext)
        ContentSafetyClassifier.loadFromCatalog(catalog)
        ApkThreatAnalyzer.ensureInitialized(appContext)

        if (dao.getKeywordRulesCount() == 0) {
            val jsonRules = BlacklistResourceLoader.toKeywordRuleEntities(catalog)
            dao.insertKeywordRules(jsonRules.ifEmpty { defaultKeywordRules() })
        }

        if (dao.getWhitelistCount() == 0) {
            dao.insertWhitelistEntries(
                listOf(
                    WhitelistEntryEntity(
                        value = "uz.gov.my",
                        entryType = WhitelistType.PACKAGE_NAME.name,
                        noteUz = "MyGov.uz — Rasmiy davlat xizmatlari ilovasi"
                    ),
                    WhitelistEntryEntity(
                        value = "com.click.uz",
                        entryType = WhitelistType.PACKAGE_NAME.name,
                        noteUz = "Click Evolution — Ishonchli to'lov tizimi"
                    )
                )
            )
        }
    }

    suspend fun logThreat(log: ThreatLogEntity): Long = dao.insertThreatLog(log)

    suspend fun deleteThreatLogById(id: Long) = dao.deleteThreatLogById(id)

    suspend fun clearLogs() = dao.clearThreatLogs()

    suspend fun recordScannedFile(file: ScannedFileEntity): Long = dao.insertScannedFile(file)

    suspend fun deleteScannedFileById(id: Long) = dao.deleteScannedFileById(id)

    suspend fun clearScannedFiles() = dao.clearScannedFiles()

    suspend fun getEnabledKeywords(): List<KeywordRuleEntity> = dao.getEnabledKeywordRules()

    suspend fun addKeywordRule(keyword: String, language: String, category: String) {
        val trimmed = keyword.trim()
        if (trimmed.isNotEmpty()) {
            dao.insertKeywordRule(
                KeywordRuleEntity(
                    keyword = trimmed,
                    language = language,
                    category = category,
                    isEnabled = true,
                    isSystemDefault = false
                )
            )
        }
    }

    /**
     * Stores a keyword/hashtag discovered by Gemini in the offline Room filter.
     * Duplicates are ignored so repeated analyses never create endless rules.
     */
    suspend fun addAutoFilteredKeywordRule(
        keyword: String,
        language: String,
        category: String
    ): Boolean {
        val trimmed = keyword.trim().trimStart('#').trim().take(120)
        if (trimmed.length < 3) return false
        if (dao.findKeywordRuleByKeyword(trimmed) != null) return false
        dao.insertKeywordRule(
            KeywordRuleEntity(
                keyword = trimmed,
                language = language,
                category = category,
                isEnabled = true,
                isSystemDefault = false
            )
        )
        return true
    }

    suspend fun toggleKeywordRule(rule: KeywordRuleEntity) {
        dao.updateKeywordRule(rule.copy(isEnabled = !rule.isEnabled))
    }

    suspend fun deleteKeywordRule(id: Long) = dao.deleteKeywordRule(id)

    suspend fun addWhitelistEntry(value: String, type: WhitelistType, noteUz: String = "") {
        val clean = value.trim()
        if (clean.isEmpty()) return
        val existing = dao.getAllWhitelistEntries().any {
            it.value.equals(clean, ignoreCase = true) && it.entryType == type.name
        }
        if (!existing) {
            dao.insertWhitelistEntry(
                WhitelistEntryEntity(
                    value = clean,
                    entryType = type.name,
                    noteUz = noteUz.trim()
                )
            )
        }
    }

    suspend fun deleteWhitelistEntry(id: Long) = dao.deleteWhitelistEntry(id)

    suspend fun isApkWhitelisted(fileName: String, packageName: String?): Boolean {
        val entries = dao.getAllWhitelistEntries()
        return matchesApkWhitelist(fileName, packageName, entries)
    }

    suspend fun isContentWhitelisted(text: String): Boolean {
        val entries = dao.getAllWhitelistEntries()
        return matchesContentWhitelist(text, entries)
    }

    suspend fun toggleAccountProtection(account: ProtectedAccountEntity) {
        val nextActive = !account.protectionActive
        dao.updateProtectedAccount(
            account.copy(
                protectionActive = nextActive,
                lastCheckedAt = System.currentTimeMillis(),
                securityScore = if (nextActive) {
                    if (account.oauthConnected) 96 else 88
                } else {
                    45
                }
            )
        )
    }

    suspend fun toggleAccountSafeSession(account: ProtectedAccountEntity) {
        val nextOauth = !account.oauthConnected
        dao.updateProtectedAccount(
            account.copy(
                oauthConnected = nextOauth,
                lastCheckedAt = System.currentTimeMillis(),
                securityScore = if (account.protectionActive) {
                    if (nextOauth) 98 else 86
                } else {
                    50
                }
            )
        )
    }

    suspend fun incrementAccountBlocked(platform: SocialPlatform) {
        dao.incrementAccountBlockedCount(platform.name)
    }

    suspend fun setOnboardingCompleted(completed: Boolean) = prefs.setOnboardingCompleted(completed)
    suspend fun setMasterShieldEnabled(enabled: Boolean) = prefs.setMasterShieldEnabled(enabled)
    suspend fun setApkAutoScanEnabled(enabled: Boolean) = prefs.setApkAutoScanEnabled(enabled)
    suspend fun setSocialGuardEnabled(enabled: Boolean) = prefs.setSocialGuardEnabled(enabled)
    suspend fun setGeminiAnalysisEnabled(enabled: Boolean) = prefs.setGeminiAnalysisEnabled(enabled)
    suspend fun setAiSensitivity(sensitivity: AiSensitivity) = prefs.setAiSensitivity(sensitivity)
    suspend fun incrementScannedFilesCount(by: Int = 1) = prefs.incrementScannedFilesCount(by)
    suspend fun setBiometricLockEnabled(enabled: Boolean) = prefs.setBiometricLockEnabled(enabled)
    suspend fun setPeriodicAppAuditEnabled(enabled: Boolean) = prefs.setPeriodicAppAuditEnabled(enabled)
    suspend fun getAuditedPackageSignatures(): Set<String> = prefs.getAuditedPackageSignatures()
    suspend fun recordAppAuditRun(
        auditedSignatures: Set<String>,
        timestamp: Long,
        summaryUz: String
    ) = prefs.recordAppAuditRun(auditedSignatures, timestamp, summaryUz)

    suspend fun setGeneralAlertsEnabled(enabled: Boolean) = prefs.setGeneralAlertsEnabled(enabled)
    suspend fun setCategoryNotificationEnabled(
        category: ThreatNotificationCategory,
        enabled: Boolean
    ) = prefs.setCategoryNotificationEnabled(category, enabled)
    suspend fun setNotificationSoundEnabled(enabled: Boolean) = prefs.setNotificationSoundEnabled(enabled)
    suspend fun setQuietHoursEnabled(enabled: Boolean) = prefs.setQuietHoursEnabled(enabled)
    suspend fun setCriticalBypassQuietHours(enabled: Boolean) = prefs.setCriticalBypassQuietHours(enabled)
    suspend fun applyNotificationPreset(preset: NotificationPreferences) = prefs.applyNotificationPreset(preset)
    suspend fun getNotificationPreferences(): NotificationPreferences = prefs.getNotificationPreferences()
    suspend fun setGeminiApiKey(apiKey: String) = prefs.setGeminiApiKey(apiKey)

    private fun defaultKeywordRules(): List<KeywordRuleEntity> = listOf(
        KeywordRuleEntity(keyword = "jihodga da'vat", language = "UZ", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "yashirin jamoat", language = "UZ", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "maxfiy bay'at", language = "UZ", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "tuzumni ag'darish", language = "UZ", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "karta kodingizni yuboring", language = "UZ", category = "FIRIBGARLIK", isSystemDefault = true),
        KeywordRuleEntity(keyword = "sms kodni ayting", language = "UZ", category = "FIRIBGARLIK", isSystemDefault = true),
        KeywordRuleEntity(keyword = "millatlararo adovat", language = "UZ", category = "NAFRAT", isSystemDefault = true),
        KeywordRuleEntity(keyword = "portlatish tayyorgarligi", language = "UZ", category = "ZO'RAVONLIK", isSystemDefault = true),
        KeywordRuleEntity(keyword = "вербовка в отряд", language = "RU", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "радикальный призыв", language = "RU", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "тайная секта", language = "RU", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "переведите деньги на карту", language = "RU", category = "FIRIBGARLIK", isSystemDefault = true),
        KeywordRuleEntity(keyword = "разжигание ненависти", language = "RU", category = "NAFRAT", isSystemDefault = true),
        KeywordRuleEntity(keyword = "join extremist cell", language = "EN", category = "EKSTREMIZM", isSystemDefault = true),
        KeywordRuleEntity(keyword = "violent attack guide", language = "EN", category = "ZO'RAVONLIK", isSystemDefault = true),
        KeywordRuleEntity(keyword = "hate speech mobilization", language = "EN", category = "NAFRAT", isSystemDefault = true)
    )

    companion object {
        fun matchesApkWhitelist(
            fileName: String,
            packageName: String?,
            entries: List<WhitelistEntryEntity>
        ): Boolean {
            return entries.any { entry ->
                when (entry.entryType) {
                    WhitelistType.APK_FILE.name -> fileName.equals(entry.value, ignoreCase = true)
                    WhitelistType.PACKAGE_NAME.name -> !packageName.isNullOrBlank() &&
                        packageName.equals(entry.value, ignoreCase = true)
                    else -> false
                }
            }
        }

        fun matchesContentWhitelist(
            text: String,
            entries: List<WhitelistEntryEntity>
        ): Boolean {
            if (text.isBlank()) return false
            val lower = text.lowercase()
            return entries.any { entry ->
                entry.entryType == WhitelistType.SOCIAL_CHANNEL.name &&
                    lower.contains(entry.value.lowercase())
            }
        }
    }
}
