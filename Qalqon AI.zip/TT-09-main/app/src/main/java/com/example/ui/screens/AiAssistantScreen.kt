package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.AiAssistantUiState
import com.example.ui.AssistantChatMessage
import com.example.ui.components.StatusBadgePill
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberNavyBg
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.ShieldEmeraldContainer
import com.example.ui.theme.ThreatCrimson
import com.example.ui.theme.ThreatCrimsonContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dark-mode cybersecurity chat connected to Gemini (gemini-2.5-flash).
 * The assistant speaks Uzbek and guides users through malicious APK installs,
 * compromised accounts and suspicious links/messages.
 */
@Composable
fun AiAssistantScreen(
    state: AiAssistantUiState,
    onSendMessage: (String) -> Unit,
    onClearChat: () -> Unit
) {
    var messageInput by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size, state.isResponding) {
        if (state.messages.isNotEmpty()) {
            listState.animateScrollToItem(
                if (state.isResponding) state.messages.size else state.messages.size - 1
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyBg)
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CyberSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.45f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "Gemini AI",
                                tint = CyberCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "AI Yordamchi",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        StatusBadgePill(
                            text = "Gemini 2.5 Flash",
                            accentColor = ShieldEmerald,
                            containerColor = ShieldEmeraldContainer
                        )
                    }
                    Text(
                        text = "O'zbek kiberxavfsizlik mutaxassisi. Zararli APK, buzilgan akkaunt yoki shubhali havola bo'yicha yordam beradi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            SuggestionChip(label = "To'yga taklifnoma.apk") {
                                onSendMessage("To'yga taklifnoma.apk ni tasodifan o'rnatib qo'ydim. Nima qilishim kerak?")
                            }
                        }
                        item {
                            SuggestionChip(label = "Akkaunt buzilgan") {
                                onSendMessage("Telegram akkauntim buzilgan bo'lishi mumkin, qanday tiklayman?")
                            }
                        }
                        item {
                            SuggestionChip(label = "Shubhali havola") {
                                onSendMessage("Shubhali havola va xabarni qanday tekshiraman?")
                            }
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                state = listState,
                contentPadding = PaddingValues(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.messages, key = { it.id }) { message ->
                    AssistantChatBubble(message = message)
                }
                if (state.isResponding) {
                    item(key = "assistant_typing") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = CyberCyan,
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = "AI Yordamchi javob yozmoqda...",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan
                            )
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CyberSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, CyberOutline)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        placeholder = {
                            Text(
                                text = "Kiberxavfsizlik bo'yicha savolingizni yozing...",
                                color = CyberTextSecondary
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_assistant_message_input"),
                        minLines = 2,
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberOutline,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onClearChat,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("ai_assistant_clear_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "Suhbatni tozalash",
                                tint = CyberTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        androidx.compose.material3.Button(
                            onClick = {
                                if (messageInput.isNotBlank() && !state.isResponding) {
                                    onSendMessage(messageInput)
                                    messageInput = ""
                                }
                            },
                            enabled = messageInput.isNotBlank() && !state.isResponding,
                            modifier = Modifier
                                .height(44.dp)
                                .testTag("ai_assistant_send_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = CyberNavyBg
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Send,
                                contentDescription = "Yuborish",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = if (state.isResponding) "Kutmoqda..." else "Yuborish",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SuggestionChip(
    label: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.testTag("ai_assistant_suggestion_$label"),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.55f))
    ) {
        Text(text = label, color = CyberCyan, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun AssistantChatBubble(message: AssistantChatMessage) {
    val accent = when {
        message.isError -> ThreatCrimson
        message.isUser -> CyberCyan
        else -> ShieldEmerald
    }
    val container = when {
        message.isError -> ThreatCrimsonContainer.copy(alpha = 0.7f)
        message.isUser -> CyberCyanContainer.copy(alpha = 0.75f)
        else -> CyberSurfaceElevated
    }
    val timeLabel = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.88f),
            color = container,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isUser) 16.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 16.dp
            ),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (message.isUser) "Siz" else "AI Yordamchi",
                    style = MaterialTheme.typography.labelSmall,
                    color = accent,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextPrimary
                )
                Text(
                    text = timeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextSecondary,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
