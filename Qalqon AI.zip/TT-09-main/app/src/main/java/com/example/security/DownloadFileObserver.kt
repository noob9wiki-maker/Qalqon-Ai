package com.example.security

import android.os.Build
import android.os.FileObserver
import java.io.File

class DownloadFileObserver private constructor(
    private val directory: File,
    private val onApkDetected: (File) -> Unit
) {
    private var observer: FileObserver? = null

    fun start() {
        if (!directory.exists() || !directory.isDirectory) return
        val mask = FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO or FileObserver.CREATE

        observer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            object : FileObserver(directory, mask) {
                override fun onEvent(event: Int, path: String?) {
                    handleFileEvent(path)
                }
            }
        } else {
            @Suppress("DEPRECATION")
            object : FileObserver(directory.absolutePath, mask) {
                override fun onEvent(event: Int, path: String?) {
                    handleFileEvent(path)
                }
            }
        }
        observer?.startWatching()
    }

    fun stop() {
        observer?.stopWatching()
        observer = null
    }

    private fun handleFileEvent(relativePath: String?) {
        val name = relativePath ?: return
        if (!name.endsWith(".apk", ignoreCase = true)) return
        val file = File(directory, name)
        if (file.exists() && file.isFile) {
            onApkDetected(file)
        }
    }

    companion object {
        fun create(directory: File, onApkDetected: (File) -> Unit): DownloadFileObserver {
            return DownloadFileObserver(directory, onApkDetected)
        }
    }
}
