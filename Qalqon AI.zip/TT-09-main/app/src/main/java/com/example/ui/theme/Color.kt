package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Cybersecurity Palette
val CyberNavyBg = Color(0xFF0B0F19)
val CyberSurface = Color(0xFF121826)
val CyberSurfaceElevated = Color(0xFF182133)
val CyberSurfaceBright = Color(0xFF212D44)
val CyberOutline = Color(0xFF2B3A55)

// Semantic Status Colors
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanContainer = Color(0xFF003844)
val CyberCyanGlow = Color(0x3300E5FF)

val ThreatCrimson = Color(0xFFFF2A55)
val ThreatCrimsonContainer = Color(0xFF4B0A18)
val ThreatCrimsonGlow = Color(0x33FF2A55)

val ShieldEmerald = Color(0xFF00E676)
val ShieldEmeraldContainer = Color(0xFF083B23)

val WarningAmber = Color(0xFFFFB020)
val WarningAmberContainer = Color(0xFF422C04)

// Text Hierarchy
val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF64748B)
